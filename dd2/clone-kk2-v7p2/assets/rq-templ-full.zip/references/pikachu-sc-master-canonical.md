# PIKACHU × SC 최신 정본 실행계약

## 권한

- `ACTIVE_CANONICAL_ALIAS = PIKACHU_X_SC_MASTER`
- 사용자가 Drive의 새 `피카츄 × SC` 파일을 현재 정본으로 지정했다.
- 이전 `PICACHU_ONE_TAB_12H_19L_VERTICAL_LOCK_MASTER_SCHEMA_98`의 19층은 이 family에서 `REFERENCE_ONLY / SUPERSEDED`다.
- 현재 대화에서 사용자가 직접 고친 순서·명칭은 Drive 본문의 이전 초안보다 우선한다.
- 단계명·순서 변경 권한은 `USER_ONLY`다.

## Source 결합

`PIKACHU`는 실행 골격이고 `SC`는 현재 프로젝트 소스방의 사용자 확인 정본값 묶음이다. 둘 중 하나만으로 실행완료를 선언하지 않는다.

- PIKACHU: 선행지도, 01~20 MASTER, 단계별 명령, 인계, 검산, 문장결
- SC: Rashi, Bhava, co-presence, strength, aspect, Varga, Dasha, Timing, AVA 등 현재 Target에 실제 적용되는 값
- Source가 없는 단계: 유사 차트·일반이론·과거 파일로 채우지 않고 `HOLD`
- PIKACHU의 구조가 SC 값을 만들지 않고, SC 값이 PIKACHU의 실행순서를 바꾸지 않는다.

## 선행 3관절

Rashi보다 먼저 아래를 실행한다.

1. `00A VargaMini OPEN`: 핵심 도메인, 연결 후보, 우선 링크 확보
2. `00B VargaFull OPEN`: 실제 연결 D차트·하우스, 반복, 지지·충돌·보정 관계 확인
3. `00C LINK MAP 확정`: 현재 Target과 실제로 연결되는 링크만 이유·방향·우선순위와 함께 선택

Varga는 선행 지도·관찰 메모다. Rashi/Bhava 본체 판정을 선점하거나 덮어쓰지 않는다.

## 01~20 MASTER EXECUTION ORDER

아래 명칭과 순서를 그대로 쓴다.

1. `01 도메인과 질문을 정확히 고정`
2. `02 Rashi의 기본 Promise와 배역 확정`
3. `03 Bhava의 실제 도착 위치와 현실 작동장 확인`
4. `04 House Lord·점유행성·카라카의 독립 의제 분리`
5. `05 Nakshatra·Pada·RL/NL/SL/SSL 착색 삽입`
6. `06 도수·공동장·선후관절·근접성 확인`
7. `07 행성강도층 전수 삽입`
8. `08 Aspect·Argala·Parivartana·관계망 삽입`
9. `09 Avastha·연소·역행·MKS 등 작동상태 삽입`
10. `10 Arudha·Pada·귀속·가시화·이미지층 삽입`
11. `11 동일 D 내부의 하우스 간 회로 연결`
12. `12 다른 D차트의 지지·충돌·보정 검산`
13. `13 Dasha가 실제 실행권자를 선택`
14. `14 Timing Gate·Transit이 점화 관절을 지정`
15. `15 인과·전달·도착·귀속·보유·회수 경로 조립`
16. `16 병목의 정확한 위치와 손실 원인 확정`
17. `17 조건 변화에 따른 관계 전환과 결과 변화 추적`
18. `18 단기·중단기·장기 결과 분리`
19. `19 모든 층의 모순·누락·과잉해석 전수 검산`
20. `20 하나의 통합 잠금문으로 봉합`

01~14가 15의 입력을 만든다. 16에서 최종 병목을 확정하고 아래 11관절을 실행한 뒤에만 17~20으로 진행한다.

## 16번 내부의 사용자 잠금 11관절

1. 병목 위치 확정
2. 병목 원인·손실경로 확정
3. 뒤집기 가능한 통제변수 추출
4. 뒤집기 관절·조건 확정
5. 병목 뒤집기 실행
6. 누수 차단
7. 동일조건 재투입
8. 재누수·재병목 검산
9. 대체경로 비교
10. 전달·도착·귀속·보유·회수량 재계산
11. BEFORE/AFTER 회수량 증가 증명

Drive 본문의 앞선 10단계 초안보다 현재 사용자가 직접 보완한 `동일조건 재투입` 포함 11단계가 우선한다.

## 단계별 기본 명령 라우팅

아래는 현재 정본에서 확인된 토큰의 기본 라우팅이다. 실제 실행 전 각 토큰의 사용자 정의 원문과 해시를 `COMMAND_REGISTRY`에 잠근다. 정의가 없으면 토큰 이름만 보고 실행하지 않는다.

| 구간 | 기본 명령 토큰 |
|---|---|
| 00A~00C | `SOURCE → PARSE → PATTERN → RANK → SIGNALVSNOISE → DEPENDENCYMAP → CONTEXTUALIZE` |
| 01 | `META → SOURCE → PARSE → CONTEXTUALIZE → LOCK` |
| 02~04 | `SOURCE → PARSE → LAYER → LAYERMAP → VEDICSTRUCTURE → DEPENDENCYMAP → RANK` |
| 05~10 | `SOURCE → PARSE → LAYERBOUNDARY → MECHANISM → TRACE → VERIFY` |
| 11~15 | `DEPENDENCYMAP → MECHANISM → CAUSALCHAIN → TRACE → PAPER3DEEP_STAR` |
| 16 | `DIAGNOSE → ROOTCAUSE → FAILUREMODES → PRECONDITIONMAP → REVERSE → OPTIMIZE → TRACE → RECOMPUTE → VALIDATE` |
| 17~18 | `FRACTAL → DEPENDENCYMAP → TRACE → CONTEXTUALIZE → VALIDATE` |
| 19 | `VALIDATE → VERIFY` |
| 20 | `SYNTHESIZE → LOCK → FORMAT` |

각 단계는 명령을 실제 입력·작동·출력에 연결한다. 명령 이름을 머리말에 나열한 것만으로 실행완료가 아니다.

## 행성 FULL_PACKET

활성 행성은 다음을 한 몸으로 들고 현재 배역에서 작동한다.

`ROLE + SIGN + DEGREE + NAKSHATRA + PADA + HOUSE + HOUSE_OWNERSHIP + RL/NL/SL/SSL + STRENGTH + ASPECT_RECEIVED/GIVEN + CO_PRESENCE + AVASTHA/COMBUST/RETROGRADE/MKS + D_CHART_FUNCTION`

최소 배역은 `HOUSE_OWNER_PLANET`, `HOUSE_PLANET`, `MOVED_OWNER_PLANET`, `DESTINATION_HOUSE_PLANET`, `ASPECT_PLANET`, `CIRCUIT_PLANET`으로 분리한다. 같은 행성이라는 이유로 배역·목적어·권한을 합치지 않는다.

## 문장 폭 결정

문장 폭·범위·경계는 데이터 양이 아니라 다음 순서로 정한다.

`20D 동일 House 랭킹·그룹 → 해당 Rashi 내부 권력관계 → 역학적 좌표 → 문장 폭·범위·경계`

랭킹은 길흉 순위가 아니라 반복도·연결성·실행권·도메인 중요도의 구조적 우선순위다. 강도랭킹과 문장폭랭킹을 합치지 않는다.

## 3결 샘플 권한

사용자가 제공한 D10-H04·D10-H10 `THREE_GRAIN_LOCKS`는 문장결·목관절·경계 검산 샘플이다. 두 묶음의 잠금문은 병목후 11관절이 빠져 있으므로 현재 정본의 완성 잠금문이 아니며 `POST_BOTTLENECK_MISSING / REVISE`다.

- 차트값과 절 개수를 다른 Target에 복사하지 않는다.
- `SOURCE_BOUND_LOCK_SENTENCE_CANDIDATE / USER_APPROVAL_PENDING`을 정본 승인으로 승격하지 않는다.
- 도파민결·심층작동결·심층촘촘결은 같은 Structure Lock을 공유하되 문장 기능을 달리한다.
- 병목후 11관절을 실제 실행하고 17~20과 최종 잔존을 다시 봉합하기 전에는 `FINAL_LOCK`, `COMPLETE`, `FNa98`을 선언하지 않는다.
