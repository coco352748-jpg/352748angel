# 고정 01~20 FNa98 칼끝문장 실행 계약

## 1. 경로 잠금

- `TEMPLATE_ID = FIXED_KNIFE_SENTENCE_01_20_FNA98_V1`
- `TEMPLATE_SHA256 = ef001b7c9ae33638e964217fd59bfb7d895762b34756d8e9eca26d14724aafb0`
- `OPERATION_ROUTE = FIXED_KNIFE_SENTENCE_01_20_PATH`
- 본문 정본은 `fixed-knife-sentence-template-01-20.txt`다.
- 《01》~《20》의 번호·제목·순서·기능과 ending meta 문법을 변경·병합·동적 재배정하지 않는다.
- ending meta의 `INDEX=STRUCTURAL_JOINT_DISCOVERY > ...`는 사용자가 지정한 출력 문자열로 그대로 보존한다. 내부 실행 경로 권한은 `OPERATION_ROUTE=FIXED_KNIFE_SENTENCE_01_20_PATH`와 전용 패킷으로 분리하며, 이 INDEX 문자열만으로 동적 V2의 20 PRIMARY 관절 배정을 호출하지 않는다.
- 이 경로는 `STRUCTURAL_JOINT_DISCOVERY`의 동적 제목형 V2 및 `DEEP_DENSE_240H_COMMON_PATH`의 하위단계형 240H 템플릿과 독립이다.
- V2의 `OLD_FIXED_01_20_CONTENT_ORDER=VOID`와 `OLD_FIXED_01_20_TITLES=VOID_AS_GLOBAL_ORDER`는 V2 동적 배정 안에서만 유효하다. 현재 사용자가 이 고정형 경로를 선택한 경우까지 VOID 처리하지 않는다.

## 2. Source 권한

- `SOURCE_AUTHORITY = GOOGLE_DRIVE_ACTIVE_CANONICAL`
- `CHART_VALUE_MODE = FETCH_FROM_DRIVE`
- `UNVERIFIED_VALUE_GENERATION = FORBIDDEN`
- 현재 사용자가 지정한 Drive Active Canonical의 실제 archive·member·section·field만 차트값 권한을 가진다.
- `$rq-sc7`은 사용자가 현재 Plain Source 공급자로 선택했을 때 해시 검증된 archive/member packet을 제공할 수 있다. `SC_VERIFIED`는 Source 입장과 bytes 정체를 증명하지만 Drive Active Canonical 자동승격이나 Target 적용성 확정은 하지 않는다.
- `rq-sc7` packet을 사용할 때도 `SOURCE_SKILL + SOURCE_SET_ID + ARCHIVE_SET_SHA256 + FAMILY_ID + ARCHIVE_NAME + ARCHIVE_SHA256 + MEMBER_NAME + MEMBER_SHA256 + SECTION_TOKEN + FIELD_KEY + SOURCE_LOCATOR + SOURCE_VALUE`를 역추적한다.
- Spirit Chalit은 현재 D1 전용이다. D2~D60에 복사하거나 native Bhava를 대체하지 않는다.
- Transit은 현재 D1/D9 결합 Source이며 `IMAGE_EXTRACTED / USER_REVIEW_READY / CANONICAL_STATUS_NOT_DECLARED`다. 사용자의 정본 지정 전에는 《14》의 실제 점화·기간 근거로 승격하지 않고 `HOLD`한다.
- Timing Gate는 확인된 Aspect03 선행값 없이 Aspect01·배치·Transit만으로 점화시각을 확정하지 않는다.
- 《05》·《06》에서 Nakshatra·Pada·RL/NL/SL/SSL·정확 도수차·공동장 선후관절이 현재 질문의 주 Target이면 `$rq-nak`의 독립 패킷을 호출한다. 해당 값이 전체 칼끝문장의 보조 착색층일 뿐이면 별도 회로 실행을 강제하지 않고 확인된 Native Source값과 HOLD 경계만 결속한다.
- 나크파다 하위패킷을 호출해도 차트 템플릿 경로와 PASS 범위를 합치지 않는다. 나크파다 패킷은 《05》·《06》에 필요한 Source·회로 Lock만 인계하고 고정 01~20 제목·순서·다른 슬롯 판정을 바꾸지 못한다.

## 3. 실행 순서

```text
00_TARGET_LOCK
→ 01_SOURCE_LOCK
→ 02_SLOT_EVIDENCE_MAP_01_20
→ 03_FIXED_SENTENCE_ASSEMBLY_01_20
→ 04_SENTENCE_REVERSE_MAP
→ 05_FIXED_PACKET_VALIDATION
→ 06_FIXED_OUTPUT_VALIDATION
→ 07_3PASS_FINAL_GATE
```

순서를 바꾸거나 Source/Evidence map 전에 문장을 쓰지 않는다.

### 00 Target Lock

다음을 모두 잠근다.

- `ACTUAL_QUESTION`
- `D_CHART_TAG / D_CHART_DOMAIN`
- `HOUSE_ID / HOUSE_FUNCTION / SOURCE_HOUSE_TOKEN`
- `SOURCE_SCOPE / EXCLUSIONS`
- `OUTPUT_CONTRACT`

필수 Target 값이 없으면 실행하지 않고 `HOLD`한다.

### 01 Source Lock

사용 Source마다 권한·자료·적용·판정 상태를 분리한다.

- 권한: `ACTIVE / VOID`
- 자료: `PARSED / NOT_PARSED / NONE`
- 적용: `APPLICABLE / NOT_APPLICABLE`
- 판정: `CLEAR / CONFLICT / HOLD`
- 근거: `DIRECT_SOURCE / DERIVED / INFERENCE / HOLD`

Rashi, Bhava, strength, relation, operation state, visibility, Dasha, Timing, Transit을 한 층으로 합치지 않는다.
`07_1AB` Native actor material의 Nakshatra·Pada·RL/NL/SL/SSL과 도수는 Native 층으로, `07_14AB` Full Varga 반복은 Cross-D 보정층으로 분리하며 반복을 Native 값이나 강도로 바꾸지 않는다.

### 02 Slot Evidence Map

각 《01》~《20》에 다음을 기록한다.

- `slot_no / fixed_slot_title`
- `required_source_lanes / applicable_source_ids`
- `source_locator / source_value`
- `direct_fact / derived_rule_ref`
- `why_parent / result_boundary`
- `evidence_grade / assertion_state / status / hold_reason`

한 Source family를 모든 슬롯에 억지로 넣지 않는다. 적용되지 않는 슬롯은 `NOT_APPLICABLE`, 자료는 있으나 미파싱이면 `NOT_PARSED`, 필수 근거가 없으면 `HOLD`한다.

### 03 Fixed Sentence Assembly

각 문장은 다음 관절을 Source가 허용하는 범위에서 결속한다.

```text
FORWARD_ANSWER
→ DIRECT_FACT
→ STRUCTURAL_RELATION
→ WHY_MECHANISM
→ AUTHORIZED_CHANGE_OR_INVARIANT
→ RESULT_BOUNDARY
```

고정 제목은 유지하지만 문장값은 Job마다 Source에서 새로 읽는다. 다른 D×House 문장을 placeholder 치환하거나 D10-H10 예시의 값을 복사하지 않는다. 근거가 없는 성공·병목·귀속·보유·회수·시기는 강한 문장으로 만들지 않는다.

### 04 Sentence Reverse Map

각 핵심절은 다음 경로로 역매핑한다.

```text
SLOT_NO + CLAUSE_ID
→ EVIDENCE_ID
→ SOURCE_ID + MEMBER + SECTION + FIELD + LOCATOR + VALUE
→ DIRECT_SOURCE / APPROVED_DERIVED
→ RESULT_BOUNDARY
```

역매핑되지 않는 핵심절은 제거하거나 `HOLD`한다. 사용자에게 역매핑표를 보여줄 필요는 없지만 내부 기록은 필수다.

### 05 Fixed Packet Validation

Source Lock·20슬롯 Evidence·절별 역매핑·나크파다 하위패킷 경계·3PASS 상태를 다음으로 검산한다.

```bash
python3 scripts/validate_fixed_knife_sentence_packet.py <packet.json>
```

전용 패킷은 `TEMPLATE_ID=FIXED_KNIFE_SENTENCE_01_20_FNA98_V1`, `OPERATION_ROUTE=FIXED_KNIFE_SENTENCE_01_20_PATH`, 세 외부경로 dependency `NOT_USED`, Drive Active Canonical Source, 01~20 고정 제목벡터, PASS 슬롯의 Evidence와 reverse map, 출력 artifact hash를 가져야 한다. 필수 Source가 아직 없으면 20슬롯을 근거 없는 문장으로 채우지 않고 명시적 `HOLD_BOUNDARY`, 빈 reverse map, 미생성 output artifact를 가진 `HOLD` 패킷으로 닫을 수 있다. `joint_bank`, 동적 `allocation_01_20`, PIKACHU 실행필드는 금지한다.

### 06 Fixed Output Validation

최종 사람말 파일에 다음을 실행한다.

```bash
python3 scripts/validate_fixed_knife_sentence_output.py <artifact>
```

검증기는 Target 제목, 고정 20개 제목의 정확한 순서, 각 슬롯 본문, 미치환 placeholder, ending meta, 완전 동일 본문 중복을 확인한다. Source 사실과 WHY는 별도 작업패킷·역매핑·3PASS로 검산한다.

### 07 3PASS Final Gate

- PASS 1: Source·권한·Target·Rashi/Bhava·상태축·역매핑
- PASS 2: WHY·인과·비가산·귀속/보유/회수·Timing 경계·20슬롯 고유 기능
- PASS 3: 고정 제목·순서·본문·TITLE/INDEX/STATUS·저장·재열기

`PASS`는 세 관문과 전용 패킷·출력 검증기가 모두 통과할 때만 가능하다. 수정 가능한 결함은 `REVISE`, 필수 Source·권한·역매핑 부족은 `HOLD`다.

## 4. 고정 슬롯 기능

1. 도메인과 질문
2. Rashi Promise와 배역
3. Bhava 도착과 현실 작동장
4. Lord·Occupant·Karaka 독립 의제
5. Nakshatra·Pada·RL/NL/SL/SSL
6. 도수·공동장·선후·근접성
7. 비가산 강도층
8. Aspect·Argala·Parivartana·관계망
9. Avastha·연소·역행·MKS
10. Arudha·Pada·가시화·귀속
11. Target D 12H 가로축
12. 20D 세로축
13. Dasha 실행권자
14. Timing Gate·Transit 점화
15. 인과·전달·도착·귀속·보유·회수
16. 병목·손실 원인
17. 통제변수와 BEFORE/AFTER
18. 기간별 결과
19. 모순·누락·과잉해석 검산
20. 통합 잠금과 미해결 경계

## 5. 금지

- 동적 V2 제목 생성 규칙을 이 경로에 적용
- 고정 제목을 동적 V2의 전역 제목으로 역수출
- `rq-sc7` 내장 존재를 Drive Active Canonical 승인으로 변환
- 나크파다 보조 착색만 있는 일반 Job에 전체 나크파다 회로를 강제하거나 나크파다 하위패킷의 PASS를 전체 20슬롯 PASS로 변환
- Chalit D1 값을 다른 D에 복사하거나 Bhava 대체
- Transit 비정본 상태를 실제 점화·기간 확정으로 변환
- Mini 후보를 Full 반복확정으로 변환
- sign 반복을 house 반복으로, 반복을 강도로, 밀도를 병목으로 변환
- 도착을 귀속으로, 귀속을 소유로, 소유를 보유로 변환
- Source 없는 placeholder 채움·문장 복제·완전 동일 슬롯 본문 재사용
