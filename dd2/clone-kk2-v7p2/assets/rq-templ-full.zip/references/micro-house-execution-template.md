# PIKACHU × SC 미세 마이크로 실행 템플

## 불변 순서

`00A → 00B → 00C → 01 → … → 15 → 16 → POST_01 → … → POST_11 → 17 → 18 → 19 → 20`

`references/pikachu-sc-master-canonical.md`의 명칭과 순서를 그대로 사용한다. 생략·병합·재명명·재배열을 금지한다.

## Target 단위

현재 사용자 지시가 정한 다음 단위마다 전체 순서를 독립 완주한다.

- 한 Rashi
- 한 Bhava
- 한 House
- 한 House×20D
- 한 D-chart의 H01~H12

다섯 탭은 같은 실행계약을 공유하되 서로 다른 Target을 받는다. 동일 Target 복제는 실패다.

## PREMAP_EXECUTION

00A~00C 각각에 다음 필드를 둔다.

- `target_key`
- `stage_no / stage_name`
- `input_refs`
- `command_tokens / command_definition_hashes`
- `selected_value`
- `operation / output`
- `handoff_id / receives_from`
- `evidence_grade / why / status / hold_reason`

00A의 `receives_from=ROOT`, 00B부터는 직전 `handoff_id`를 받아야 한다.

## MASTER_EXECUTION_01_20

01~20 각 단계에 PREMAP과 같은 필드를 둔다. 01은 00C의 인계를 받고, 각 후속 단계는 직전 단계의 인계를 받는다. 단, 17은 16의 인계를 직접 받지 않고 POST_11의 인계를 받는다.

모든 단계의 `command_tokens`는 1개 이상이며 현재 `COMMAND_REGISTRY`에 정의·Source·해시가 있어야 한다. 단계명만 채우거나 명령 이름만 나열하면 실패다.

## PLANET_FULL_PACKET_N

04에서 독립 배역을 분리하고 05~10에서 다음 필드를 같은 행성 패킷에 누적한다.

- role
- sign / degree / nakshatra / pada / house
- house ownership
- RL / NL / SL / SSL
- strength
- aspect received / given
- co-presence relation
- avastha / combustion / retrograde / MKS
- D-chart functional agenda
- Source / evidence grade / authority state
- Source admission (`SC_VERIFIED` 또는 cutoff 이상 provider-native `created_at`)

미공급 층은 `HOLD` 또는 정확한 `NOT_APPLICABLE`로 남기며 일반지식으로 채우지 않는다.

## POST_BOTTLENECK_EXECUTION_01_11

16의 출력이 POST_01로 들어가고 11관절을 순서대로 실행한다. 각 관절에도 동일한 명령·입력·출력·인계·증거·상태 필드를 둔다.

추가 필수값:

- `same_condition_signature_before`
- `same_condition_signature_after`
- `recalculation_ledger`: 전달·도착·귀속·보유·회수
- `before_after_proof`: 기준·단위·BEFORE·AFTER·DELTA·증명상태

동일조건 서명이 다르면 7~11은 `REVISE`. 기준·단위가 없으면 수치 증가를 선언하지 않고 `HOLD`한다.

## 단계 셀 통과조건

각 셀은 다음을 모두 만족해야 `PASS`다.

1. 현재 Target과 Source가 명시됨
2. 실제 입력 Source가 전역 입장 게이트를 통과하고 Source ID로 역매핑됨
3. 사용자 정의 명령의 원문 정의·해시 확인
4. 입력이 직전 인계 또는 명시 Source를 가리킴
5. 실제 선택값과 작동이 기록됨
6. 출력이 다음 단계 입력으로 사용 가능함
7. 근거등급과 WHY 관절이 있음
8. 층위·상태·귀속 점프가 없음

`HOLD`는 빈칸 은폐가 아니라 미확정 이유·해결권한·필요 Source를 기록한다.

## 최종 닫힘

20의 통합 잠금문 뒤에 다음을 따로 남긴다.

- `ACTUAL_FINAL_REMAINDER`
- 회수 후 최종 잔존
- 재투입 가능 자원
- 남은 병목·신규 누수
- 현실 귀속·보유 상태
- 회로 종료 또는 HOLD

하나라도 누락되면 COMPLETE가 아니다.
