# 심층촘촘결 3.25~3.75단계 목관절층 문장 계약

## 기준 Source의 권한

사용자가 제시한 `D10-H04 심층촘촘결 잠금문`은 문장 깊이·구조·경계의 기준 Source다. 해당 원문의 D10-H04 차트값과 28개 절 제목을 다른 Target의 사실 Source나 고정 목차로 복사하지 않는다.

- 기준 기능: 문장 깊이·인과밀도·반례·현실경계·목관절 품질
- 사실 권한: D10-H04 Source 안에서만
- 다른 차트 적용: 문장 원리만 계승
- 현재 상태: 사용자가 별도 승인하기 전 `STYLE_AND_STRUCTURE_REFERENCE`, 차트 정본 승격 금지

## 목관절층의 의미

`3.25~3.75단계 목관절층`은 문장 길이 점수가 아니다. Source 사실과 최종 결론 사이에서 다음이 한 번에 보이는 깊이다.

1. 무엇이 확인된 사실인가
2. 그 사실이 어떤 구조질문을 여는가
3. 어떤 주어가 어떤 처리장·조건·매개를 통과하는가
4. 무엇을 말할 수 없으며 왜 HOLD인가
5. 앞 관절이 다음 관절의 입력이 되는가
6. 병목과 뒤집기 조건이 어디에 있는가
7. 발생·도착·귀속·보유·회수·최종잔존이 분리되는가
8. 마지막 문장이 전체 WHY를 회수하는가

## 절 단위 조립

각 절은 Target에 필요한 만큼 만들되 다음 기능을 닫는다.

- `SECTION_QUESTION`: 이 절이 답할 단일 구조질문
- `DIRECT_SOURCE`: 원자료·상태·권한
- `STRUCTURAL_DERIVATION`: 승인 규칙으로만 결속한 구조도출
- `BOUNDARY`: 금지되는 현실화·층위점프·일반론
- `COUNTEREXAMPLE`: 그럴듯하지만 틀린 해석과 기각 이유
- `DEPENDENCY_HANDOFF`: 다음 절에 넘기는 입력
- `REALITY_STATUS`: 실제 사건·감정·결과의 PASS/HOLD

절 수와 문단 수를 D10-H04 예제와 기계적으로 같게 만들지 않는다. Source 관절이 닫힐 만큼 쓰되, 설명을 늘려 깊이처럼 보이게 하지 않는다.

## 반드시 보존할 분리

- EMPTY ≠ 무기능·약함·부재
- Bhava Begin/Middle ≠ 사건 시간표
- House Lord 소유 ≠ placement ≠ 실제 이동
- placement field ≠ Target identity
- Aspect·pressure ≠ occupancy·arrival·event ignition
- temporary holding for judgment ≠ attribution ≠ ownership
- processing ≠ responsibility ownership
- result occurrence ≠ delivery ≠ arrival ≠ attribution ≠ retention
- return ≠ recovery ≠ retained remainder
- Strength reference ≠ native capacity ≠ event certainty
- Cross-D support ≠ Target Promise
- 존재하는 데이터 ≠ ACTIVE authority ≠ 실제 적용
- 구조후보 ≠ 현실사건

## WHY 목관절

문단을 다음 구조로 결속한다.

`근거→구조질문→원인·조건→매개·처리→상태변화 후보→판정→금지경계→다음 관절`

문장마다 모든 표지를 기계적으로 노출할 필요는 없지만, 독자가 다시 “왜?”를 물어야만 연결되는 핵심관절을 남기지 않는다.

## 해석문 생성 순서

1. D-chart domain과 House question을 잠근다.
2. 공실·단일·공동장을 정확히 분기한다.
3. Rashi body와 Bhava reality field를 분리한다.
4. House Lord Route와 RL/NL/SL/SSL Circuit을 별도 경로로 조립한다.
5. Nakshatra/Pada를 해당 주어의 처리질감으로만 결속한다.
6. Strength·Aspect·Arudha·Dasha·Timing·AVA·Varga의 권한과 미적용 경계를 쓴다.
7. 인과·전달·도착·귀속·보유·누수·회수를 분리한다.
8. 최소 반례로 과잉해석을 기각한다.
9. PIKACHU×SC의 00A~00C·01~20과 병목후 11관절을 내부 실행한다.
10. 전체 구조를 `FINAL_NECK_JOINT`에서 회수한다.

## FINAL_NECK_JOINT

마지막 절은 새 사실을 만들지 않는다. 앞 절에서 검산된 것만 회수하여 다음을 닫는다.

- Target의 본체
- 핵심 운영주체와 처리장
- 원인회로와 의존순서
- 주병목과 뒤집기 조건
- 귀속·회수·최종잔존 경계
- 현실에서 확인해야 할 증거
- 남은 HOLD

## 문장 실패

- Source값 나열 뒤 일반 키워드 결론
- 길이만 늘린 1.5차 문장
- 같은 설명을 표현만 바꿔 반복
- 행성 일반론으로 미공급 작동방식 생성
- 현실사건·감정·조직·관계·시기를 구조값에서 확정
- HOLD를 본문에서 숨기고 STATUS만 PASS
- 예제의 D10-H04 사실·28절을 다른 Target에 치환
- 문장 유창성으로 00A~00C·01~20·단계별 명령·병목후 11관절을 건너뜀
- 병목을 설명한 뒤 통제변수·실행·동일조건 재투입·재검산·회수증명 없이 잠금문 종료

이 실패가 하나라도 있으면 심층촘촘결 잠금문이 아니다.
