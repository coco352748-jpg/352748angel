# 정본·Source·상태 계약

## 0. 전역 Source 입장

권한 순위를 적용하기 전에 `source-admission-gate.md`를 실행한다. 이 스킬에서 사용할 수 있는 Source는 `SC_VERIFIED OR provider-native created_at >= 2026-08-09T00:00:00+09:00`를 만족한 파일뿐이다. 비-SC도 생성시각 분기를 통과하면 허용한다. 두 분기 모두 실패한 자료는 권한이 높아 보여도 본체·Support·명령·예시·스타일 근거로 사용하지 않는다.

## 1. 권한 순서

Target은 다음 순서로 선택한다.

1. 현재 사용자 지시
2. 현재 TARGET·SCOPE
3. 최신 사용자 교정
4. 해당 작업의 ACTIVE_CANONICAL
5. 이전 문맥

Source는 다음 순서로 적용한다.

1. 현재 사용자가 지정한 Source
2. 사용자가 확인한 사실
3. 해당 작업의 ACTIVE_CANONICAL
4. 사용자가 허용한 Support Source
5. 일반지식
6. 추론

사용자 Source 전용 작업에서는 4~6을 사용하지 않는다. Support Source는 본체 Source를 바꾸지 못한다. 인터넷은 최신성·외부 검증이 필요하거나 사용자가 명시한 경우에만 쓴다.

## 2. 독립 상태축

한 줄의 상태값으로 서로 다른 문제를 덮지 않는다.

- 권한 상태: `ACTIVE / VOID`
- 자료 상태: `NONE / NOT_PARSED / PARSED`
- 적용 상태: `APPLICABLE / NOT_APPLICABLE`
- 판정 상태: `CLEAR / CONFLICT / HOLD`
- 작업 상태: `PENDING / REVISE / PASS`
- 입장 상태: `ELIGIBLE / REJECTED / HOLD`

`NONE`은 확인했으며 값이 없음이다. `NOT_PARSED`는 자료가 있지만 아직 구조화하지 않았음이다. `NOT_APPLICABLE`은 현재 Target에 쓰지 않음이다. `CONFLICT`는 권위 Source끼리 충돌함이다. `HOLD`는 판정에 필요한 근거가 부족함이다.

## 3. Canonical 교체

- 최신 교정은 지정된 범위만 바꾼다.
- `LOCAL_CORRECTION`을 전역 정본 변경으로 승격하지 않는다.
- `CANONICAL_CHANGE`는 사용자 명시 승인이 필요하다.
- 정본 교체 뒤 이전 차트값·분석문·파생표·검산본·문장 Lock은 자동 재사용하지 않는다.
- 정본 스키마와 기능은 유지할 수 있으나 고유값은 새 Source에서 다시 읽는다.

## 4. Source Packet 최소 필드

각 Source마다 다음을 기록한다.

- `source_id`
- `name_or_path`
- `authority`: `CURRENT_SPECIFIED / USER_CONFIRMED / ACTIVE_CANONICAL / SUPPORT`
- `authority_state`: `ACTIVE / VOID`
- `material_state`: `PARSED / NOT_PARSED / NONE`
- `read_scope`
- `identity_or_hash`
- `sc_verified`
- `sc_verification_basis`
- `created_at`
- `created_at_source`
- `admission_basis`
- `allowed_uses`
- `prohibited_uses`

입장 통과만으로 `PARSED`나 `ACTIVE_CANONICAL`을 선언하지 않는다. 파일명·폴더명·과거 인용만으로 `PARSED`를 선언하지 않는다.

## 5. Evidence 등급

- `DIRECT_SOURCE`: Source가 직접 제공한 값
- `DERIVED`: 사용자 승인 공식·규칙으로 도출한 값
- `INFERENCE`: 가능한 해석이며 사실이 아님
- `HOLD`: 근거 부족 또는 충돌

각 주요 결론은 Evidence ID를 역추적할 수 있어야 한다. Source에 없는 값·의도·감정·인과를 문장력으로 만들지 않는다.
