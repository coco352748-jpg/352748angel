# Source Router 16형 구조관절 발견·동적 칼끝문장 계약

## 0. V2 정본 잠금

- `TEMPLATE_ID = DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2`
- `TEMPLATE_VERSION = V2_REPAIRED`
- `TEMPLATE_AUTHORITY = ACTIVE_CANONICAL`
- `CANONICAL_SCOPE = RQ_VEDIC_SYSTEM_WIDE_FOR_STRUCTURAL_JOINT_DISCOVERY`
- `CANONICAL_REGISTRY = canonical-registry.md`
- 상세 Source Router 16, True Execution Order, 사람말 형식은 `deep-dense-knife-sentence-template-v2.txt`가 정본이다.
- `d10-h10-calibration-only.txt`는 문장력·WHY·경계·확정성 교정만 허용한다.
- Calibration 예시의 내용 순서, 슬롯 제목, 차트값, 문장뼈대를 다른 Job에 상속하지 않는다.
- 고정 하위단계형 `DEEP_DENSE_LOCK_240H_COMMON_V1`과 이 동적 제목형 V2를 한 패킷에서 병합하지 않는다.
- 사용자 지정 상위 20개 고정 제목형 `FIXED_KNIFE_SENTENCE_01_20_FNA98_V1`도 별도 경로다. V2의 `OLD_FIXED_01_20_* = VOID`는 동적 배정 안의 전역순서 상속만 금지하며, 사용자가 고정 경로를 선택한 작업까지 폐기하지 않는다.

## 1. 독립 모드

- `OPERATION_MODE = STRUCTURAL_JOINT_DISCOVERY`
- `VIEW = SOURCE_ROUTED_SEPARATE_LAYERS`
- `PIKACHU_DEPENDENCY = NOT_USED`
- PIKACHU 정본, 00A~00C, PIKACHU MASTER 01~20, 병목후 11관절은 이 모드의 입력·실행골격·검산항목으로 호출하지 않는다.
- 여기서 `01~20`은 촘촘결의 서로 다른 문장 기능 20개를 뜻한다. 고정 제목을 강요하지 않고 기능·인과·결과의 실제 독립성을 검산한다.

이 모드는 `references/source-admission-gate.md`를 통과하고 현재 작업에서 `ACTIVE / PARSED / APPLICABLE`로 확인된 Source Router 16의 실제값만 사용한다. 구조발견의 선행축은 VARGA FULL·VARGA MINI이며, S01~S11은 일치 관절에만 증거를 결속하고 S14~S16은 외부 실행·시간·작동상태 게이트에만 결속한다. Drive 검색결과의 제목이나 수정일만으로 정본 권한을 부여하지 않는다.

Source 우선순위는 `S01 Rashi base → S02 Bhava arrival → S04 active co-presence field → S03 transfer bridge`다. 이는 병합순서가 아니라 역할·경계 순서다. S15는 Aspect03 선행값이 없으면 점화·기간을 HOLD하고, S16은 확인된 Timing Trigger가 없으면 작동상태를 HOLD한다. Dasha·Timing·AVA는 base structure를 다시 쓰지 못한다.

## 2. Target 잠금

탐색 전에 다음을 모두 확정한다.

- `ACTUAL_QUESTION`
- `TARGET_D_CHART`
- `TARGET_HOUSE`
- `D_CHART_DOMAIN`
- `HOUSE_FUNCTION`

하나라도 확인되지 않으면 관절 수집으로 넘어가지 않는다. 질문 의도와 Target을 과거 파일명·예시·풍부한 Source에 맞춰 바꾸지 않는다.

## 3. 20D 세로축

기본 20D 집합은 다음과 같다.

```text
D1, D9, D2, D3, D4, D5, D6, D7, D8, D10, D11,
D12, D16, D20, D24, D27, D30, D40, D45, D60
```

`D50=VOID`이며 다른 Source가 포함하더라도 실행 집합·대체 Manifest·Job으로 승격하지 않는다. 같은 N하우스를 20D 전체에서 비교하며 각 D를 누락하지 않는다.

20D 세로축은 이 단계에서 한 번만 스캔하고 `VERTICAL_20D_AXIS`로 잠근다. 이후 01~20 배정·문장·검산은 이 Axis ID를 인계받으며 20D 원자료를 슬롯마다 다시 스캔하지 않는다.

다음 분류는 서로 구분해 기록한다.

- `SAME_STRUCTURE`
- `SIMILAR_STRUCTURE`
- `RARE_STRUCTURE`
- `CONCENTRATED_STRUCTURE`
- `CROSS_REPEAT`

한 구조에 복수 표지가 붙을 수 있지만 각 표지의 근거는 독립적으로 남긴다. 빈도만 세어 중요도를 만들지 않는다. 희귀성은 중요도의 증거가 아니고 반복성은 강도의 증거가 아니다. 마지막에 TARGET D-N하우스의 세로축 상대위치·중요도·근거·HOLD를 잠근다.

## 4. TARGET D 가로축

TARGET D의 `H01~H12`를 모두 조사한다. N하우스와 각 하우스의 구조관계를 Source에 역매핑하고, N하우스가 다음 중 무엇을 담당하는지 판정한다.

- `INPUT_POINT`
- `TRANSFER_POINT`
- `BOTTLENECK_POINT`
- `AMPLIFICATION_POINT`
- `TRANSITION_POINT`
- `ATTRIBUTION_POINT`
- `RECOVERY_POINT`

역할은 복수일 수 있으나 각 역할의 입력·전달·결과가 같다고 가정하지 않는다. 마지막에 TARGET D 안에서 N하우스의 가로축 상대위치·중요도·근거·HOLD를 잠근다.

## 5. 최종 구조적 교차점

`20D 세로축 위치 × TARGET D 가로축 위치`를 교차시켜 하나의 `FINAL_STRUCTURAL_CROSSPOINT`를 만든다. 다음을 서로 다른 필드로 판정한다.

- 교차 역할과 구조 중심성
- 관절이 교차점과 닿는 거리·직접성
- 전달 영향과 병목·뒤집기 관련성
- 칼끝문장 세기
- 허용 동사 강도
- 단어 선택
- 확정성
- 문장 폭

모든 관절을 같은 어조로 평준화하지 않는다. 강한 중심은 근거 범위 안에서 강하게, 보조 구조는 보조 수준으로, 조건부 구조는 조건을 보존해, 약한 Source는 약한 확정성으로 쓴다.

## 6. Evidence Registry와 구조관절 은행

Source를 직접 참조하는 핵심값은 먼저 `EVIDENCE_REGISTRY`에 등록한다.

- `evidence_id`
- `source_id / source_locator / source_value`
- `grade = DIRECT_SOURCE / DERIVED`
- `approved_rule_ref`: DERIVED일 때 필수
- `status = PASS`

입장 게이트를 통과하지 않은 Source, `INFERENCE`, 미승인 DERIVED는 실행 Evidence로 등록하지 않는다. 축·교차점·관절·배정·칼끝문장은 이 Evidence ID만 참조한다.

실제 Source에서 비중복 PRIMARY 관절을 최소 20개 탐색한다. 20개가 확인되지 않으면 수를 맞추지 않고 부족분을 `HOLD`한다. 필요할 때 `SUPPORT / RESERVE`를 추가한다.

각 관절은 다음 필드를 모두 가진다.

- `joint_id / joint_signature / tier`
- `source_structure_values`
- `start_point`
- `input_or_pressure`
- `transfers_to_next`
- `structural_centrality`
- `transfer_impact`
- `bottleneck_formation`
- `bottleneck_reversal_potential`
- `result_arrival_location`
- `result_attribution`
- `result_retention`
- `recovery_potential`
- `connections`
- `nonduplication_basis`
- `vertical_rarity_or_repetition`
- `horizontal_importance`
- `crosspoint_distance_directness`
- `evidence_refs / evidence_grade / status / hold_reason`

`DIRECT_SOURCE` 또는 사용자 승인 규칙으로 나온 `DERIVED`만 실행 가능한 관절이다. 근거 없는 인과·강도·의도·감정·결과는 관절로 만들지 않는다.

## 7. 촘촘결 01~20 배정

각 번호에 `PRIMARY`, 필요한 `SUPPORT`, 선택적 `RESERVE` 관절을 배정한다. PASS 번호는 PRIMARY 관절을 하나 이상 가져야 한다. 발견을 끝내기 전에 배정하거나 문장을 먼저 쓰지 않는다. 작성 전에 번호별로 다음 세 질문을 답한다.

- `most_important`: 무엇이 가장 중요한가
- `why_this_joint_owns_stage`: 왜 이 관절이 이 번호를 담당하는가
- `loss_if_omitted`: 이 관절이 빠지면 전체 구조에서 무엇을 잃는가
- `slot_title`: 그 Job의 실제 관절 기능을 드러내는 동적 제목

그리고 `operation_face`를 다음 중 하나로 고정한다.

```text
INPUT, PRESSURE, TRANSFER, BOTTLENECK, REVERSAL,
ARRIVAL, ATTRIBUTION, RETENTION, RECOVERY
```

같은 관절의 반복 사용은 가능하지만 같은 `operation_face`와 같은 기능·인과경로·결과·결론을 표현만 바꾸어 재사용할 수 없다. 각 번호의 `distinctness_signature`에 `function / causal_path / result / conclusion`을 기록한다. 네 값이 모두 같은 두 번호는 중복 실패다.

과거 고정 01~20 내용순서와 제목은 이 모드의 전역 순서가 아니다. D10-H10의 슬롯 순서·제목을 복제하거나 placeholder만 바꾼 배정은 실패다. 20개 제목은 모두 채워져야 하며 같은 Job 안에서 중복되면 안 된다.

## 8. 칼끝문장과 역매핑

각 번호의 칼끝문장은 `FORWARD_ANSWER→DIRECT_FACT→STRUCTURAL_RELATION→WHY_MECHANISM→AUTHORIZED_CHANGE_OR_INVARIANT→RESULT_BOUNDARY`를 Source가 허용하는 범위에서 결속한다. 각 핵심절을 다음에 역매핑한다.

- 사용 관절 ID
- Evidence ID가 역매핑하는 실제 Source ID·위치·값
- `DIRECT_SOURCE / DERIVED`
- Target·세로축·가로축·교차점 연결

각 핵심절 record는 `sentence_no / clause_id / core_clause / joint_id / evidence_id / source_id / archive_name / inner_member_name / source_locator / source_value / evidence_grade / vertical_link / horizontal_link / crosspoint_link / status`를 가진다.

역매핑되지 않는 핵심절은 제외하거나 `HOLD`한다. 고정 절 제목의 문자열 일치가 아니라 실제 기능필드와 Source 연결을 검산한다.

## 9. 비가산 원칙

강도, 권한, 지원, 압력, 빈도, 희귀·반복은 독립축이다. 다음을 금지한다.

- 합계점수·가중점수·평균점수로 축을 병합
- 희귀성으로 중심성 자동 승격
- 반복횟수로 동사 강도 자동 승격
- 한 축의 높은 값으로 다른 축의 VOID·HOLD 상쇄

`combined_total_score = false`와 독립축 목록을 작업패킷에 남긴다.

## 10. 작업패킷과 상태

최소 상위 필드는 다음과 같다.

```text
actual_question
template_id
template_version
template_authority
operation_mode
pikachu_dependency
source_admission_policy
target
source_router_16
source_packet
evidence_registry
vertical_20d_axis
horizontal_target_d_axis
final_structural_crosspoint
joint_bank
primary_shortfall
allocation_01_20
sentence_reverse_map
axis_non_addition_lock
minimum_final_gate
human_output
qa
final_status
```

`PASS`는 `template_id + template_version + template_authority`가 현재 정본 레지스트리와 일치하고, Source Entry, 20D·H01~H12 완전성, 20개 이상 비중복 PRIMARY, 동적 제목을 가진 01~20 배정, 모든 핵심절 역매핑, 비가산 검문이 모두 PASS일 때만 가능하다. PRIMARY가 20개 미만이면 `primary_shortfall.status = HOLD`와 부족 수·이유를 적고 `final_status = HOLD`로 둔다. 패킷은 `python3 scripts/validate_structural_joint_packet.py <packet.json>`으로, 최종 사람말 파일은 `python3 scripts/validate_knife_sentence_v2_output.py <artifact>`로 각각 검증한다.
