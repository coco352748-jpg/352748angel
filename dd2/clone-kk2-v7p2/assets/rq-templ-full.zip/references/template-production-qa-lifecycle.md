# 차트 템플릿 제작·검산 공통 수명주기

## 목적

차트 템플릿의 신규 제작, 수리, 단일 파일 검산, 12H·20D·20D×12H 확장을 같은 실행 순서와 품질 기준으로 반복한다. 이 계약은 공통 제작 껍질이다. PIKACHU 정본 경로, 동적 구조관절 발견 경로, 고정 01~20 칼끝문장 경로, 240H 공용 잠금문 경로의 고유 토폴로지와 검증기를 대체하지 않는다.

개별 차트값, 미승인 해석, 과거 초안은 이 계약에 저장하지 않는다. 매 작업의 실제 Source에서 다시 읽는다.

`DEEP_DENSE_240H_COMMON_PATH`의 본체 정본은 `deep-dense-lock-template-240h.md`다. 그 파일의 《01》~《20》과 모든 하위번호, 특히 《16-01》~《16-11》과 《20-01》~《20-09》의 문구·순서·소속을 그대로 보존한다. `<D_CHART_TAG>`와 `<HOUSE_ID>`만 Job Identity로 치환할 수 있다. 공통 수명주기 패킷 PASS와 별개로 `validate_deep_dense_240h_template.py`를 반드시 통과해야 한다. 이 규칙은 `fixed-knife-sentence-template-01-20.txt`의 상위 20개 고정 제목형 경로를 대체하거나 흡수하지 않는다.

## 0. Scope Firewall

실행 전에 다음을 잠근다.

- `CURRENT_TARGET`: 가장 최근 사용자 지시 하나
- `DELIVERABLE`: 사용자가 받아야 할 완제품 하나
- `IN_SCOPE_REQUIREMENTS`: 사용자 명시사항
- `DIRECT_DEPENDENCY_LINKS`: 빠지면 완제품이 성립하지 않는 직접 의존조건과 연결 근거
- `AUTHORIZED_ACTIONS`: 각 파일 읽기·검색·수정·검산이 완성하는 요구조건 ID
- `AUTO_IMPORT = false`: 이전 미해결작업·다른 계보·보유기능·유지보수·전체정리·추가개선 자동 반입 금지
- `USER_OUTPUT = FINAL_ONLY`: 초안·중간본·수정본·진행보고는 내부 `VOID`
- `STOP_CONDITION`: 산출물 존재·명시조건 충족·마지막 검산 완료 뒤 즉시 종료

필수 새 범위는 사용자 승인을 받은 뒤에만 넣는다. 모든 실행은 `분석·설계 30% 이내 / 완제품 생성 60% 이상 / 마지막 검산 10% 이내`로 배분한다.

## 1. 실행 전 잠금

다음을 먼저 확정한다.

- `ACTUAL_QUESTION`: 지금 사용자가 실제로 요구한 결과
- `CURRENT_TARGET / DELIVERABLE`: 활성 지시 하나와 완제품 하나
- `TARGET`: 제작·수정·검산할 템플릿 또는 파일 family
- `ACTION`: build, repair, validate, expand 중 현재 권한
- `SOURCE_SCOPE`: 사용할 Source와 제외 Source
- `OUTPUT_CONTRACT`: 파일명, 파일 수, 형식, ending meta, ZIP 여부
- `OPERATION_ROUTE`: PIKACHU, STRUCTURAL_JOINT_DISCOVERY, FIXED_KNIFE_SENTENCE_01_20_PATH, DEEP_DENSE_240H_COMMON 또는 현재 승인된 다른 독립 경로

`STRUCTURAL_JOINT_DISCOVERY`에서는 `template_identity`에 `template_id=DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2`, `template_version=V2_REPAIRED`, `template_authority=ACTIVE_CANONICAL`, `canonical_scope=RQ_VEDIC_SYSTEM_WIDE_FOR_STRUCTURAL_JOINT_DISCOVERY`를 기록한다. 이 네 값은 `canonical-registry.md`와 일치해야 한다.

검산 요청은 수정 권한을 만들지 않는다. 작업지시서는 실행 설계도이며 실제 해석문이나 사건화로 확장하지 않는다.

## 2. 공통 제작 순서

### 01 Source Scope

1. `source-admission-gate.md`를 먼저 적용한다.
2. 입장 통과와 권한을 분리한다.
3. `ACTIVE / VOID`, `PARSED / NOT_PARSED / NONE`, `APPLICABLE / NOT_APPLICABLE`, `CLEAR / CONFLICT / HOLD`를 독립 기록한다.
4. 사용 Source와 제외 Source를 모두 적고 제외 이유를 남긴다.
5. 현재 지정 Source와 ACTIVE_CANONICAL이 충돌하면 진행하지 않고 `HOLD`한다.

### 02 File Family

1. 기존 sibling 파일과 사용자가 지정한 파일명 문법을 확인한다.
2. `family_id`, filename pattern, block order, 반복 단위, ending meta를 잠근다.
3. 승인된 기존 family는 block명·순서·ending meta를 보존한다.
4. `1 chart=1 file`이 지정되면 파일 간 병합을 금지한다.

### 03 Stage Role

각 단계가 무엇을 받으며 무엇을 다음 단계로 넘기는지 정한다.

```text
INPUT_REFS → OPERATION → OUTPUT → HANDOFF → EVIDENCE_GRADE → STATUS
```

단계 이름만 두고 입력·출력·인계가 비어 있으면 미실행이다. 승인된 00A~00C·01~20·병목후 11관절 또는 독립 경로 토폴로지를 임의로 합치거나 재명명하지 않는다.

### 04 Input Source

각 block과 placeholder에 다음을 연결한다.

- Source ID와 원문 위치
- 값 종류와 허용 상태
- DIRECT_SOURCE / DERIVED / INFERENCE / HOLD
- 누락 시 NONE / NOT_PARSED / NOT_APPLICABLE / HOLD 처리
- 허용 용도와 금지 용도

값이 없는 placeholder를 문장 유창성으로 채우지 않는다.

### 05 Source Separation

필요한 lane만 활성화하고 서로 덮지 않는다.

- `NATAL_ANCHOR`: D1 또는 사용자가 승인한 기준축
- `TARGET_NATIVE`: 현재 Target D·House·View의 본체값
- `VAS_NATIVE`: 연도·시점 고유값이 있는 작업에서만 사용
- `SUPPORT`: 본체를 바꾸지 않는 보조 근거

각 lane은 `APPLICABLE / NOT_APPLICABLE / HOLD`와 Source ID를 가진다. Rashi/Bhava, 현재/이전, 본체/Support, 사실/추론을 분리한다.

### 06 12H·20D·240 Job 배치

1. 단위 Job을 `ONE_D_CHART × ONE_HOUSE × ONE_VIEW`로 고정한다.
2. 각 D-domain과 House function을 Job마다 새로 잠근다.
3. 12H는 H01~H12를 정확히 한 번씩 사용한다.
4. 기본 20D는 `D1, D9, D2, D3, D4, D5, D6, D7, D8, D10, D11, D12, D16, D20, D24, D27, D30, D40, D45, D60`이다. `D50=VOID`이며 입력·대체·복구·Job 생성이 금지된다.
5. 20D×12H는 정확히 240개 독립 Job으로 다룬다.
6. 동일 Target 중복, 누락, 다른 House 문장 치환, D-domain 평균화를 금지한다.
7. 20D 세로축과 Target D H01~H12 가로축은 선행 좌표지도에서 한 번만 잠근다. `00A~00C` 경로의 실행 블록은 그 좌표지도 ID만 받아 쓰며 20D 스캔을 반복하지 않는다. 다른 독립 경로도 승인된 동등 단계에서 한 번만 계산한다.

### 07 Application Route

선택 경로의 선행조건, 실행순서, 전용 검증기를 잠근다. 둘 이상의 독립 경로가 필요한 경우 패킷과 상태를 분리한다. 한 경로의 정본·관절·검증기를 다른 경로로 끌어오지 않는다.

- 동적 V2: `validate_structural_joint_packet.py` + `validate_knife_sentence_v2_output.py`
- 고정 01~20: `validate_fixed_knife_sentence_packet.py` + `validate_fixed_knife_sentence_output.py`
- 240H 공용 하위단계형: `validate_deep_dense_240h_template.py`

### 08 Template Construction

1. typed placeholder를 사용한다.
2. `EMPTY / SINGLE / MULTI` 분기를 만든다.
3. Missing/HOLD와 금지사항을 본문 구조 안에 둔다.
4. Raw Source block과 해석·문장 block을 분리한다.
5. 파일명, TITLE/INDEX/STATUS 또는 지정 ending meta를 템플릿에 포함한다.
6. 최종 텍스트 구분선은 `━` 정확히 24칸으로 통일하고 지정된 Gray codebox 표면을 보존한다.

### 09 Raw Check

다음을 Source 원문과 직접 대조한다.

- Source 값과 차트 정체
- D-chart 분포와 House 배치
- Rashi/Bhava 경계
- visible / non-visible 경계
- degree order, occupants, lord route 중 현재 적용 필드
- EMPTY / SINGLE / MULTI 판정

Raw Check가 실패하면 문장 품질 검산으로 넘어가지 않는다.

### 10 Link Check

다음을 검산한다.

- 앞 단계 OUTPUT이 다음 단계 INPUT으로 실제 전달되는가
- 모든 주요 결론이 Source ID로 역매핑되는가
- placeholder가 올바른 Source field에 연결되는가
- D-domain과 House function이 끝까지 보존되는가
- 12H·20D·240 Job에 누락·중복·교차오염이 없는가
- 발생·도착·귀속·보유·사용·누수·반환·재투입·잔존을 혼동하지 않았는가

### 11 Single Pilot

새 family 또는 새 문장결은 지정된 한 Target에 실제값을 넣어 먼저 검증한다. 파일럿은 Source, 단계 인계, Raw Check, Link Check, 문장결, 파일 저장까지 포함한다. 검증된 동일 family의 즉시 확장을 사용자가 승인한 경우만 생략하며 근거를 기록한다.

### 12 Validation 3회

- `PASS 1 Source·정체`: 입장, 권한, 차트 정체, Source 분리, 상태축, 원문 역매핑
- `PASS 2 구조·WHY`: 단계 인계, 인과, 경계, 귀속·회수, 비합산, 하우스 고유성
- `PASS 3 형식·납품`: block 순서, 파일명, 파일 수, ending meta, 저장·재열기, ZIP 추출
- 모든 PASS에서 Scope Firewall과 단일 좌표지도 인계가 유지돼야 한다.

수정 가능한 오류는 고친 뒤 세 PASS를 처음부터 다시 실행한다.

### 13 Final Output

1. 요청된 최종 파일만 남긴다.
2. 저장 후 파일을 다시 열어 이름·수량·내용 끝을 확인한다.
3. ZIP이면 목록과 추출 가능성을 확인한다.
4. 사용자 응답은 결과, 파일, 상태를 짧게 낸다.
5. 완제품 하나 외 초안·중간본·수정본·진행보고를 노출하지 않는다.
6. STOP_CONDITION이 충족되면 추가 정리·개선·연계 없이 종료한다.

## 3. 판정

공통 상태는 다음 세 가지다.

- `PASS`: 모든 필수 게이트와 저장 검증 통과
- `REVISE`: Source와 권한은 있으나 수정 가능한 결함 존재
- `HOLD`: 필수 Source·권한·정본·선행 Lock·단위가 없거나 충돌 존재

세부 납품표시는 다음처럼 매핑한다.

- `PASS` → `PASS`
- `PASS_WITH_BOUNDARY_NOTE` → `PASS`, 단 비차단 경계 메모 필수
- `PASS_AFTER_PATCH` → `PASS`, 패치 뒤 3PASS 재실행 증거 필수
- `REVISE_REQUIRED` → `REVISE`, 수정 위치 필수
- `HOLD` → `HOLD`, 부족 근거 또는 충돌 위치 필수

FNa98은 점수가 아니다. Target, Source, 사실, WHY, 조건·예외, 형식, 파일 무결성, 실사용성이 모두 통과한 상태다.

## 4. 공통 패킷 최소 구조

`validate_template_lifecycle_packet.py`에 전달할 JSON은 다음 필드를 가진다.

- `schema_version`
- `scope_firewall`
- `actual_question`, `target`, `action`, `operation_route`
- `template_identity`: `STRUCTURAL_JOINT_DISCOVERY`에서 필수, 다른 경로는 `NOT_APPLICABLE`
- `source_scope`, `file_family`, `stage_roles`, `input_sources`
- `source_separation`, `batch_scope`, `application_route`
- `batch_scope`에는 정확한 20D 목록, `coordinate_map_stage`, `coordinate_scan_count=1`, `downstream_rescan=false`를 포함한다.
- `template_topology`, `raw_check`, `link_check`, `pilot`
- `validation_passes`, `final_output`
- `final_status`, `delivery_disposition`, `holds`, `conflicts`

PASS 패킷은 모든 적용 게이트가 `PASS` 또는 `NOT_APPLICABLE`이고, source lane·Job 수·파일 저장 검증이 서로 일치해야 한다. 이 공통 검증 뒤 선택 경로의 전용 검증기를 별도로 실행한다.

## 5. 금지

- VOID·부적격 Source 재사용
- 개별 차트값을 재사용 절차에 고정
- 작업지시서를 해석문으로 확장
- Source 없는 placeholder 채움
- Rashi/Bhava·본체/Support·서로 다른 강도층 병합
- 한 House·D-chart의 문장을 다른 Job에 치환
- 단계명만 있고 입력·출력·인계가 없는 가짜 실행
- 각 실행 블록에서 20D 좌표 스캔 반복
- 기본 20D에 D50을 넣거나 D5를 누락
- 요구조건과 연결되지 않은 파일 작업·검색·유지보수·추가개선
- 24칸이 아닌 `━` 구분선 사용
- 초안·중간본·수정본·진행보고를 사용자 완제품으로 노출
- 미저장·미재열기 파일에 PASS 선언
- 공통 검증기로 경로별 전용 검증을 생략
