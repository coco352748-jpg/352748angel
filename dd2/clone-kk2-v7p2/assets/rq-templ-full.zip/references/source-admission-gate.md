# 전역 Source 입장 게이트

이 계약은 이 스킬의 모든 모드, 정본, 명령 정의, 본체 Source, Support Source, 과거 예시 및 교차검산 자료에 먼저 적용한다. 권한·최신성·내용 적합성은 이 입장 게이트를 통과한 뒤에만 판정한다.

## 1. 허용식

Source는 다음 두 분기 중 하나 이상을 만족할 때만 사용할 수 있다.

```text
SOURCE_ADMITTED = SC_VERIFIED
               OR CREATED_AT >= 2026-08-09T00:00:00+09:00
```

경계시각은 포함한다. UTC로는 `2026-08-08T15:00:00Z`다.

- `SC_VERIFIED`: 파일명 토큰, 파일 내부 선언 또는 현재 사용자의 명시 확인으로 SC 정체가 검증됨
- `CREATED_AT`: Drive·Library·업로드 제공자 등 원본 저장계층이 제공한 파일 생성시각
- SC가 아니어도 생성시각 분기를 통과하면 사용할 수 있다.
- SC가 검증되면 생성시각이 없거나 경계 이전이어도 SC 분기로 사용할 수 있다.

## 2. SC 검증

다음 중 하나를 증거로 남긴다.

- `SC_FILENAME_TOKEN`: 파일명에서 대소문자를 무시한 독립 `SC` 토큰 또는 `_Sc`, `-SC` 같은 경계 토큰이 확인됨
- `SC_INTERNAL_MARKER`: 파일 내부의 Source class·manifest가 SC를 직접 선언함
- `USER_CONFIRMED_SC`: 현재 사용자가 해당 파일을 SC라고 명시함

검색어 `SC`에 걸렸다는 사실, 본문 어딘가의 임의 부분문자열, 폴더명, 과거 작업자의 추정만으로 SC를 확정하지 않는다.

## 3. 생성시각 검증

- timezone이 포함된 provider-native ISO-8601 `created_at`만 사용한다.
- `modified_at`, `updated_at`, 최근 열람일, 다운로드일, 로컬 복사일, ZIP 해제시각은 생성시각을 대신하지 못한다.
- 로컬 파일의 mtime·ctime을 원본 생성시각으로 승격하지 않는다.
- 비-SC 또는 SC 미확정 Source의 `created_at`이 없거나 출처가 불명확하면 해당 Source를 사용하지 않는다. 그 Source가 필수이면 작업을 `HOLD`한다.
- 새 문서가 옛 문서의 복제본이어도 provider-native 생성시각 분기는 통과할 수 있지만, 내용 권한·현재성·중복은 뒤의 권한 게이트에서 별도로 검산한다.

## 4. Source Packet 필드

작업패킷 상단에는 다음 정책 Lock을 둔다.

```text
source_admission_policy.logic = SC_VERIFIED_OR_CREATED_AT_CUTOFF
source_admission_policy.cutoff = 2026-08-09T00:00:00+09:00
source_admission_policy.cutoff_inclusive = true
source_admission_policy.modified_at_fallback = FORBIDDEN
```

모든 입장 Source에 다음 필드를 기록한다.

- `sc_verified`: boolean
- `sc_verification_basis`: `SC_FILENAME_TOKEN / SC_INTERNAL_MARKER / USER_CONFIRMED_SC / NOT_SC`
- `created_at`: timezone-aware ISO-8601 또는 SC 분기일 때 `null`
- `created_at_source`: 생성시각 제공자와 메타데이터 위치 또는 SC 분기일 때 `null`
- `admission_basis`: `SC_VERIFIED / CREATED_ON_OR_AFTER_2026_08_09_KST`

두 분기를 모두 만족해도 실제 사용한 입장근거 하나를 `admission_basis`에 고정한다. 입장 통과는 `ACTIVE_CANONICAL`, `PARSED`, Target 적용권한을 자동으로 만들지 않는다.

## 5. 실패 처리

- 두 분기 모두 실패: Source 제외
- 제외된 Source가 필수: `HOLD`
- `updated_at`을 `created_at`으로 위장: `REVISE`, 반복 또는 고의 우회면 HARD FAIL
- 입장근거가 다른 Source의 값을 대신 증명: HARD FAIL
- 입장 Source와 결론의 Source ID 역매핑 실패: `REVISE` 또는 근거가 없으면 `HOLD`

전역 검증은 `scripts/source_admission.py`를 공용 게이트로 사용한다. 각 모드의 검증기는 이 게이트를 우회하거나 자체 완화판으로 교체하지 않는다.
