# 3PASS·FNa98 품질 게이트

## 경로 적용 잠금

공통 게이트와 선택 경로 전용 게이트를 분리한다. PIKACHU의 00A~00C·MASTER 01~20·병목후 11관절은 `PIKACHU_CANONICAL_PATH`에서만 필수다. 동적 V2의 Source Router 16·20 PRIMARY·동적 제목은 `STRUCTURAL_JOINT_DISCOVERY`에서만 필수다. 고정 제목·Slot Evidence·고정 패킷은 `FIXED_KNIFE_SENTENCE_01_20_PATH`에서만 필수다. 240H 하위단계 토폴로지는 `DEEP_DENSE_240H_COMMON_PATH`에서만 필수다. 다른 경로의 게이트는 `NOT_APPLICABLE`로 두며 PASS를 막거나 대체하지 않는다.

## 검산 전 Scope Firewall

- 가장 최근 사용자 지시 하나가 `CURRENT_TARGET`으로 잠겼는가
- `DELIVERABLE`이 완제품 하나인가
- 모든 읽기·검색·수정·검산에 현재 요구조건으로 향하는 `AUTHORIZATION_LINK`가 있는가
- 이전 미해결작업·다른 계보·유지보수·전체정리·추가개선이 자동 반입되지 않았는가
- 사용자 출력이 `FINAL_ONLY`이며 STOP_CONDITION 충족 뒤 즉시 종료하는가

하나라도 실패하면 본 실행에 진입하지 않는다.

## PASS 1 — Source·정체 검산

- 실제 사용한 모든 Source가 `SC_VERIFIED OR provider-native created_at >= 2026-08-09T00:00:00+09:00` 입장식을 통과했는가
- 비-SC 날짜 분기의 `created_at` 출처가 확인되며 modified·updated·mtime·복사·ZIP 시각을 대신 쓰지 않았는가
- 명령·관절·문장·스타일 참조가 모두 입장 Source ID로 역매핑되는가
- 현재 지정 Source와 ACTIVE_CANONICAL을 직접 읽었는가
- 현재 작업에 필요한 사용자 정의 명령의 원문 정의·권한·순서를 찾았는가
- `COMMAND_REGISTRY`와 `COMMAND_TO_TEMPLATE_MAP`이 Source 위치까지 추적되는가
- PIKACHU 경로라면 PIKACHU×SC의 00A~00C·01~20·병목후 11관절 명칭·순서·상태문법을 현재 정본에서 직접 읽었는가
- 선택 경로의 모든 관절이 `INPUT_REF→COMMAND→OPERATION→OUTPUT→HANDOFF→EVIDENCE_GRADE→STATUS` 또는 그 경로의 승인된 동등 필드를 갖는가
- 현재 경로에 적용되는 사용자 명령이 실제 실행됐는가
- 모든 사용 Source가 `ACTIVE`이며 `VOID`가 섞이지 않았는가
- D-chart·domain·house·house function·view가 잠겼는가
- Rashi/Bhava, 본체/Support, 사실/파생/추론이 분리됐는가
- 누락 자료가 `NONE / NOT_PARSED / NOT_APPLICABLE / HOLD` 중 정확한 상태인가
- 동적 V2라면 `template_id`, S01~S16 router, 동적 제목 20개, 최소 3게이트, 사람말 artifact가 모두 연결되는가
- 동적 V2라면 `template_version=V2_REPAIRED`, `template_authority=ACTIVE_CANONICAL`, 전역 정본 scope가 `canonical-registry.md`와 일치하는가
- 고정 칼끝문장이라면 Drive Active Canonical, 고정 제목벡터, 20개 Slot Evidence, 절별 reverse map, 고정 패킷·출력 검산이 모두 연결되는가
- 나크파다 하위패킷은 《05》·《06》이 주 Target일 때만 별도 PASS 범위로 연결되고 전체 20슬롯 PASS로 합쳐지지 않았는가

하나라도 불명확하면 본문 생산을 멈추고 Source 위치를 특정해 HOLD한다.

## PASS 2 — 구조·WHY 검산

- Occupant state·degree order·House Lord route가 Source와 일치하는가
- 인과가 단순 병렬·공동 원인·조건·실행자·매개 중 무엇인지 판정했는가
- 결과의 발생·도착·귀속·보유·사용·누수·반환·재투입·최종 잔존을 혼동하지 않았는가
- 서로 다른 강도·권한·지원층을 합산하지 않았는가
- RQ18/RQ10이 실제로 필요한 경로·질문이라면 유효 Lock ID와 hash가 있는가
- 병목 뒤집기·회수 실행이 실제 Target이면 병목 위치 확정 뒤 `POST_BOTTLENECK_RECOVERY_CANONICAL` 11관절이 순서대로 실행됐는가
- 수치 회수량을 요구하고 기준·단위가 있을 때만 동일조건 재투입, 재누수·재병목, 대체경로 비교와 BEFORE/AFTER를 계산했는가
- 중심 결론마다 `DIRECT_SOURCE / DERIVED / INFERENCE / HOLD`가 추적되는가
- 앞 관절 OUTPUT이 다음 관절 INPUT으로 실제 연결되는가
- 심층촘촘결이 사실·구조도출·반례·현실 HOLD·다음 관절·FINAL_NECK_JOINT를 닫는가

문장이 자연스러워도 이 PASS가 실패하면 최종 해석문이 아니다.

## PASS 3 — 형식·파일·납품 검산

- 요청된 block명·순서·길이·문장결·파일명이 보존됐는가
- 1 chart=1 file 등 현재 family 규칙을 지켰는가
- 최종 사람말 파일에 required field·미치환 placeholder·PENDING이 남지 않았는가. 근거경계를 설명하는 명시적 HOLD 문장은 허용하되 빈칸 은폐로 쓰지 않았는가
- 하우스·D-chart 간 복사 치환문과 중복문장이 없는가
- 다섯 탭 분업이면 서로 다른 Target을 각자 전체 실행순서까지 완주했는가
- 기본 20D가 D5 포함·D50 VOID의 정확한 20개이며 좌표 스캔은 선행지도에서 한 번만 실행됐는가
- 파일 수·내용 끝·TITLE/INDEX/STATUS 또는 지정 ending meta가 맞는가
- 모든 `━` 구분선이 정확히 24칸인가
- 완제품 하나만 남고 초안·중간본·수정본·진행보고가 사용자 출력에서 제외됐는가
- 실제 파일 저장·재열기·ZIP 추출 검산이 끝났는가

## FNa98 판정

FNa98은 감상 점수나 자신감 수치가 아니다. 다음 필수 관문이 모두 통과한 상태다.

- TARGET 적합성
- Source 일치와 권한
- 사실 정확성
- WHY와 인과관절
- 조건·예외·귀속·회수 경계
- 형식·파일 무결성
- 사용자 실사용성
- 사용자 정의 명령 일치

적용되지 않는 관문은 `NOT_APPLICABLE`이며 실패로 세지 않는다.

### PASS

필수 관문을 모두 통과하고 원문 대조·검산 실행·파일 저장 증거가 있다.

### REVISE

필요한 Source와 권한은 있으나 수정 가능한 구조·문장·형식·파일 결함이 있다. 수정 위치를 특정하고 내부 수정 후 다시 3PASS한다.

### HOLD

필요 Source·정본 권한·선행 Lock·계산 단위가 없거나 권위 Source 충돌이 남아 있다. 근거가 생길 때까지 해당 결론을 확정하지 않는다.

## HARD FAIL

- 부적격 Source를 본체·Support·명령·문장근거로 실제 사용
- `modified_at / updated_at / mtime / ctime / 복사·다운로드·ZIP 시각`을 생성시각으로 대체
- 비-SC의 생성시각 미확인 상태에서 PASS 선언
- Source 없는 값 생성
- 정의 없는 명령 실행·임의 기능 추가·순서 변경
- 최신 PIKACHU×SC의 20단계를 과거 19층이나 임의 단계수로 교체
- 00A~00C·01~20 또는 병목후 11관절의 명령 누락·정의 미확인·이름만 배치
- 병목을 진단한 문장만 있고 통제변수→뒤집기→누수차단→동일조건 재투입→재검산→회수증명이 빠짐
- 미세 실행관절 생략·합침·빈칸 은폐·키워드 나열로 대체
- Target 이동
- 사용자 값 덮어쓰기
- VOID 재사용
- 사실과 추론 혼합
- 정본 무단 승격·해제·변경
- 미검증 상태에서 COMPLETE·FINAL·FNa98 선언
- 현재 완제품과 직접 연결되지 않은 작업의 자동 반입
- 20D 좌표 스캔을 각 `ONE_D×ONE_H` 실행 블록에서 반복
- D50을 기본 20D에 넣거나 D5를 누락
- 24칸이 아닌 `━` 구분선으로 최종 템플릿 납품

HARD FAIL을 발견하면 해당 산출물을 최종본으로 납품하지 말고 Source부터 다시 만든다.
