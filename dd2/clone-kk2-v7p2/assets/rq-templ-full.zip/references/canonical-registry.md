# RQ VeDic 템플릿 정본 레지스트리

## 전체 20D 구성 잠금

- `LOCK_ID = RQ_VEDIC_GLOBAL_20D_D50_VOID_V1`
- `ACTIVE_20D_ORDER = D1,D9,D2,D3,D4,D5,D6,D7,D8,D10,D11,D12,D16,D20,D24,D27,D30,D40,D45,D60`
- `ACTIVE_20D_COUNT = 20`
- `D50_STATUS = VOID`
- `D50_IMPORT_RESTORE_REPLACE_GENERATE = PROHIBITED`
- `JOB_TOPOLOGY = 20D×12H=240_INDEPENDENT_JOBS`

이 잠금은 아래 템플릿 경로 전부에 공통 적용한다. 경로별 Source 권한과 토폴로지는 분리하되,
D50을 대체 Manifest·Target·복구 후보로 다시 넣을 수 없다.

## STRUCTURAL_JOINT_DISCOVERY

- `REGISTRY_ID = RQ_VEDIC_TEMPLATE_CANONICAL_REGISTRY_V1`
- `OPERATION_ROUTE = STRUCTURAL_JOINT_DISCOVERY`
- `ACTIVE_CANONICAL_ALIAS = STRUCTURAL_JOINT_DISCOVERY_ACTIVE_TEMPLATE`
- `TEMPLATE_ID = DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2`
- `TEMPLATE_VERSION = V2_REPAIRED`
- `CANONICAL_STATUS = ACTIVE_CANONICAL`
- `AUTHORITY_STATE = ACTIVE`
- `CANONICAL_SCOPE = RQ_VEDIC_SYSTEM_WIDE_FOR_STRUCTURAL_JOINT_DISCOVERY`
- `CANONICAL_PATH = references/deep-dense-knife-sentence-template-v2.txt`
- `APPROVAL_BASIS = CURRENT_USER_EXPLICIT_CANONICAL_CHANGE`
- `APPROVED_AT = 2026-08-11 Asia/Seoul`
- `MATERIAL_STATE = PARSED`
- `APPLICABILITY_STATE = APPLICABLE_TO_STRUCTURAL_JOINT_DISCOVERY_ONLY`
- `SOURCE_ADMISSION_STATE = NOT_APPLICABLE_INTERNAL_TEMPLATE_SCHEMA`
- `UNLOCK_OR_REPLACEMENT_AUTHORITY = USER_ONLY`

## 경로 분리

- `PIKACHU_CANONICAL_PATH`는 자체 정본을 유지하며 이 V2가 대체·흡수하지 않는다.
- `FIXED_KNIFE_SENTENCE_01_20_PATH`는 자체 고정 제목형 정본을 유지한다.
- `DEEP_DENSE_240H_COMMON_PATH`는 자체 하위단계형 정본을 유지한다.
- `d10-h10-calibration-only.txt`는 문장력 교정용이며 정본 본문·슬롯·값을 공급하지 않는다.
- 정본 선택은 `operation_route + template_id + template_version + template_authority`로만 수행한다. INDEX 문자열만으로 선택하지 않는다.

## VOID 경계

- `DDCHART_Mj01_FNa98_R4_P01.txt`부터 `DDCHART_Mj01_FNa98_R4_P04.txt`까지의 네 파일, 그 안의 R4 오케스트레이션·내장 R3 복사본, 그리고 그 파일들에서 파생된 판정·해석·메타정보는 `VOID`다.
- 위 네 파일과 파생물은 검색·참조·병합·복구·템플 입력·정본 영향·정본 승격에 사용하지 않는다.
- 이 VOID는 위 R4 파일 안의 내장복사본 범위이며, 별도 권한으로 존재하는 독립 R3 정본의 상태를 자동 변경하지 않는다.

## 실행 검문

- 구조관절 작업패킷은 `template_authority=ACTIVE_CANONICAL`과 `template_version=V2_REPAIRED`를 가져야 한다.
- 템플릿 제작·수리·확장 패킷은 동일한 `template_identity`를 가져야 한다.
- 실제 차트 Source는 이 내부 템플 정본과 별개로 Source 입장·권한·Target 적용 검문을 통과해야 한다.
