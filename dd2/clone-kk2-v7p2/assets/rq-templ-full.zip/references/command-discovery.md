# 사용자 정의 명령 탐색·실행 계약

## 목적

명령을 일반 AI 용어로 해석하지 않고 사용자가 정의한 기능·권한·순서 그대로 실행한다. 명령은 현재 질문을 해결하는 기능이며 Target을 바꾸는 권한이 아니다.

## 탐색 순서

1. 후보 파일에 `source-admission-gate.md`를 적용하고 입장 실패 파일을 명령 후보에서도 제외한다.
2. 현재 사용자 요청에서 명령 토큰과 정확한 철자를 추출한다.
3. 사용자가 현재 지정한 입장 Source와 파일에서 같은 토큰의 정의를 검색한다.
4. 현재 프로젝트의 ACTIVE_CANONICAL 명령 레지스트리·정본 스키마·선행 Handoff를 검색한다.
5. 현재 Source가 One/Zip 등 복수 저장 경로로 나뉘고 사용자가 둘 다 보라고 했으면 양쪽을 전수 확인한다.
6. 최신 사용자 교정이 있으면 지정 범위에만 적용한다.
7. 이전 문맥의 정의는 전역 입장식과 현재 Source를 모두 통과할 때만 보조한다.

파일명이나 명령 이름만으로 기능을 추정하지 않는다. 정의 본문과 적용 조건을 직접 읽는다.
`COMMAND_REGISTRY.source_id`는 입장 통과한 `SOURCE_PACKET.source_id`를 가리켜야 한다.

## COMMAND_REGISTRY 필드

각 명령마다 다음을 기록한다.

- `command_token`
- `canonical_definition`
- `authority_state`: `ACTIVE / VOID`
- `scope`
- `inputs`
- `outputs`
- `preconditions`
- `execution_order`
- `allowed_combinations`
- `conflicts`
- `prohibitions`
- `hold_conditions`
- `source_id`
- `source_location`
- `definition_hash`

## 실행 규칙

- 현재 질문에 필요한 명령만 선택한다.
- 여러 명령을 결합할 때 각 명령의 권한과 선후관계를 보존한다.
- 현재 사용자 지시와 명령이 충돌하면 현재 지시를 우선한다.
- 프로젝트 전용 명령을 다른 프로젝트나 일반 질문에 자동 적용하지 않는다.
- 명령 정의가 없으면 `COMMAND_DEFINITION_HOLD`로 두고 필요한 정의의 위치만 요청한다.
- `LOCAL_CORRECTION`은 지정 명령·필드만 바꾸며 전체 레지스트리 개정으로 승격하지 않는다.
- 사용자가 `VOID`한 명령은 이름이 다시 보여도 재활성화하지 않는다.

## 템플릿 연결

템플릿을 만들기 전에 각 block이 어떤 명령의 어떤 출력 필드를 받는지 연결한다. `COMMAND_TO_TEMPLATE_MAP`에는 다음을 기록한다.

- `command_token`
- `template_block`
- `input_source`
- `output_field`
- `execution_position`
- `failure_state`

명령 결과가 없는 block을 문장력이나 placeholder 추정으로 채우지 않는다. 명령 순서가 바뀌면 결과가 달라지는 family는 순서를 불변값으로 잠근다.

## 전 관절 명령 강제

PIKACHU×SC의 00A~00C·01~20·병목후 11관절 각각에 `STAGE_COMMAND_LOCK`을 만든다.

- `target_key`
- `stage_no / stage_name`
- `command_tokens`
- `command_definition_hashes`
- `command_scope`
- `command_order`
- `command_input`
- `command_output`
- `failure_state`
- `handoff_id`

모든 관절의 `command_tokens`는 1개 이상이어야 한다. 명령을 실제 입력·작동·출력에 연결하지 않고 이름만 붙이는 것을 금지한다.

현재 정본의 기본 라우팅은 `pikachu-sc-master-canonical.md`를 따른다. 각 토큰은 `SOURCE`, `PARSE`, `PATTERN`, `RANK`, `SIGNALVSNOISE`, `DEPENDENCYMAP`, `CONTEXTUALIZE`, `META`, `LAYER`, `LAYERMAP`, `LAYERBOUNDARY`, `VEDICSTRUCTURE`, `PARETO`, `MECHANISM`, `CAUSALCHAIN`, `TRACE`, `DIAGNOSE`, `ROOTCAUSE`, `PAPER3DEEP_STAR`, `FAILUREMODES`, `PRECONDITIONMAP`, `REVERSE`, `OPTIMIZE`, `RECOMPUTE`, `VALIDATE`, `VERIFY`, `FRACTAL`, `SYNTHESIZE`, `LOCK`, `FORMAT`의 사용자 정의 원문을 확인한 뒤에만 사용한다.

명령사전에서 자주 보이는 토큰이 있더라도 현재 ACTIVE 원문 정의를 읽기 전에는 기능을 부여하지 않는다. `/AUTOPROMPT`, `SELFREFINE`, `ELIVedic`, `/FORMAL`과 구조·전제·병목·검산 계열 명령도 이름만으로 자동 활성화하지 않는다.
