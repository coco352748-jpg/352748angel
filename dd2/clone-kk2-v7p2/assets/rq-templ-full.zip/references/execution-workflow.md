# 제작·분석·해석 실행 계약

## 작업패킷

실행 전에 JSON 또는 동등한 구조로 다음을 고정한다.

- 질문: `actual_question`, `action`, `operation_mode`
- 명령: `command_registry`, `command_to_template_map`
- 정본 실행: `premap_execution`, `master_execution_01_20`, `stage_command_locks`, `post_bottleneck_execution_01_11`
- 분업: `worker_matrix`
- Target: `d_chart`, `d_chart_domain`, `house_id`, `house_function`, `view`
- 범위: `scope`, `exclusions`, `output_contract`, `format_contract`
- Source: `source_packet`, `active_canonical_id`
- Source admission: `source_admission_policy`, 각 Source의 `sc_verified / created_at / admission_basis`
- 상태: `state_axes`, `conflicts`, `holds`
- 검산: `pilot`, `locks`, `qa`, `final_status`

## A. 템플릿 제작

1. 모든 후보 파일에 전역 Source 입장 게이트를 적용하고 통과 Source만 `SOURCE_PACKET`에 넣는다.
2. 현재 작업에 필요한 사용자 정의 명령을 찾아 `COMMAND_REGISTRY`를 잠근다.
3. 명령별 출력과 템플릿 block을 `COMMAND_TO_TEMPLATE_MAP`으로 연결한다.
4. 최신 PIKACHU×SC 정본에서 00A~00C·01~20·병목후 11관절의 명칭·필드·상태문법을 읽어 실행 카탈로그를 만든다.
5. 사용자 파일명 family와 기존 sibling 파일을 확인한다.
6. Source 역할을 본체·보조·압력·강도·상태·시간·가시화·귀속으로 나눈다.
7. `R / A / D1 / Target / INDEX` 구조와 선행 Handoff를 확정한다.
8. block명·순서·반복단위·ending meta를 확정한다.
9. placeholder마다 값 종류, 허용 상태, Source 필드, 누락 처리법을 지정한다.
10. `EMPTY / SINGLE / MULTI` 분기를 만든다.
11. Rashi/Bhava와 D1/Target 적용 경계를 문장으로 명시한다.
12. Missing/HOLD와 금지사항을 템플릿 안에 넣는다.
13. 지정된 한 Target에 실제 입장 Source값을 넣어 전 관절의 명령·입력·출력·인계·빈칸·충돌·중복을 검산한다.
14. 파일럿 PASS 뒤 전체 family를 확장한다.

템플릿은 설명서가 아니라 실제 값을 손실 없이 받아 최종 산출물을 만들 수 있는 실행 구조여야 한다.

## B. 구조 분석

1. 00A VargaMini→00B VargaFull→00C Link Map으로 20D 동일 House의 선행 좌표를 만든다.
2. 01에서 Domain과 질문, 역학적 좌표, 문장 폭·범위·경계를 잠근다.
3. 02~03에서 Rashi Promise와 Bhava 현실 작동장을 분리한다.
4. 04~10에서 행성 배역과 FULL_PACKET, 도수·공동장·강도·관계·상태·가시화를 누적한다.
5. 11~14에서 동일 D·다른 D·Dasha·Timing의 실행권과 점화를 검문한다.
6. 15에서 인과→전달→도착→귀속→보유→회수 경로를 조립한다.
7. 16에서 최종 병목을 확정하고 `POST_BOTTLENECK_RECOVERY_CANONICAL` 11관절을 전부 실행한다.
8. 동일조건 재투입·재누수·재병목·대체경로를 거친 뒤 회수량을 재계산하고 BEFORE/AFTER 증가를 증명한다.
9. 17~20에서 조건변화·시간결과·전층 검산·통합 잠금문을 다시 봉합한다.
10. `ACTUAL_FINAL_REMAINDER`, `EVIDENCE_MAP`, `MERGED_STRUCTURE_LOCK`을 확정한다.

구조관절은 `뜻+행성+조언`의 나열이 아니다. `근거→원인·조건→매개→작동→변화→판정→결과`를 실제 Source 역할로 연결한다.

## C. 해석문·분석문

1. 문단마다 대표 주어와 Target field를 하나씩 고정한다.
2. 결론 바로 뒤에 그 결론을 만든 WHY 관절을 붙인다.
3. 현실 발현과 왜곡 발현을 Source가 허용할 때만 분리한다.
4. Domain의 의미를 일반 D1 현실로 바꾸지 않는다.
5. 하우스별 고유값·경로·병목·잔존을 문장 안에 남긴다.
6. 같은 정보는 중복하지 않되, 인과에 필요한 관절은 삭제하지 않는다.
7. 일반 독자가 읽을 수 있는 자연스러운 한국어로 번역하되 강도·조건·예외를 줄이지 않는다.
8. 심층촘촘결이면 `deep-dense-writing-contract.md`의 절 단위 구조와 FINAL_NECK_JOINT를 실행한다.

## D. 배치 확장

- Pilot Lock과 동일 family hash를 사용한다.
- `H01~H12`를 각각 독립 주어로 다시 잡는다.
- 20D는 각 D-domain을 먼저 번역한 후 하우스 기능을 결속한다.
- 작업자 분할 시 Source Packet·Structure Lock·RQ18/RQ10 Lock을 공유한다.
- 병목 이후 작업이면 `POST_BOTTLENECK_RECOVERY_LOCK`도 공유한다.
- 각 작업자는 서로 다른 Target을 받고 자기 Target의 00A~00C·01~20·병목후 11관절을 독립 완주한다.
- 다섯 탭은 같은 Target을 복제하지 않는다.
- 문장 작업자는 새 구조를 만들지 않는다.
- 병합 뒤 누락·중복·교차오염·치환문·file count를 전수 검산한다.

## E. 납품

- 사용자가 요청한 최종 파일만 제공한다.
- 파일 존재·저장 내용·이름·수량·ending meta를 다시 읽어 확인한다.
- ZIP이면 압축 목록과 실제 추출 가능성을 확인한다.
- 사용자 응답에는 결과·상태·파일 링크를 짧게 남긴다.
