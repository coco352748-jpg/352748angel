#!/usr/bin/env python3
"""Validate only the fixed heading topology of the 240-house deep-dense template."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


CANONICAL = Path(__file__).resolve().parent.parent / "references" / "deep-dense-lock-template-240h.md"
TITLE_RE = re.compile(r"^《(?P<d>D(?:[1-9]|[1-5][0-9]|60)|<D_CHART_TAG>)-(?P<h>H(?:0[1-9]|1[0-2])|<HOUSE_ID>) 심층촘촘결 잠금문》$")
NUMBERED_RE = re.compile(r"^《(?:0[1-9]|1[0-9]|20)(?:-(?:0[1-9]|1[01]))?》 .+$")
D_CHARTS = {
    "D1", "D9", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D10",
    "D11", "D12", "D16", "D20", "D24", "D27", "D30", "D40", "D45", "D60",
}
DIVIDER_LINE = "━" * 24


def extract_heading_tokens(text: str) -> list[str]:
    tokens: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if TITLE_RE.fullmatch(line) or NUMBERED_RE.fullmatch(line):
            tokens.append(line)
    return tokens


def expected_for(candidate_tokens: list[str], canonical_tokens: list[str]) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    if not candidate_tokens:
        return [], ["no deep-dense template headings found"]
    match = TITLE_RE.fullmatch(candidate_tokens[0])
    if match is None:
        return [], ["first heading must be the D-chart/house lock title"]
    d_chart = match.group("d")
    house_id = match.group("h")
    if (d_chart == "<D_CHART_TAG>") != (house_id == "<HOUSE_ID>"):
        errors.append("title must use both placeholders or one concrete D-chart/house pair")
    if d_chart != "<D_CHART_TAG>" and d_chart not in D_CHARTS:
        errors.append(f"unsupported D chart: {d_chart}")
    expected = [
        token.replace("<D_CHART_TAG>", d_chart).replace("<HOUSE_ID>", house_id)
        for token in canonical_tokens
    ]
    return expected, errors


def validate(candidate: Path) -> list[str]:
    try:
        canonical_text = CANONICAL.read_text(encoding="utf-8")
        candidate_text = candidate.read_text(encoding="utf-8")
    except OSError as exc:
        return [f"cannot read template: {exc}"]

    canonical_tokens = extract_heading_tokens(canonical_text)
    candidate_tokens = extract_heading_tokens(candidate_text)
    expected, errors = expected_for(candidate_tokens, canonical_tokens)
    if errors:
        return errors
    divider_lines = [
        line for line in candidate_text.splitlines() if line and set(line) == {"━"}
    ]
    if len(divider_lines) < 3:
        errors.append("expected at least three divider lines")
    for index, line in enumerate(divider_lines, start=1):
        if line != DIVIDER_LINE:
            errors.append(f"divider line {index} must contain exactly 24 ━ characters")
    if len(candidate_tokens) != len(expected):
        errors.append(
            f"heading count changed: expected {len(expected)}, got {len(candidate_tokens)}"
        )
    for idx, (actual, required) in enumerate(zip(candidate_tokens, expected), start=1):
        if actual != required:
            errors.append(
                f"heading {idx} changed or moved: expected {required!r}, got {actual!r}"
            )
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("candidate", type=Path, help="Template or filled lock document")
    args = parser.parse_args()
    errors = validate(args.candidate)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS: template structure only; Source-value validation NOT_APPLICABLE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
