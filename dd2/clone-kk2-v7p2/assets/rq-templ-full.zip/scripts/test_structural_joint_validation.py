#!/usr/bin/env python3
"""Regression tests for Source admission and structural-joint validation."""

from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from source_admission import validate_source_admission
from validate_deep_dense_240h_template import (
    CANONICAL as DEEP_DENSE_CANONICAL,
    validate as validate_deep_dense_template,
)
from validate_structural_joint_packet import DEFAULT_20D, HOUSES, QA_GATES, validate
from validate_structural_joint_packet import ROUTER_LANES


CUTOFF_KST = "2026-08-09T00:00:00+09:00"
OPERATION_FACES = [
    "INPUT",
    "PRESSURE",
    "TRANSFER",
    "BOTTLENECK",
    "REVERSAL",
    "ARRIVAL",
    "ATTRIBUTION",
    "RETENTION",
    "RECOVERY",
]


def make_source(
    source_id: str,
    source_role: str,
    *,
    sc_verified: bool = True,
    sc_verification_basis: str = "SC_FILENAME_TOKEN",
    created_at: str | None = "2026-08-08T23:59:59+09:00",
    created_at_source: str | None = "Drive.createdTime",
    admission_basis: str = "SC_VERIFIED",
) -> dict[str, Any]:
    name = f"{source_role.lower()}_Sc.json" if sc_verified else f"{source_role.lower()}.json"
    return {
        "source_id": source_id,
        "source_role": source_role,
        "name_or_path": name,
        "authority": "CURRENT_SPECIFIED",
        "authority_state": "ACTIVE",
        "material_state": "PARSED",
        "read_scope": "FULL",
        "identity_or_hash": f"sha256:{source_id.lower()}",
        "allowed_uses": ["STRUCTURAL_JOINT_DISCOVERY"],
        "prohibited_uses": ["PIKACHU"],
        "sc_verified": sc_verified,
        "sc_verification_basis": sc_verification_basis,
        "created_at": created_at,
        "created_at_source": created_at_source,
        "admission_basis": admission_basis,
    }


def make_joint(number: int) -> dict[str, Any]:
    joint_id = f"J{number:02d}"
    return {
        "joint_id": joint_id,
        "joint_signature": f"unique structural signature {number:02d}",
        "tier": "PRIMARY",
        "source_structure_values": {"value": f"source-value-{number:02d}"},
        "start_point": f"start-{number:02d}",
        "input_or_pressure": f"input-{number:02d}",
        "transfers_to_next": f"transfer-{number:02d}",
        "structural_centrality": f"centrality-{number:02d}",
        "transfer_impact": f"impact-{number:02d}",
        "bottleneck_formation": f"bottleneck-{number:02d}",
        "bottleneck_reversal_potential": f"reversal-{number:02d}",
        "result_arrival_location": f"arrival-{number:02d}",
        "result_attribution": f"attribution-{number:02d}",
        "result_retention": f"retention-{number:02d}",
        "recovery_potential": f"recovery-{number:02d}",
        "connections": [f"connection-{number:02d}"],
        "nonduplication_basis": f"basis-{number:02d}",
        "vertical_rarity_or_repetition": f"vertical-{number:02d}",
        "horizontal_importance": f"horizontal-{number:02d}",
        "crosspoint_distance_directness": f"distance-{number:02d}",
        "evidence_refs": ["E_FULL"],
        "evidence_grade": "DIRECT_SOURCE",
        "status": "PASS",
        "hold_reason": "",
    }


def make_allocation(number: int) -> dict[str, Any]:
    stage_no = f"{number:02d}"
    return {
        "stage_no": stage_no,
        "slot_title": f"discovered-joint-title-{stage_no}",
        "stage_function": f"function-{stage_no}",
        "stage_question": f"question-{stage_no}",
        "primary_joint_ids": [f"J{number:02d}"],
        "support_joint_ids": [],
        "reserve_joint_ids": [],
        "operation_face": OPERATION_FACES[(number - 1) % len(OPERATION_FACES)],
        "most_important": f"important-{stage_no}",
        "why_this_joint_owns_stage": f"ownership-{stage_no}",
        "loss_if_omitted": f"loss-{stage_no}",
        "distinctness_signature": {
            "function": f"distinct-function-{stage_no}",
            "causal_path": f"distinct-path-{stage_no}",
            "result": f"distinct-result-{stage_no}",
            "conclusion": f"distinct-conclusion-{stage_no}",
        },
        "wording_level": "STRONG",
        "evidence_refs": ["E_FULL"],
        "status": "PASS",
        "hold_reason": "",
    }


def make_reverse_map(number: int) -> dict[str, Any]:
    stage_no = f"{number:02d}"
    return {
        "stage_no": stage_no,
        "knife_sentence_core": f"knife-core-{stage_no}",
        "core_clauses": [f"clause-{stage_no}"],
        "clause_records": [{
            "sentence_no": stage_no,
            "clause_id": f"C-{stage_no}-01",
            "core_clause": f"clause-{stage_no}",
            "joint_id": f"J{number:02d}",
            "evidence_id": "E_FULL",
            "source_id": "SRC_FULL",
            "archive_name": "varga_full_Sc.zip",
            "inner_member_name": "D9_varga_full.txt",
            "source_locator": "full:1",
            "source_value": "full-value",
            "evidence_grade": "DIRECT_SOURCE",
            "vertical_link": f"vertical-{stage_no}",
            "horizontal_link": f"horizontal-{stage_no}",
            "crosspoint_link": f"crosspoint-{stage_no}",
            "status": "PASS",
        }],
        "joint_ids": [f"J{number:02d}"],
        "evidence_refs": ["E_FULL"],
        "evidence_grade": "DIRECT_SOURCE",
        "mapping_status": "PASS",
        "hold_reason": "",
    }


def make_valid_packet() -> dict[str, Any]:
    full_source = make_source("SRC_FULL", "VARGA_FULL")
    mini_source = make_source(
        "SRC_MINI",
        "VARGA_MINI",
        sc_verified=False,
        sc_verification_basis="NOT_SC",
        created_at=CUTOFF_KST,
        admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
    )

    comparison_by_d = [
        {
            "d_chart": d_chart,
            "house_id": "H05",
            "structural_signature": f"vertical-signature-{d_chart}",
            "classification_tags": ["SAME_STRUCTURE"],
            "evidence_refs": ["E_FULL"],
            "status": "PASS",
            "hold_reason": "",
        }
        for d_chart in DEFAULT_20D
    ]
    classification_summary = {
        "same_structure": {
            "members": list(DEFAULT_20D),
            "evidence_refs": ["E_FULL"],
            "status": "PASS",
            "hold_reason": "",
        },
        "similar_structure": {
            "members": [],
            "evidence_refs": [],
            "status": "PASS",
            "hold_reason": "",
        },
        "rare_structure": {
            "members": [],
            "evidence_refs": [],
            "status": "PASS",
            "hold_reason": "",
        },
        "concentrated_structure": {
            "members": [],
            "evidence_refs": [],
            "status": "PASS",
            "hold_reason": "",
        },
        "cross_repeat": {
            "members": [],
            "evidence_refs": [],
            "status": "PASS",
            "hold_reason": "",
        },
    }
    horizontal_houses = [
        {
            "house_id": house_id,
            "relation_to_target": f"relation-{house_id}",
            "role_codes": ["TRANSFER_POINT"],
            "input_or_pressure": f"input-{house_id}",
            "handoff": f"handoff-{house_id}",
            "structural_effect": f"effect-{house_id}",
            "evidence_refs": ["E_MINI"],
            "status": "PASS",
            "hold_reason": "",
        }
        for house_id in HOUSES
    ]

    router_lanes = []
    for lane_id in ROUTER_LANES:
        if lane_id == "S12_VARGA_MINI":
            source_ids = ["SRC_MINI"]
            status = "PASS"
            material_state = "PARSED"
            applicability_state = "APPLICABLE"
        elif lane_id == "S13_VARGA_FULL":
            source_ids = ["SRC_FULL"]
            status = "PASS"
            material_state = "PARSED"
            applicability_state = "APPLICABLE"
        else:
            source_ids = []
            status = "NOT_APPLICABLE"
            material_state = "NONE"
            applicability_state = "NOT_APPLICABLE"
        router_lanes.append({
            "lane_id": lane_id,
            "source_ids": source_ids,
            "material_state": material_state,
            "applicability_state": applicability_state,
            "status": status,
            "hold_reason": "",
        })

    allocations = [make_allocation(number) for number in range(1, 21)]

    return {
        "schema_version": "1.0",
        "actual_question": "Discover the structural joints for D9 H05.",
        "template_id": "DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2",
        "template_version": "V2_REPAIRED",
        "template_authority": "ACTIVE_CANONICAL",
        "operation_mode": "STRUCTURAL_JOINT_DISCOVERY",
        "pikachu_dependency": "NOT_USED",
        "source_admission_policy": {
            "logic": "SC_VERIFIED_OR_CREATED_AT_CUTOFF",
            "cutoff": CUTOFF_KST,
            "cutoff_inclusive": True,
            "modified_at_fallback": "FORBIDDEN",
        },
        "target": {
            "d_chart": "D9",
            "house_id": "H05",
            "source_house_token": "5H",
            "d_chart_domain": "marriage",
            "house_function": "creative-output",
            "view": "SOURCE_ROUTED_SEPARATE_LAYERS",
        },
        "source_router_16": {
            "lanes": router_lanes,
            "routing_status": "PASS",
            "hold_reason": "",
        },
        "source_packet": [full_source, mini_source],
        "evidence_registry": [
            {
                "evidence_id": "E_FULL",
                "source_id": "SRC_FULL",
                "source_locator": "full:1",
                "source_value": "full-value",
                "grade": "DIRECT_SOURCE",
                "approved_rule_ref": None,
                "status": "PASS",
            },
            {
                "evidence_id": "E_MINI",
                "source_id": "SRC_MINI",
                "source_locator": "mini:1",
                "source_value": "mini-value",
                "grade": "DIRECT_SOURCE",
                "approved_rule_ref": None,
                "status": "PASS",
            },
        ],
        "vertical_20d_axis": {
            "d_set": list(DEFAULT_20D),
            "d_set_basis": "DEFAULT_20D",
            "d_set_evidence_refs": [],
            "comparison_by_d": comparison_by_d,
            "classification_summary": classification_summary,
            "target_relative_position": "vertical-position",
            "target_structural_importance": "vertical-importance",
            "importance_basis": "vertical-basis",
            "evidence_refs": ["E_FULL"],
            "status": "PASS",
            "hold_reason": "",
        },
        "horizontal_target_d_axis": {
            "houses": horizontal_houses,
            "target_relative_position": "horizontal-position",
            "target_structural_importance": "horizontal-importance",
            "importance_basis": "horizontal-basis",
            "evidence_refs": ["E_MINI"],
            "status": "PASS",
            "hold_reason": "",
        },
        "final_structural_crosspoint": {
            "vertical_basis": "vertical-basis",
            "horizontal_basis": "horizontal-basis",
            "crosspoint_role": "transfer-crosspoint",
            "structural_centrality": "central",
            "distance_directness": "direct",
            "transfer_impact": "high-within-source",
            "bottleneck_reversal_relation": "source-bounded",
            "sentence_intensity": "high-within-source",
            "verb_strength": "direct",
            "word_choice": "source-bounded",
            "certainty": "direct-source",
            "sentence_width": "single-causal-chain",
            "evidence_refs": ["E_FULL", "E_MINI"],
            "evidence_grade": "DIRECT_SOURCE",
            "status": "PASS",
            "hold_reason": "",
        },
        "joint_bank": [make_joint(number) for number in range(1, 21)],
        "primary_shortfall": {
            "required_count": 20,
            "available_count": 20,
            "missing_count": 0,
            "status": "NOT_APPLICABLE",
            "hold_reason": "",
        },
        "allocation_01_20": allocations,
        "sentence_reverse_map": [make_reverse_map(number) for number in range(1, 21)],
        "axis_non_addition_lock": {
            "combined_total_score": False,
            "combination_method": "HIERARCHICAL_ONLY",
            "independent_axes": {
                "strength": "INDEPENDENT",
                "authority": "INDEPENDENT",
                "support": "INDEPENDENT",
                "pressure": "INDEPENDENT",
                "frequency": "INDEPENDENT",
                "rarity_repetition": "INDEPENDENT",
            },
            "rarity_is_not_importance": True,
            "repetition_is_not_strength": True,
            "status": "PASS",
        },
        "minimum_final_gate": {
            "gate_01_source_entry": "PASS",
            "gate_02_independent_allocation": "PASS",
            "gate_03_reverse_mapping": "PASS",
            "status": "PASS",
            "hold_reason": "",
        },
        "human_output": {
            "target_title": "D9-H05 심층촘촘결 FNa98 칼끝문장",
            "slot_count": 20,
            "dynamic_titles": [stage["slot_title"] for stage in allocations],
            "ending_meta": "D9H05_FNa98_심층촘촘결_칼끝문장_01-20",
            "artifact_path": "D9H05.txt",
            "output_validation_status": "PASS",
            "status": "PASS",
            "hold_reason": "",
        },
        "qa": {gate: "PASS" for gate in QA_GATES},
        "final_status": "PASS",
    }


def make_valid_19_primary_hold_packet() -> dict[str, Any]:
    packet = make_valid_packet()
    packet["joint_bank"].pop()
    packet["primary_shortfall"] = {
        "required_count": 20,
        "available_count": 19,
        "missing_count": 1,
        "status": "HOLD",
        "hold_reason": "Only 19 nonduplicate PRIMARY joints are evidenced.",
    }

    allocation = packet["allocation_01_20"][-1]
    allocation["primary_joint_ids"] = []
    allocation["evidence_refs"] = []
    allocation["status"] = "HOLD"
    allocation["hold_reason"] = "No twentieth evidenced PRIMARY joint."

    reverse_map = packet["sentence_reverse_map"][-1]
    reverse_map["joint_ids"] = []
    reverse_map["evidence_refs"] = []
    reverse_map["clause_records"] = []
    reverse_map["evidence_grade"] = "HOLD"
    reverse_map["mapping_status"] = "HOLD"
    reverse_map["hold_reason"] = "Stage 20 is held with the PRIMARY shortfall."

    packet["qa"]["primary_joint_count"] = "HOLD"
    packet["qa"]["allocation_01_20"] = "HOLD"
    packet["qa"]["reverse_mapping"] = "HOLD"
    packet["minimum_final_gate"]["gate_02_independent_allocation"] = "HOLD"
    packet["minimum_final_gate"]["gate_03_reverse_mapping"] = "HOLD"
    packet["minimum_final_gate"]["status"] = "HOLD"
    packet["final_status"] = "HOLD"
    return packet


class ErrorAssertionMixin:
    def assert_error_contains(self, errors: list[str], fragment: str) -> None:
        self.assertTrue(
            any(fragment in error for error in errors),
            msg=f"Expected error containing {fragment!r}; got:\n" + "\n".join(errors),
        )


class SourceAdmissionTests(ErrorAssertionMixin, unittest.TestCase):
    def test_old_verified_sc_is_admitted(self) -> None:
        source = make_source("SRC_OLD_SC", "VARGA_FULL")
        self.assertEqual(validate_source_admission(source, "source"), [])

    def test_sc_filename_match_must_be_an_independent_token(self) -> None:
        source = make_source("SRC_FALSE_SC_SUBSTRING", "VARGA_FULL")
        source["name_or_path"] = "misc.json"
        errors = validate_source_admission(source, "source")
        self.assert_error_contains(errors, "no independent SC filename token")

    def test_new_non_sc_is_admitted(self) -> None:
        source = make_source(
            "SRC_NEW_NON_SC",
            "VARGA_MINI",
            sc_verified=False,
            sc_verification_basis="NOT_SC",
            created_at="2026-08-09T00:00:01+09:00",
            admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
        )
        self.assertEqual(validate_source_admission(source, "source"), [])

    def test_cutoff_is_inclusive_in_kst_and_utc(self) -> None:
        for created_at in (CUTOFF_KST, "2026-08-08T15:00:00Z"):
            with self.subTest(created_at=created_at):
                source = make_source(
                    "SRC_CUTOFF",
                    "VARGA_MINI",
                    sc_verified=False,
                    sc_verification_basis="NOT_SC",
                    created_at=created_at,
                    admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
                )
                self.assertEqual(validate_source_admission(source, "source"), [])

    def test_old_non_sc_is_rejected(self) -> None:
        source = make_source(
            "SRC_OLD_NON_SC",
            "VARGA_MINI",
            sc_verified=False,
            sc_verification_basis="NOT_SC",
            created_at="2026-08-08T23:59:59+09:00",
            admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
        )
        errors = validate_source_admission(source, "source")
        self.assert_error_contains(errors, "is inadmissible")

    def test_updated_at_cannot_replace_created_at(self) -> None:
        source = make_source(
            "SRC_UPDATED_ONLY",
            "VARGA_MINI",
            sc_verified=False,
            sc_verification_basis="NOT_SC",
            created_at=None,
            created_at_source=None,
            admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
        )
        source["updated_at"] = "2026-08-10T09:00:00+09:00"
        errors = validate_source_admission(source, "source")
        self.assert_error_contains(errors, "is inadmissible")

    def test_naive_created_at_is_rejected(self) -> None:
        source = make_source(
            "SRC_NAIVE_DATE",
            "VARGA_MINI",
            sc_verified=False,
            sc_verification_basis="NOT_SC",
            created_at="2026-08-09T00:00:00",
            admission_basis="CREATED_ON_OR_AFTER_2026_08_09_KST",
        )
        errors = validate_source_admission(source, "source")
        self.assert_error_contains(errors, "timezone-aware ISO-8601")


class StructuralJointPacketTests(ErrorAssertionMixin, unittest.TestCase):
    def setUp(self) -> None:
        self.packet = make_valid_packet()

    def test_valid_20_primary_packet_passes(self) -> None:
        self.assertEqual(validate(self.packet), [])

    def test_default_20d_includes_d5_and_voids_d50(self) -> None:
        self.assertIn("D5", DEFAULT_20D)
        self.assertNotIn("D50", DEFAULT_20D)
        self.assertEqual(len(DEFAULT_20D), 20)

    def test_active_canonical_template_identity_is_required(self) -> None:
        for field, invalid_value in (
            ("template_version", "V1"),
            ("template_authority", "CURRENT_SPECIFIED"),
        ):
            with self.subTest(field=field):
                packet = make_valid_packet()
                packet[field] = invalid_value
                errors = validate(packet)
                self.assert_error_contains(errors, f"{field} must be")

    def test_explicit_void_r4_source_is_rejected(self) -> None:
        self.packet["source_packet"][0]["name_or_path"] = "DDCHART_Mj01_FNa98_R4_P01.txt"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "explicitly VOID R4 source")

    def test_source_admission_policy_is_an_exact_lock(self) -> None:
        invalid_values = {
            "logic": "SC_ONLY",
            "cutoff": "2026-08-09T00:00:01+09:00",
            "cutoff_inclusive": False,
            "modified_at_fallback": "ALLOWED",
        }
        for field, invalid_value in invalid_values.items():
            with self.subTest(field=field):
                packet = make_valid_packet()
                packet["source_admission_policy"][field] = invalid_value
                errors = validate(packet)
                self.assert_error_contains(errors, f"source_admission_policy.{field} must be")

    def test_same_joint_with_different_operation_face_is_allowed(self) -> None:
        self.packet["allocation_01_20"][1]["primary_joint_ids"] = ["J01"]
        self.assertNotEqual(
            self.packet["allocation_01_20"][0]["operation_face"],
            self.packet["allocation_01_20"][1]["operation_face"],
        )
        self.assertEqual(validate(self.packet), [])

    def test_19_primary_with_explicit_shortfall_is_valid_hold(self) -> None:
        packet = make_valid_19_primary_hold_packet()
        self.assertEqual(validate(packet), [])

    def test_old_non_sc_source_is_rejected_by_packet_validator(self) -> None:
        source = self.packet["source_packet"][0]
        source.update(
            {
                "name_or_path": "varga_full.json",
                "sc_verified": False,
                "sc_verification_basis": "NOT_SC",
                "created_at": "2026-08-08T23:59:59+09:00",
                "admission_basis": "CREATED_ON_OR_AFTER_2026_08_09_KST",
            }
        )
        errors = validate(self.packet)
        self.assert_error_contains(errors, "source_packet[0] is inadmissible")

    def test_missing_varga_role_is_rejected(self) -> None:
        self.packet["source_packet"][1]["source_role"] = "SUPPORT"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "source_packet missing role: VARGA_MINI")

    def test_missing_d_chart_is_rejected(self) -> None:
        self.packet["vertical_20d_axis"]["d_set"].pop()
        self.packet["vertical_20d_axis"]["comparison_by_d"].pop()
        errors = validate(self.packet)
        self.assert_error_contains(errors, "d_set must contain 20 unique D charts")

    def test_missing_house_is_rejected(self) -> None:
        self.packet["horizontal_target_d_axis"]["houses"].pop()
        errors = validate(self.packet)
        self.assert_error_contains(errors, "houses must contain 12 rows")

    def test_19_primary_cannot_claim_final_pass(self) -> None:
        self.packet["joint_bank"].pop()
        self.packet["allocation_01_20"][-1]["primary_joint_ids"] = ["J19"]
        self.packet["sentence_reverse_map"][-1]["joint_ids"] = ["J19"]
        self.packet["primary_shortfall"] = {
            "required_count": 20,
            "available_count": 19,
            "missing_count": 1,
            "status": "HOLD",
            "hold_reason": "Only 19 PRIMARY joints are evidenced.",
        }
        errors = validate(self.packet)
        self.assert_error_contains(errors, "final PASS requires at least 20 PASS PRIMARY joints")

    def test_duplicate_primary_joint_signature_is_rejected(self) -> None:
        self.packet["joint_bank"][1]["joint_signature"] = self.packet["joint_bank"][0][
            "joint_signature"
        ]
        errors = validate(self.packet)
        self.assert_error_contains(errors, "duplicate PRIMARY joint_signature")

    def test_duplicate_stage_distinctness_signature_is_rejected(self) -> None:
        duplicate = copy.deepcopy(
            self.packet["allocation_01_20"][0]["distinctness_signature"]
        )
        self.packet["allocation_01_20"][1]["distinctness_signature"] = duplicate
        errors = validate(self.packet)
        self.assert_error_contains(errors, "duplicate stage distinctness signature")

    def test_same_joint_and_operation_face_reuse_is_rejected(self) -> None:
        first = self.packet["allocation_01_20"][0]
        second = self.packet["allocation_01_20"][1]
        second["primary_joint_ids"] = list(first["primary_joint_ids"])
        second["operation_face"] = first["operation_face"]
        errors = validate(self.packet)
        self.assert_error_contains(errors, "same joint and operation_face reused")

    def test_unknown_evidence_reference_is_rejected(self) -> None:
        self.packet["joint_bank"][0]["evidence_refs"] = ["E_UNKNOWN"]
        errors = validate(self.packet)
        self.assert_error_contains(errors, "references unknown evidence: E_UNKNOWN")

    def test_inference_evidence_is_rejected(self) -> None:
        self.packet["evidence_registry"][0]["grade"] = "INFERENCE"
        errors = validate(self.packet)
        self.assert_error_contains(errors, ".grade must be DIRECT_SOURCE or DERIVED")

    def test_combined_total_score_is_rejected(self) -> None:
        self.packet["axis_non_addition_lock"]["combined_total_score"] = True
        errors = validate(self.packet)
        self.assert_error_contains(errors, "combined_total_score must be false")

    def test_recursive_aggregate_score_is_rejected(self) -> None:
        self.packet["final_structural_crosspoint"]["aggregate_score"] = 99
        errors = validate(self.packet)
        self.assert_error_contains(errors, "forbidden cross-axis score")

    def test_pikachu_dependency_is_rejected(self) -> None:
        self.packet["pikachu_dependency"] = "USED"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "pikachu_dependency must be NOT_USED")

    def test_missing_source_router_lane_is_rejected(self) -> None:
        self.packet["source_router_16"]["lanes"].pop()
        errors = validate(self.packet)
        self.assert_error_contains(errors, "exactly 16 lane records")

    def test_old_rashi_only_view_is_rejected(self) -> None:
        self.packet["target"]["view"] = "RASHI"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "SOURCE_ROUTED_SEPARATE_LAYERS")

    def test_complete_fixed_title_vector_in_dynamic_allocation_is_rejected(self) -> None:
        from validate_fixed_knife_sentence_output import FIXED_TITLES

        for stage, title in zip(self.packet["allocation_01_20"], FIXED_TITLES):
            stage["slot_title"] = title
        self.packet["human_output"]["dynamic_titles"] = list(FIXED_TITLES)
        errors = validate(self.packet)
        self.assert_error_contains(errors, "complete fixed/calibration title vector")

    def test_clause_level_unknown_source_is_rejected(self) -> None:
        self.packet["sentence_reverse_map"][0]["clause_records"][0]["source_id"] = "UNKNOWN"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "references unknown source")

    def test_human_output_titles_must_match_allocation(self) -> None:
        self.packet["human_output"]["dynamic_titles"][0] = "different-title"
        errors = validate(self.packet)
        self.assert_error_contains(errors, "must match allocation slot_title order")


class DeepDenseTemplateTopologyTests(ErrorAssertionMixin, unittest.TestCase):
    def validate_candidate_text(self, text: str) -> list[str]:
        with tempfile.TemporaryDirectory() as temp_dir:
            candidate = Path(temp_dir) / "candidate.md"
            candidate.write_text(text, encoding="utf-8")
            return validate_deep_dense_template(candidate)

    def test_canonical_template_topology_passes(self) -> None:
        self.assertEqual(validate_deep_dense_template(DEEP_DENSE_CANONICAL), [])

    def test_d50_concrete_template_is_rejected(self) -> None:
        canonical_text = DEEP_DENSE_CANONICAL.read_text(encoding="utf-8")
        candidate_text = canonical_text.replace("<D_CHART_TAG>", "D50").replace("<HOUSE_ID>", "H08")
        errors = self.validate_candidate_text(candidate_text)
        self.assert_error_contains(errors, "unsupported D chart: D50")

    def test_d5_concrete_template_passes(self) -> None:
        canonical_text = DEEP_DENSE_CANONICAL.read_text(encoding="utf-8")
        candidate_text = canonical_text.replace("<D_CHART_TAG>", "D5").replace("<HOUSE_ID>", "H08")
        self.assertEqual(self.validate_candidate_text(candidate_text), [])

    def test_non_24_character_divider_is_rejected(self) -> None:
        canonical_text = DEEP_DENSE_CANONICAL.read_text(encoding="utf-8")
        candidate_text = canonical_text.replace("━━━━━━━━━━━━━━━━━━━━━━━━", "━━━━━━━━━━━━━━━━━━━━━━━━━", 1)
        errors = self.validate_candidate_text(candidate_text)
        self.assert_error_contains(errors, "exactly 24")

    def test_deleted_subheading_is_rejected(self) -> None:
        canonical_text = DEEP_DENSE_CANONICAL.read_text(encoding="utf-8")
        deleted = canonical_text.replace("《16-06》 누수 차단\n", "", 1)
        self.assertNotEqual(deleted, canonical_text)
        errors = self.validate_candidate_text(deleted)
        self.assert_error_contains(errors, "heading count changed")

    def test_reordered_subheadings_are_rejected(self) -> None:
        canonical_text = DEEP_DENSE_CANONICAL.read_text(encoding="utf-8")
        original = "《16-06》 누수 차단\n《16-07》 동일조건 재투입\n"
        reordered = "《16-07》 동일조건 재투입\n《16-06》 누수 차단\n"
        candidate_text = canonical_text.replace(original, reordered, 1)
        self.assertNotEqual(candidate_text, canonical_text)
        errors = self.validate_candidate_text(candidate_text)
        self.assert_error_contains(errors, "changed or moved")


if __name__ == "__main__":
    unittest.main()
