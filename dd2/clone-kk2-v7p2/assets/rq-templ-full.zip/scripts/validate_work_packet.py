#!/usr/bin/env python3
"""Validate a PIKACHU × SC RQ VeDic work packet before delivery."""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

try:
    from .source_admission import REQUIRED_ADMISSION_FIELDS, validate_source_admission
except ImportError:  # Direct execution: python3 scripts/validate_work_packet.py
    from source_admission import REQUIRED_ADMISSION_FIELDS, validate_source_admission


REQUIRED_TOP = {
    "actual_question",
    "action",
    "operation_mode",
    "active_canonical_id",
    "command_registry",
    "command_to_template_map",
    "premap_execution",
    "master_execution_01_20",
    "post_bottleneck_execution_01_11",
    "worker_matrix",
    "target",
    "scope",
    "exclusions",
    "output_contract",
    "source_admission_policy",
    "source_packet",
    "state_axes",
    "pilot",
    "locks",
    "qa",
    "final_status",
}

REQUIRED_TARGET = {"d_chart", "d_chart_domain", "house_id", "house_function", "view"}
REQUIRED_SOURCE = {
    "source_id",
    "name_or_path",
    "authority",
    "authority_state",
    "material_state",
    "read_scope",
    "identity_or_hash",
} | REQUIRED_ADMISSION_FIELDS
REQUIRED_STAGE = {
    "input_refs",
    "command_tokens",
    "command_definition_hashes",
    "selected_value",
    "operation",
    "output",
    "handoff_id",
    "receives_from",
    "evidence_grade",
    "why",
    "status",
}
QA_GATES = {"target", "source", "facts", "why", "logic", "format", "file_integrity", "usability"}
VALID_MODES = {
    "TEMPLATE_BUILD",
    "TEMPLATE_REPAIR",
    "STRUCTURE_ANALYSIS",
    "INTERPRETATION_WRITING",
    "VALIDATION_ONLY",
    "BATCH_EXPANSION",
}
VALID_FINAL = {"PENDING", "REVISE", "HOLD", "PASS"}
VALID_STAGE_STATUS = {"PASS", "REVISE", "HOLD", "NOT_APPLICABLE"}

EXPECTED_SOURCE_ADMISSION_POLICY = {
    "logic": "SC_VERIFIED_OR_CREATED_AT_CUTOFF",
    "cutoff": "2026-08-09T00:00:00+09:00",
    "cutoff_inclusive": True,
    "modified_at_fallback": "FORBIDDEN",
}

PREMAP_ORDER = [
    ("00A", "VargaMini OPEN"),
    ("00B", "VargaFull OPEN"),
    ("00C", "LINK MAP 확정"),
]

MASTER_ORDER = [
    ("01", "도메인과 질문을 정확히 고정"),
    ("02", "Rashi의 기본 Promise와 배역 확정"),
    ("03", "Bhava의 실제 도착 위치와 현실 작동장 확인"),
    ("04", "House Lord·점유행성·카라카의 독립 의제 분리"),
    ("05", "Nakshatra·Pada·RL/NL/SL/SSL 착색 삽입"),
    ("06", "도수·공동장·선후관절·근접성 확인"),
    ("07", "행성강도층 전수 삽입"),
    ("08", "Aspect·Argala·Parivartana·관계망 삽입"),
    ("09", "Avastha·연소·역행·MKS 등 작동상태 삽입"),
    ("10", "Arudha·Pada·귀속·가시화·이미지층 삽입"),
    ("11", "동일 D 내부의 하우스 간 회로 연결"),
    ("12", "다른 D차트의 지지·충돌·보정 검산"),
    ("13", "Dasha가 실제 실행권자를 선택"),
    ("14", "Timing Gate·Transit이 점화 관절을 지정"),
    ("15", "인과·전달·도착·귀속·보유·회수 경로 조립"),
    ("16", "병목의 정확한 위치와 손실 원인 확정"),
    ("17", "조건 변화에 따른 관계 전환과 결과 변화 추적"),
    ("18", "단기·중단기·장기 결과 분리"),
    ("19", "모든 층의 모순·누락·과잉해석 전수 검산"),
    ("20", "하나의 통합 잠금문으로 봉합"),
]

POST_ORDER = [
    (1, "병목 위치 확정"),
    (2, "병목 원인·손실경로 확정"),
    (3, "뒤집기 가능한 통제변수 추출"),
    (4, "뒤집기 관절·조건 확정"),
    (5, "병목 뒤집기 실행"),
    (6, "누수 차단"),
    (7, "동일조건 재투입"),
    (8, "재누수·재병목 검산"),
    (9, "대체경로 비교"),
    (10, "전달·도착·귀속·보유·회수량 재계산"),
    (11, "BEFORE/AFTER 회수량 증가 증명"),
]

PREMAP_COMMANDS = {
    "00A": {"SOURCE", "PARSE", "PATTERN", "RANK", "SIGNALVSNOISE"},
    "00B": {"SOURCE", "PARSE", "PATTERN", "DEPENDENCYMAP", "CONTEXTUALIZE"},
    "00C": {"DEPENDENCYMAP", "RANK", "SIGNALVSNOISE", "LOCK"},
}

MASTER_COMMANDS = {
    "01": {"META", "SOURCE", "PARSE", "CONTEXTUALIZE", "LOCK"},
    "02": {"SOURCE", "PARSE", "LAYER", "LAYERMAP", "VEDICSTRUCTURE"},
    "03": {"SOURCE", "PARSE", "LAYER", "LAYERBOUNDARY", "VEDICSTRUCTURE"},
    "04": {"LAYER", "LAYERMAP", "DEPENDENCYMAP", "RANK", "PARETO"},
    "05": {"SOURCE", "PARSE", "LAYERBOUNDARY", "CONTEXTUALIZE"},
    "06": {"PARSE", "TRACE", "VERIFY"},
    "07": {"SOURCE", "PARSE", "RANK", "PARETO", "VERIFY"},
    "08": {"SOURCE", "PARSE", "DEPENDENCYMAP", "MECHANISM", "VERIFY"},
    "09": {"SOURCE", "PARSE", "LAYERBOUNDARY", "VERIFY"},
    "10": {"SOURCE", "PARSE", "LAYERBOUNDARY", "TRACE", "VERIFY"},
    "11": {"DEPENDENCYMAP", "MECHANISM", "CAUSALCHAIN", "TRACE"},
    "12": {"PATTERN", "SIGNALVSNOISE", "DEPENDENCYMAP", "CONTEXTUALIZE", "VERIFY"},
    "13": {"SOURCE", "PARSE", "DEPENDENCYMAP", "TRACE", "VERIFY"},
    "14": {"SOURCE", "PARSE", "DEPENDENCYMAP", "TRACE", "VERIFY"},
    "15": {"MECHANISM", "CAUSALCHAIN", "TRACE", "PAPER3DEEP_STAR"},
    "16": {"DIAGNOSE", "ROOTCAUSE", "FAILUREMODES", "PAPER3DEEP_STAR"},
    "17": {"FRACTAL", "DEPENDENCYMAP", "TRACE", "CONTEXTUALIZE"},
    "18": {"FRACTAL", "TRACE", "CONTEXTUALIZE", "VALIDATE"},
    "19": {"VALIDATE", "VERIFY"},
    "20": {"SYNTHESIZE", "LOCK", "FORMAT"},
}

POST_COMMANDS = {
    1: {"DIAGNOSE", "TRACE"},
    2: {"ROOTCAUSE", "FAILUREMODES", "TRACE"},
    3: {"PARETO", "PRECONDITIONMAP"},
    4: {"PRECONDITIONMAP", "REVERSE", "OPTIMIZE"},
    5: {"REVERSE", "OPTIMIZE", "TRACE"},
    6: {"FAILUREMODES", "OPTIMIZE", "TRACE"},
    7: {"TRACE", "RECOMPUTE", "VERIFY"},
    8: {"FAILUREMODES", "DIAGNOSE", "VALIDATE"},
    9: {"TRACE", "PARETO", "OPTIMIZE"},
    10: {"TRACE", "RECOMPUTE", "VERIFY"},
    11: {"RECOMPUTE", "VALIDATE", "VERIFY", "LOCK"},
}


def missing_keys(obj: object, required: set[str], label: str, errors: list[str]) -> None:
    if not isinstance(obj, dict):
        errors.append(f"{label} must be an object")
        return
    missing = sorted(required - set(obj))
    if missing:
        errors.append(f"{label} missing: {', '.join(missing)}")


def nonempty(value: object) -> bool:
    return value is not None and value != "" and value != [] and value != {}


def command_index(registry: object, errors: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    if not isinstance(registry, list) or not registry:
        errors.append("command_registry must be a non-empty list")
        return result
    required = {
        "command_token",
        "canonical_definition",
        "definition_hash",
        "authority_state",
        "source_id",
        "source_location",
    }
    for idx, item in enumerate(registry):
        label = f"command_registry[{idx}]"
        missing_keys(item, required, label, errors)
        if not isinstance(item, dict):
            continue
        for field in required:
            if not nonempty(item.get(field)):
                errors.append(f"{label} empty: {field}")
        token = item.get("command_token")
        if token in result:
            errors.append(f"duplicate command token: {token}")
        if item.get("authority_state") != "ACTIVE":
            errors.append(f"{label} is not ACTIVE")
        if token:
            result[str(token)] = str(item.get("definition_hash", ""))
    return result


def validate_stage(
    stage: object,
    number_field: str,
    expected_number: object,
    expected_name: str,
    label: str,
    commands: dict[str, str],
    required_commands: set[str],
    final_status: str,
    errors: list[str],
) -> None:
    missing_keys(stage, REQUIRED_STAGE | {number_field, "stage_name"}, label, errors)
    if not isinstance(stage, dict):
        return
    if stage.get(number_field) != expected_number:
        errors.append(f"{label} number changed: expected {expected_number!r}")
    if stage.get("stage_name") != expected_name:
        errors.append(f"{label} name changed: expected {expected_name}")
    status = stage.get("status")
    if status not in VALID_STAGE_STATUS:
        errors.append(f"{label} invalid status: {status!r}")

    always_required = {
        "input_refs",
        "command_tokens",
        "command_definition_hashes",
        "operation",
        "handoff_id",
        "receives_from",
        "evidence_grade",
        "why",
    }
    for field in always_required:
        if not nonempty(stage.get(field)):
            errors.append(f"{label} empty: {field}")
    if status in {"PASS", "NOT_APPLICABLE"}:
        for field in ("selected_value", "output"):
            if not nonempty(stage.get(field)):
                errors.append(f"{label} {status} empty: {field}")
    if status in {"HOLD", "REVISE"} and not nonempty(stage.get("hold_reason")):
        errors.append(f"{label} {status} requires hold_reason")

    tokens = stage.get("command_tokens")
    hashes = stage.get("command_definition_hashes")
    if not isinstance(tokens, list) or not tokens:
        errors.append(f"{label} requires at least one command token")
    elif not isinstance(hashes, dict):
        errors.append(f"{label} command_definition_hashes must be an object")
    else:
        for token in tokens:
            if token not in commands:
                errors.append(f"{label} unknown command token: {token}")
            elif hashes.get(token) != commands[token]:
                errors.append(f"{label} command hash mismatch: {token}")
        missing_commands = sorted(required_commands - set(tokens))
        if missing_commands:
            errors.append(f"{label} canonical commands missing: {', '.join(missing_commands)}")

    if final_status == "PASS" and status not in {"PASS", "NOT_APPLICABLE"}:
        errors.append(f"PASS has unresolved stage: {label}")


def execution_map(
    value: object,
    list_key: str,
    order: list[tuple[object, str]],
    number_field: str,
    label: str,
    commands: dict[str, str],
    command_requirements: dict[object, set[str]],
    final_status: str,
    errors: list[str],
) -> dict[str, list[dict]]:
    result: dict[str, list[dict]] = {}
    if not isinstance(value, list) or not value:
        errors.append(f"{label} must be a non-empty list")
        return result
    for idx, item in enumerate(value):
        item_label = f"{label}[{idx}]"
        if not isinstance(item, dict):
            errors.append(f"{item_label} must be an object")
            continue
        target_key = item.get("target_key")
        stages = item.get(list_key)
        if not nonempty(target_key):
            errors.append(f"{item_label} missing target_key")
            continue
        if target_key in result:
            errors.append(f"{label} duplicate target_key: {target_key}")
        if not isinstance(stages, list):
            errors.append(f"{item_label}.{list_key} must be a list")
            continue
        if len(stages) != len(order):
            errors.append(f"{item_label}.{list_key} count must be {len(order)}, got {len(stages)}")
        for stage_idx, expected in enumerate(order):
            if stage_idx >= len(stages):
                break
            validate_stage(
                stages[stage_idx],
                number_field,
                expected[0],
                expected[1],
                f"{item_label}.{list_key}[{stage_idx}]",
                commands,
                command_requirements.get(expected[0], set()),
                final_status,
                errors,
            )
        result[str(target_key)] = [x for x in stages if isinstance(x, dict)]
    return result


def validate_chain(
    target_key: str,
    pre: list[dict],
    master: list[dict],
    post: list[dict],
    errors: list[str],
) -> None:
    if len(pre) != 3 or len(master) != 20 or len(post) != 11:
        return
    expected_receive: object = "ROOT"
    for idx, stage in enumerate(pre):
        if stage.get("receives_from") != expected_receive:
            errors.append(f"{target_key} PREMAP[{idx}] handoff chain broken")
        expected_receive = stage.get("handoff_id")
    for idx, stage in enumerate(master[:16]):
        if stage.get("receives_from") != expected_receive:
            errors.append(f"{target_key} MASTER[{idx + 1:02d}] handoff chain broken")
        expected_receive = stage.get("handoff_id")
    for idx, stage in enumerate(post):
        if stage.get("receives_from") != expected_receive:
            errors.append(f"{target_key} POST[{idx + 1:02d}] handoff chain broken")
        expected_receive = stage.get("handoff_id")
    for idx, stage in enumerate(master[16:], start=17):
        if stage.get("receives_from") != expected_receive:
            errors.append(f"{target_key} MASTER[{idx:02d}] handoff chain broken")
        expected_receive = stage.get("handoff_id")


def validate_post_metadata(
    entries: object,
    mode: str,
    final_status: str,
    errors: list[str],
) -> None:
    if not isinstance(entries, list):
        return
    required = {
        "same_condition_signature_before",
        "same_condition_signature_after",
        "recalculation_ledger",
        "before_after_proof",
    }
    for idx, item in enumerate(entries):
        label = f"post_bottleneck_execution_01_11[{idx}]"
        missing_keys(item, required, label, errors)
        if not isinstance(item, dict):
            continue
        before_sig = item.get("same_condition_signature_before")
        after_sig = item.get("same_condition_signature_after")
        if not nonempty(before_sig) or not nonempty(after_sig):
            errors.append(f"{label} same-condition signatures required")
        elif before_sig != after_sig:
            errors.append(f"{label} same-condition reinjection mismatch")

        ledger = item.get("recalculation_ledger")
        ledger_keys = {"transfer", "arrival", "attribution", "retention", "recovery_amount"}
        missing_keys(ledger, ledger_keys, f"{label}.recalculation_ledger", errors)
        if isinstance(ledger, dict):
            for key in ledger_keys:
                if not nonempty(ledger.get(key)):
                    errors.append(f"{label}.recalculation_ledger empty: {key}")

        proof = item.get("before_after_proof")
        proof_keys = {"basis", "unit", "before", "after", "delta", "proof_status"}
        missing_keys(proof, proof_keys, f"{label}.before_after_proof", errors)
        if isinstance(proof, dict):
            for key in proof_keys:
                if not nonempty(proof.get(key)) and proof.get(key) != 0:
                    errors.append(f"{label}.before_after_proof empty: {key}")
            allowed = {"PASS", "SCHEMA_PASS"} if mode in {"TEMPLATE_BUILD", "TEMPLATE_REPAIR"} else {"PASS"}
            if final_status == "PASS" and proof.get("proof_status") not in allowed:
                errors.append(f"{label} PASS requires BEFORE/AFTER proof")
            if item.get("recovery_increase_claimed"):
                b, a, d = proof.get("before"), proof.get("after"), proof.get("delta")
                if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in (b, a, d)):
                    errors.append(f"{label} numeric recovery claim requires finite before/after/delta")
                elif not math.isclose(a - b, d) or d <= 0:
                    errors.append(f"{label} recovery increase delta is not proven")


def validate(packet: object) -> list[str]:
    errors: list[str] = []
    missing_keys(packet, REQUIRED_TOP, "packet", errors)
    if not isinstance(packet, dict):
        return errors

    mode = packet.get("operation_mode")
    if mode not in VALID_MODES:
        errors.append(f"operation_mode invalid: {mode!r}")
    final_status = packet.get("final_status")
    if final_status not in VALID_FINAL:
        errors.append(f"final_status invalid: {final_status!r}")
    if not nonempty(packet.get("active_canonical_id")):
        errors.append("active_canonical_id required")

    source_admission_policy = packet.get("source_admission_policy")
    missing_keys(
        source_admission_policy,
        set(EXPECTED_SOURCE_ADMISSION_POLICY),
        "source_admission_policy",
        errors,
    )
    if isinstance(source_admission_policy, dict):
        for key, expected_value in EXPECTED_SOURCE_ADMISSION_POLICY.items():
            if source_admission_policy.get(key) != expected_value:
                errors.append(
                    f"source_admission_policy.{key} must be {expected_value!r}"
                )

    commands = command_index(packet.get("command_registry"), errors)

    command_map = packet.get("command_to_template_map")
    if not isinstance(command_map, list) or not command_map:
        errors.append("command_to_template_map must be a non-empty list")
    else:
        for idx, mapping in enumerate(command_map):
            required = {"command_token", "template_block", "input_source", "output_field", "execution_position", "failure_state"}
            missing_keys(mapping, required, f"command_to_template_map[{idx}]", errors)
            if isinstance(mapping, dict) and mapping.get("command_token") not in commands:
                errors.append(f"command_to_template_map[{idx}] uses unknown command")

    pre = execution_map(
        packet.get("premap_execution"), "stages", PREMAP_ORDER, "stage_no", "premap_execution", commands, PREMAP_COMMANDS, str(final_status), errors
    )
    master = execution_map(
        packet.get("master_execution_01_20"), "stages", MASTER_ORDER, "stage_no", "master_execution_01_20", commands, MASTER_COMMANDS, str(final_status), errors
    )
    post = execution_map(
        packet.get("post_bottleneck_execution_01_11"), "steps", POST_ORDER, "step_no", "post_bottleneck_execution_01_11", commands, POST_COMMANDS, str(final_status), errors
    )
    validate_post_metadata(packet.get("post_bottleneck_execution_01_11"), str(mode), str(final_status), errors)

    target_sets = [set(pre), set(master), set(post)]
    if target_sets[0] != target_sets[1] or target_sets[1] != target_sets[2]:
        errors.append("premap/master/post target sets must match")
    for target_key in sorted(set(pre) & set(master) & set(post)):
        validate_chain(target_key, pre[target_key], master[target_key], post[target_key], errors)

    workers = packet.get("worker_matrix")
    if not isinstance(workers, list):
        errors.append("worker_matrix must be a list")
    else:
        worker_targets = [x.get("target_key") for x in workers if isinstance(x, dict)]
        if len(workers) == 5 and len(set(worker_targets)) != 5:
            errors.append("five-tab work requires five distinct target_key values")
        for idx, worker in enumerate(workers):
            if not isinstance(worker, dict) or not worker.get("worker_id") or not worker.get("target_key"):
                errors.append(f"worker_matrix[{idx}] requires worker_id and target_key")
            elif worker.get("target_key") not in master:
                errors.append(f"worker_matrix[{idx}] target has no execution")

    missing_keys(packet.get("target"), REQUIRED_TARGET, "target", errors)
    target = packet.get("target")
    if isinstance(target, dict) and target.get("view") == "RASHI_BHAVA_MERGED":
        errors.append("target.view must not merge Rashi and Bhava")

    sources = packet.get("source_packet")
    admitted_source_ids: set[str] = set()
    admitted_active_canonical_ids: set[str] = set()
    source_id_counts: dict[str, int] = {}
    if not isinstance(sources, list) or not sources:
        errors.append("source_packet must contain at least one source")
    else:
        active_canonical = False
        for idx, source in enumerate(sources):
            label = f"source_packet[{idx}]"
            missing_keys(source, REQUIRED_SOURCE, label, errors)
            if not isinstance(source, dict):
                continue
            admission_errors = validate_source_admission(source, label)
            errors.extend(admission_errors)

            source_id = source.get("source_id")
            valid_source_id = isinstance(source_id, str) and bool(source_id.strip())
            if not valid_source_id:
                errors.append(f"{label}.source_id must be a non-empty string")
            else:
                source_id_counts[source_id] = source_id_counts.get(source_id, 0) + 1
                if not admission_errors:
                    admitted_source_ids.add(source_id)
                    if source.get("authority") == "ACTIVE_CANONICAL":
                        admitted_active_canonical_ids.add(source_id)

            if source.get("authority_state") == "VOID":
                errors.append(f"{label} is VOID")
            if source.get("material_state") != "PARSED":
                errors.append(f"{label} is not PARSED")
            if source.get("authority") == "ACTIVE_CANONICAL":
                active_canonical = True

        for source_id, count in source_id_counts.items():
            if count > 1:
                errors.append(f"duplicate source_id: {source_id}")
                admitted_source_ids.discard(source_id)
                admitted_active_canonical_ids.discard(source_id)

        if not active_canonical:
            errors.append("source_packet has no ACTIVE_CANONICAL entry")

    active_canonical_id = packet.get("active_canonical_id")
    if nonempty(active_canonical_id):
        if not isinstance(active_canonical_id, str) or not active_canonical_id.strip():
            errors.append("active_canonical_id must be a non-empty string")
        elif active_canonical_id not in admitted_active_canonical_ids:
            errors.append(
                "active_canonical_id must reference one admissible ACTIVE_CANONICAL source"
            )

    registry = packet.get("command_registry")
    if isinstance(registry, list):
        for idx, command in enumerate(registry):
            if not isinstance(command, dict):
                continue
            source_id = command.get("source_id")
            if nonempty(source_id):
                if not isinstance(source_id, str) or not source_id.strip():
                    errors.append(
                        f"command_registry[{idx}].source_id must be a non-empty string"
                    )
                elif source_id not in admitted_source_ids:
                    errors.append(
                        f"command_registry[{idx}].source_id must reference one admissible source"
                    )

    state_axes = packet.get("state_axes")
    if not isinstance(state_axes, dict):
        errors.append("state_axes must be an object")
    elif final_status == "PASS":
        if state_axes.get("authority") == "VOID":
            errors.append("PASS cannot use VOID authority")
        if state_axes.get("judgment") in {"CONFLICT", "HOLD"}:
            errors.append("PASS cannot retain CONFLICT or HOLD judgment")

    pilot = packet.get("pilot")
    if not isinstance(pilot, dict):
        errors.append("pilot must be an object")
    elif mode == "BATCH_EXPANSION" and not (pilot.get("status") == "PASS" or pilot.get("skip_authorized") is True):
        errors.append("BATCH_EXPANSION requires pilot PASS or explicit skip_authorized")

    locks = packet.get("locks")
    if not isinstance(locks, dict):
        errors.append("locks must be an object")
    else:
        required_locks = {
            "pikachu_sc_order_lock_id",
            "pikachu_sc_order_sha256",
            "post_bottleneck_recovery_lock_id",
            "post_bottleneck_recovery_sha256",
        }
        missing = sorted(key for key in required_locks if not nonempty(locks.get(key)))
        if missing:
            errors.append(f"locks missing: {', '.join(missing)}")

    qa = packet.get("qa")
    missing_keys(qa, QA_GATES, "qa", errors)
    if final_status == "PASS" and isinstance(qa, dict):
        failed = sorted(key for key in QA_GATES if qa.get(key) not in {"PASS", "NOT_APPLICABLE"})
        if failed:
            errors.append(f"PASS has unpassed QA gates: {', '.join(failed)}")
        if qa.get("file_integrity") != "PASS":
            errors.append("PASS requires file_integrity PASS")

    if final_status == "PASS" and packet.get("holds"):
        errors.append("PASS cannot retain holds")
    if final_status == "PASS" and packet.get("conflicts"):
        errors.append("PASS cannot retain conflicts")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet", type=Path, help="JSON work packet to validate")
    args = parser.parse_args()
    try:
        packet = json.loads(args.packet.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"HOLD: cannot read packet: {exc}", file=sys.stderr)
        return 2
    errors = validate(packet)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
