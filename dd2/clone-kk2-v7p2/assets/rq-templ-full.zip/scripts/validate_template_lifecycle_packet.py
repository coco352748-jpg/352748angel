#!/usr/bin/env python3
"""Validate the reusable RQ VeDic template production and QA lifecycle packet."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from source_admission import validate_source_admission


REQUIRED_TOP = {
    "schema_version",
    "scope_firewall",
    "actual_question",
    "target",
    "action",
    "operation_route",
    "source_scope",
    "file_family",
    "stage_roles",
    "input_sources",
    "source_separation",
    "batch_scope",
    "application_route",
    "template_topology",
    "raw_check",
    "link_check",
    "pilot",
    "validation_passes",
    "final_output",
    "final_status",
    "delivery_disposition",
    "holds",
    "conflicts",
}

VALID_ACTIONS = {"BUILD", "REPAIR", "VALIDATE", "EXPAND"}
VALID_FINAL = {"PASS", "REVISE", "HOLD"}
VALID_DISPOSITIONS = {
    "PASS",
    "PASS_WITH_BOUNDARY_NOTE",
    "PASS_AFTER_PATCH",
    "REVISE_REQUIRED",
    "HOLD",
}
VALID_GATE = {"PASS", "REVISE", "HOLD", "NOT_APPLICABLE"}
VALID_LANE = {"APPLICABLE", "NOT_APPLICABLE", "HOLD"}
VALID_EVIDENCE = {"DIRECT_SOURCE", "DERIVED", "INFERENCE", "HOLD"}
VALID_STAGE = {"PASS", "REVISE", "HOLD", "NOT_APPLICABLE"}
DEFAULT_20D = [
    "D1", "D9", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D10",
    "D11", "D12", "D16", "D20", "D24", "D27", "D30", "D40", "D45", "D60",
]
ROUTE_VALIDATORS = {
    "PIKACHU_CANONICAL_PATH": ["validate_work_packet.py"],
    "STRUCTURAL_JOINT_DISCOVERY": [
        "validate_structural_joint_packet.py",
        "validate_knife_sentence_v2_output.py",
    ],
    "FIXED_KNIFE_SENTENCE_01_20_PATH": [
        "validate_fixed_knife_sentence_packet.py",
        "validate_fixed_knife_sentence_output.py",
    ],
    "DEEP_DENSE_240H_COMMON_PATH": ["validate_deep_dense_240h_template.py"],
}
ROUTE_STEPS = {
    "PIKACHU_CANONICAL_PATH": ["00A", "00B", "00C", "01-20"],
    "STRUCTURAL_JOINT_DISCOVERY": [
        "00_TARGET_LOCK",
        "01_SOURCE_ROUTER_16",
        "02_EVIDENCE_REGISTRY",
        "03_STRUCTURAL_JOINT_DISCOVERY",
        "04_JOINT_BANK",
        "05_INDEPENDENT_ALLOCATION_01_20",
        "06_HUMAN_SENTENCE_ASSEMBLY",
        "07_SENTENCE_REVERSE_MAP",
        "08_MINIMUM_FINAL_GATE",
    ],
    "FIXED_KNIFE_SENTENCE_01_20_PATH": [
        "00_TARGET_LOCK",
        "01_SOURCE_LOCK",
        "02_SLOT_EVIDENCE_MAP_01_20",
        "03_FIXED_SENTENCE_ASSEMBLY_01_20",
        "04_SENTENCE_REVERSE_MAP",
        "05_FIXED_PACKET_VALIDATION",
        "06_FIXED_OUTPUT_VALIDATION",
        "07_3PASS_FINAL_GATE",
    ],
    "DEEP_DENSE_240H_COMMON_PATH": ["TARGET_LOCK", "FIXED_01_20_SUBSTAGE_TOPOLOGY", "3PASS"],
}
STRUCTURAL_CANONICAL_IDENTITY = {
    "template_id": "DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2",
    "template_version": "V2_REPAIRED",
    "template_authority": "ACTIVE_CANONICAL",
    "canonical_scope": "RQ_VEDIC_SYSTEM_WIDE_FOR_STRUCTURAL_JOINT_DISCOVERY",
}
VOID_SOURCE_NAME_TOKENS = {"ddchart_mj01_fna98_r4"}

SOURCE_SCOPE_FIELDS = {"included_source_ids", "excluded_sources", "admission_verified", "authority_verified"}
SCOPE_FIREWALL_FIELDS = {
    "current_target",
    "deliverable",
    "deliverable_count",
    "in_scope_requirements",
    "direct_dependency_links",
    "authorized_actions",
    "auto_import",
    "scope_expansion",
    "user_output",
    "execution_budget",
    "stop_condition",
    "status",
}
FILE_FAMILY_FIELDS = {"family_id", "filename_pattern", "block_order", "ending_meta", "one_chart_one_file"}
SOURCE_LANES = {"natal_anchor", "target_native", "vas_native", "support"}
RAW_GATES = {"source_values", "d_chart_distribution", "view_boundary", "visibility_boundary", "occupant_lord_state"}
LINK_GATES = {"stage_handoffs", "source_reverse_mapping", "placeholder_binding", "domain_house_preservation", "job_uniqueness", "attribution_chain", "coordinate_map_single_scan"}
PASS_FIELDS = {"pass_1_source_identity", "pass_2_structure_why", "pass_3_format_delivery"}
FINAL_OUTPUT_FIELDS = {"paths", "file_count", "exists", "reopened", "ending_meta_verified", "archive_extract_verified", "final_only", "stop_condition_met"}
STAGE_FIELDS = {"stage_id", "input_refs", "operation", "output", "handoff_to", "evidence_grade", "status"}

DISPOSITION_MAP = {
    "PASS": "PASS",
    "PASS_WITH_BOUNDARY_NOTE": "PASS",
    "PASS_AFTER_PATCH": "PASS",
    "REVISE_REQUIRED": "REVISE",
    "HOLD": "HOLD",
}


def nonempty(value: object) -> bool:
    return value is not None and value != "" and value != [] and value != {}


def require_object(value: object, fields: set[str], label: str, errors: list[str]) -> dict:
    if not isinstance(value, dict):
        errors.append(f"{label} must be an object")
        return {}
    missing = sorted(fields - set(value))
    if missing:
        errors.append(f"{label} missing: {', '.join(missing)}")
    return value


def validate_gate_map(value: object, fields: set[str], label: str, final_status: str, errors: list[str]) -> None:
    obj = require_object(value, fields, label, errors)
    for field in fields:
        status = obj.get(field)
        if status not in VALID_GATE:
            errors.append(f"{label}.{field} invalid: {status!r}")
        elif final_status == "PASS" and status not in {"PASS", "NOT_APPLICABLE"}:
            errors.append(f"PASS has unresolved gate: {label}.{field}")


def validate_scope_firewall(value: object, final_status: str, errors: list[str]) -> None:
    obj = require_object(value, SCOPE_FIREWALL_FIELDS, "scope_firewall", errors)
    for field in ("current_target", "deliverable"):
        if not nonempty(obj.get(field)):
            errors.append(f"scope_firewall.{field} must be non-empty")
    if obj.get("deliverable_count") != 1:
        errors.append("scope_firewall.deliverable_count must be exactly 1")

    requirements = obj.get("in_scope_requirements")
    if not isinstance(requirements, list) or not requirements:
        errors.append("scope_firewall.in_scope_requirements must be a non-empty list")
        requirement_ids: set[str] = set()
    else:
        requirement_ids = {str(item) for item in requirements}
        if len(requirement_ids) != len(requirements):
            errors.append("scope_firewall.in_scope_requirements contains duplicates")

    dependencies = obj.get("direct_dependency_links")
    if not isinstance(dependencies, list):
        errors.append("scope_firewall.direct_dependency_links must be a list")

    actions = obj.get("authorized_actions")
    if not isinstance(actions, list) or not actions:
        errors.append("scope_firewall.authorized_actions must be a non-empty list")
    else:
        for index, action in enumerate(actions):
            action_obj = require_object(
                action,
                {"action", "requirement_ref"},
                f"scope_firewall.authorized_actions[{index}]",
                errors,
            )
            if not nonempty(action_obj.get("action")):
                errors.append(f"scope_firewall.authorized_actions[{index}].action must be non-empty")
            if str(action_obj.get("requirement_ref")) not in requirement_ids:
                errors.append(f"scope_firewall.authorized_actions[{index}] has no in-scope requirement link")

    if obj.get("auto_import") is not False:
        errors.append("scope_firewall.auto_import must be false")
    expansion = obj.get("scope_expansion")
    if expansion not in {"NOT_REQUIRED", "USER_APPROVED"}:
        errors.append("scope_firewall.scope_expansion must be NOT_REQUIRED or USER_APPROVED")
    elif expansion == "USER_APPROVED" and not nonempty(obj.get("scope_expansion_basis")):
        errors.append("USER_APPROVED scope expansion requires scope_expansion_basis")
    if obj.get("user_output") != "FINAL_ONLY":
        errors.append("scope_firewall.user_output must be FINAL_ONLY")

    budget = require_object(
        obj.get("execution_budget"),
        {"analysis_design_percent", "product_creation_percent", "final_validation_percent"},
        "scope_firewall.execution_budget",
        errors,
    )
    values = [
        budget.get("analysis_design_percent"),
        budget.get("product_creation_percent"),
        budget.get("final_validation_percent"),
    ]
    if not all(isinstance(item, (int, float)) and not isinstance(item, bool) for item in values):
        errors.append("scope_firewall.execution_budget values must be numeric")
    elif sum(values) != 100:
        errors.append("scope_firewall.execution_budget must total 100")
    else:
        if values[0] > 30:
            errors.append("scope_firewall analysis/design exceeds 30%")
        if values[1] < 60:
            errors.append("scope_firewall product creation is below 60%")
        if values[2] > 10:
            errors.append("scope_firewall final validation exceeds 10%")

    stop = require_object(
        obj.get("stop_condition"),
        {"deliverable_exists", "explicit_conditions_met", "final_validation_complete", "stop_now"},
        "scope_firewall.stop_condition",
        errors,
    )
    if final_status == "PASS":
        for field in ("deliverable_exists", "explicit_conditions_met", "final_validation_complete", "stop_now"):
            if stop.get(field) is not True:
                errors.append(f"PASS requires scope_firewall.stop_condition.{field}=true")
        if obj.get("status") != "PASS":
            errors.append("PASS requires scope_firewall.status=PASS")


def validate(packet: object) -> list[str]:
    errors: list[str] = []
    if not isinstance(packet, dict):
        return ["packet must be an object"]

    missing = sorted(REQUIRED_TOP - set(packet))
    if missing:
        errors.append(f"packet missing: {', '.join(missing)}")

    for field in ("schema_version", "actual_question", "target", "operation_route"):
        if not nonempty(packet.get(field)):
            errors.append(f"{field} must be non-empty")
    operation_route = packet.get("operation_route")
    if operation_route not in ROUTE_VALIDATORS:
        errors.append(f"operation_route invalid: {operation_route!r}")
    if operation_route == "STRUCTURAL_JOINT_DISCOVERY":
        identity = require_object(
            packet.get("template_identity"),
            set(STRUCTURAL_CANONICAL_IDENTITY),
            "template_identity",
            errors,
        )
        for field, expected in STRUCTURAL_CANONICAL_IDENTITY.items():
            if identity.get(field) != expected:
                errors.append(f"template_identity.{field} must be {expected!r}")

    action = packet.get("action")
    if action not in VALID_ACTIONS:
        errors.append(f"action invalid: {action!r}")

    final_status = packet.get("final_status")
    if final_status not in VALID_FINAL:
        errors.append(f"final_status invalid: {final_status!r}")
    disposition = packet.get("delivery_disposition")
    if disposition not in VALID_DISPOSITIONS:
        errors.append(f"delivery_disposition invalid: {disposition!r}")
    elif final_status in VALID_FINAL and DISPOSITION_MAP[disposition] != final_status:
        errors.append("delivery_disposition does not map to final_status")

    validate_scope_firewall(packet.get("scope_firewall"), str(final_status), errors)

    source_scope = require_object(packet.get("source_scope"), SOURCE_SCOPE_FIELDS, "source_scope", errors)
    included = source_scope.get("included_source_ids")
    if not isinstance(included, list) or not included:
        errors.append("source_scope.included_source_ids must be a non-empty list")
    elif len(included) != len(set(included)):
        errors.append("source_scope.included_source_ids contains duplicates")
    if final_status == "PASS":
        for field in ("admission_verified", "authority_verified"):
            if source_scope.get(field) is not True:
                errors.append(f"PASS requires source_scope.{field}=true")

    family = require_object(packet.get("file_family"), FILE_FAMILY_FIELDS, "file_family", errors)
    for field in ("family_id", "filename_pattern", "block_order", "ending_meta"):
        if not nonempty(family.get(field)):
            errors.append(f"file_family.{field} must be non-empty")

    sources = packet.get("input_sources")
    source_ids: set[str] = set()
    if not isinstance(sources, list) or not sources:
        errors.append("input_sources must be a non-empty list")
    else:
        required = {
            "source_id", "name_or_path", "authority_state", "material_state",
            "sc_verified", "sc_verification_basis", "created_at", "created_at_source",
            "admission_basis", "read_scope", "allowed_uses", "prohibited_uses",
        }
        for index, source in enumerate(sources):
            obj = require_object(source, required, f"input_sources[{index}]", errors)
            errors.extend(validate_source_admission(obj, f"input_sources[{index}]"))
            source_id = obj.get("source_id")
            if not nonempty(source_id):
                errors.append(f"input_sources[{index}].source_id must be non-empty")
            elif source_id in source_ids:
                errors.append(f"duplicate input source: {source_id}")
            else:
                source_ids.add(str(source_id))
            if obj.get("authority_state") != "ACTIVE":
                errors.append(f"input_sources[{index}] is not ACTIVE")
            if obj.get("material_state") != "PARSED":
                errors.append(f"input_sources[{index}] is not PARSED")
            source_identity = " ".join(
                str(obj.get(field, ""))
                for field in ("source_id", "name_or_path")
            ).casefold()
            if any(token in source_identity for token in VOID_SOURCE_NAME_TOKENS):
                errors.append(f"input_sources[{index}] uses an explicitly VOID R4 source")

    if isinstance(included, list):
        unknown = sorted(set(included) - source_ids)
        if unknown:
            errors.append(f"included Source IDs missing from input_sources: {', '.join(unknown)}")

    separation = require_object(packet.get("source_separation"), SOURCE_LANES, "source_separation", errors)
    for lane in SOURCE_LANES:
        lane_obj = require_object(separation.get(lane), {"status", "source_ids"}, f"source_separation.{lane}", errors)
        lane_status = lane_obj.get("status")
        lane_ids = lane_obj.get("source_ids")
        if lane_status not in VALID_LANE:
            errors.append(f"source_separation.{lane}.status invalid: {lane_status!r}")
        if not isinstance(lane_ids, list):
            errors.append(f"source_separation.{lane}.source_ids must be a list")
        elif lane_status == "APPLICABLE" and not lane_ids:
            errors.append(f"source_separation.{lane} APPLICABLE requires Source IDs")
        elif lane_status == "NOT_APPLICABLE" and lane_ids:
            errors.append(f"source_separation.{lane} NOT_APPLICABLE must not carry Source IDs")
        elif any(source_id not in source_ids for source_id in lane_ids):
            errors.append(f"source_separation.{lane} references unknown Source ID")
        if final_status == "PASS" and lane_status == "HOLD":
            errors.append(f"PASS cannot retain HOLD lane: {lane}")

    stages = packet.get("stage_roles")
    if not isinstance(stages, list) or not stages:
        errors.append("stage_roles must be a non-empty list")
    else:
        seen_stage_ids: set[str] = set()
        for index, stage in enumerate(stages):
            obj = require_object(stage, STAGE_FIELDS, f"stage_roles[{index}]", errors)
            stage_id = str(obj.get("stage_id", ""))
            if not stage_id:
                errors.append(f"stage_roles[{index}].stage_id must be non-empty")
            elif stage_id in seen_stage_ids:
                errors.append(f"duplicate stage_id: {stage_id}")
            seen_stage_ids.add(stage_id)
            for field in ("input_refs", "operation", "output", "handoff_to"):
                if not nonempty(obj.get(field)):
                    errors.append(f"stage_roles[{index}].{field} must be non-empty")
            if obj.get("evidence_grade") not in VALID_EVIDENCE:
                errors.append(f"stage_roles[{index}].evidence_grade invalid")
            stage_status = obj.get("status")
            if stage_status not in VALID_STAGE:
                errors.append(f"stage_roles[{index}].status invalid")
            elif final_status == "PASS" and stage_status not in {"PASS", "NOT_APPLICABLE"}:
                errors.append(f"PASS has unresolved stage: {stage_id}")

    batch = require_object(
        packet.get("batch_scope"),
        {
            "unit", "expected_job_count", "actual_job_count", "unique_target_count",
            "duplicate_target_count", "d_chart_set", "coordinate_map_stage",
            "coordinate_scan_count", "downstream_rescan",
        },
        "batch_scope",
        errors,
    )
    if batch.get("unit") != "ONE_D_CHART_X_ONE_HOUSE_X_ONE_VIEW":
        errors.append("batch_scope.unit must be ONE_D_CHART_X_ONE_HOUSE_X_ONE_VIEW")
    if batch.get("d_chart_set") != DEFAULT_20D:
        errors.append("batch_scope.d_chart_set must include D5, exclude VOID D50, and match the fixed 20D order")
    if not nonempty(batch.get("coordinate_map_stage")):
        errors.append("batch_scope.coordinate_map_stage must be non-empty")
    if batch.get("coordinate_scan_count") != 1:
        errors.append("batch_scope.coordinate_scan_count must be exactly 1")
    if batch.get("downstream_rescan") is not False:
        errors.append("batch_scope.downstream_rescan must be false")
    counts = [batch.get("expected_job_count"), batch.get("actual_job_count"), batch.get("unique_target_count"), batch.get("duplicate_target_count")]
    if not all(isinstance(value, int) and value >= 0 for value in counts):
        errors.append("batch_scope counts must be non-negative integers")
    elif final_status == "PASS":
        expected, actual, unique, duplicates = counts
        if expected <= 0 or actual != expected or unique != expected or duplicates != 0:
            errors.append("PASS requires exact, unique, duplicate-free Job counts")

    require_object(packet.get("application_route"), {"route_id", "ordered_steps", "route_validator", "route_validation_status"}, "application_route", errors)
    route = packet.get("application_route")
    if isinstance(route, dict):
        if route.get("route_id") != operation_route:
            errors.append("application_route.route_id must match operation_route")
        validators = route.get("route_validator")
        validator_list = [validators] if isinstance(validators, str) else validators
        expected_validators = ROUTE_VALIDATORS.get(str(operation_route))
        if validator_list != expected_validators:
            errors.append("application_route.route_validator does not match route contract")
        expected_steps = ROUTE_STEPS.get(str(operation_route))
        if route.get("ordered_steps") != expected_steps:
            errors.append("application_route.ordered_steps does not match route contract")
    if isinstance(route, dict) and final_status == "PASS":
        if not nonempty(route.get("ordered_steps")) or not nonempty(route.get("route_validator")):
            errors.append("PASS requires an ordered route and route validator")
        if route.get("route_validation_status") != "PASS":
            errors.append("PASS requires route_validation_status=PASS")

    topology = require_object(packet.get("template_topology"), {"block_order", "placeholder_bindings", "ending_meta", "divider_line", "topology_status"}, "template_topology", errors)
    if final_status == "PASS" and topology.get("topology_status") != "PASS":
        errors.append("PASS requires template_topology.topology_status=PASS")
    if topology.get("divider_line") != "━" * 24:
        errors.append("template_topology.divider_line must contain exactly 24 ━ characters")

    validate_gate_map(packet.get("raw_check"), RAW_GATES, "raw_check", str(final_status), errors)
    validate_gate_map(packet.get("link_check"), LINK_GATES, "link_check", str(final_status), errors)
    validate_gate_map(packet.get("validation_passes"), PASS_FIELDS, "validation_passes", str(final_status), errors)

    pilot = require_object(packet.get("pilot"), {"target_key", "status", "skip_authorized", "evidence"}, "pilot", errors)
    if final_status == "PASS" and not (pilot.get("status") == "PASS" or pilot.get("skip_authorized") is True):
        errors.append("PASS requires pilot PASS or explicit skip_authorized")

    output = require_object(packet.get("final_output"), FINAL_OUTPUT_FIELDS, "final_output", errors)
    if final_status == "PASS":
        if output.get("exists") is not True or output.get("reopened") is not True:
            errors.append("PASS requires final output existence and reopen verification")
        if output.get("ending_meta_verified") is not True:
            errors.append("PASS requires ending meta verification")
        paths = output.get("paths")
        file_count = output.get("file_count")
        if not isinstance(paths, list) or not paths or file_count != len(paths):
            errors.append("final_output.file_count must match non-empty paths")
        archive_status = output.get("archive_extract_verified")
        if archive_status not in {True, "NOT_APPLICABLE"}:
            errors.append("archive_extract_verified must be true or NOT_APPLICABLE")
        if output.get("final_only") is not True:
            errors.append("PASS requires final_output.final_only=true")
        if output.get("stop_condition_met") is not True:
            errors.append("PASS requires final_output.stop_condition_met=true")

    holds = packet.get("holds")
    conflicts = packet.get("conflicts")
    if not isinstance(holds, list) or not isinstance(conflicts, list):
        errors.append("holds and conflicts must be lists")
    elif final_status == "PASS" and (holds or conflicts):
        errors.append("PASS cannot retain holds or conflicts")

    if disposition == "PASS_WITH_BOUNDARY_NOTE" and not nonempty(packet.get("boundary_note")):
        errors.append("PASS_WITH_BOUNDARY_NOTE requires boundary_note")
    if disposition == "PASS_AFTER_PATCH" and packet.get("patch_revalidation") is not True:
        errors.append("PASS_AFTER_PATCH requires patch_revalidation=true")
    if disposition == "REVISE_REQUIRED" and not nonempty(packet.get("revision_locations")):
        errors.append("REVISE_REQUIRED requires revision_locations")

    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet", type=Path, help="JSON lifecycle packet to validate")
    args = parser.parse_args()
    try:
        packet = json.loads(args.packet.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"HOLD: cannot read packet: {exc}", file=sys.stderr)
        return 2
    errors = validate(packet)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
