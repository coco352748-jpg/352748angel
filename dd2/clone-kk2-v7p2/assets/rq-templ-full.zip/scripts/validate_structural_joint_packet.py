#!/usr/bin/env python3
"""Validate the standalone D Rashi–N-house structural-joint discovery packet."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from source_admission import validate_source_admission
from validate_fixed_knife_sentence_output import FIXED_TITLES


DEFAULT_20D = [
    "D1", "D9", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D10",
    "D11", "D12", "D16", "D20", "D24", "D27", "D30", "D40", "D45", "D60",
]
HOUSES = [f"H{number:02d}" for number in range(1, 13)]
VERTICAL_CLASSES = {
    "SAME_STRUCTURE",
    "SIMILAR_STRUCTURE",
    "RARE_STRUCTURE",
    "CONCENTRATED_STRUCTURE",
    "CROSS_REPEAT",
    "NO_CONFIRMED_MATCH",
    "HOLD",
}
VERTICAL_SUMMARY_KEYS = {
    "same_structure",
    "similar_structure",
    "rare_structure",
    "concentrated_structure",
    "cross_repeat",
}
HORIZONTAL_ROLES = {
    "INPUT_POINT",
    "TRANSFER_POINT",
    "BOTTLENECK_POINT",
    "AMPLIFICATION_POINT",
    "TRANSITION_POINT",
    "ATTRIBUTION_POINT",
    "RECOVERY_POINT",
    "NONE_CONFIRMED",
    "HOLD",
}
OPERATION_FACES = {
    "INPUT", "PRESSURE", "TRANSFER", "BOTTLENECK", "REVERSAL",
    "ARRIVAL", "ATTRIBUTION", "RETENTION", "RECOVERY",
}
WORDING_LEVELS = {"STRONG", "MODERATE", "CONDITIONAL", "HOLD"}
ROUTER_LANES = [
    "S01_RASHI",
    "S02_BHAVA",
    "S03_CO2_FIRST_PASS",
    "S04_VEDIC_CO2",
    "S05_SHADBALA_DRISHTI_ASPECT01",
    "S06_SPIRIT_CHALIT",
    "S07_BHINNA",
    "S08_SAP",
    "S09_TKS",
    "S10_EKS",
    "S11_SDP",
    "S12_VARGA_MINI",
    "S13_VARGA_FULL",
    "S14_DASHA",
    "S15_TIMING_GATE",
    "S16_AVA",
]
ROUTER_LANE_STATES = {"PASS", "HOLD", "NOT_PARSED", "NOT_APPLICABLE"}
TIERS = {"PRIMARY", "SUPPORT", "RESERVE"}
STATUSES = {"PASS", "REVISE", "HOLD"}
FINAL_STATUSES = {"PASS", "REVISE", "HOLD", "PENDING"}
EVIDENCE_GRADES = {"DIRECT_SOURCE", "DERIVED"}
INDEPENDENT_AXES = {
    "strength", "authority", "support", "pressure", "frequency", "rarity_repetition",
}
FORBIDDEN_PIKACHU_FIELDS = {
    "premap_execution",
    "master_execution_01_20",
    "post_bottleneck_execution_01_11",
    "pikachu_sc_order_lock_id",
}
FORBIDDEN_SCORE_KEYS = {
    "aggregate_score", "composite_score", "overall_score", "weighted_score",
}
VOID_SOURCE_NAME_TOKENS = {
    "ddchart_mj01_fna98_r4",
}
REQUIRED_TOP = {
    "schema_version",
    "actual_question",
    "template_id",
    "template_version",
    "template_authority",
    "operation_mode",
    "pikachu_dependency",
    "source_admission_policy",
    "target",
    "source_router_16",
    "source_packet",
    "evidence_registry",
    "vertical_20d_axis",
    "horizontal_target_d_axis",
    "final_structural_crosspoint",
    "joint_bank",
    "primary_shortfall",
    "allocation_01_20",
    "sentence_reverse_map",
    "axis_non_addition_lock",
    "minimum_final_gate",
    "human_output",
    "qa",
    "final_status",
}
REQUIRED_SOURCE = {
    "source_id", "source_role", "name_or_path", "authority", "authority_state",
    "material_state", "read_scope", "identity_or_hash", "allowed_uses", "prohibited_uses",
}
REQUIRED_JOINT = {
    "joint_id", "joint_signature", "tier", "source_structure_values", "start_point",
    "input_or_pressure", "transfers_to_next", "structural_centrality", "transfer_impact",
    "bottleneck_formation", "bottleneck_reversal_potential", "result_arrival_location",
    "result_attribution", "result_retention", "recovery_potential", "connections",
    "nonduplication_basis", "vertical_rarity_or_repetition", "horizontal_importance",
    "crosspoint_distance_directness", "evidence_refs", "evidence_grade", "status",
    "hold_reason",
}
QA_GATES = {
    "target_lock",
    "source_admission",
    "source_router_16",
    "varga_full_mini",
    "vertical_20d_completeness",
    "horizontal_12h_completeness",
    "crosspoint",
    "primary_joint_count",
    "joint_nonduplication",
    "allocation_01_20",
    "semantic_nonduplication",
    "reverse_mapping",
    "axis_non_addition",
    "minimum_final_gate",
    "human_output",
    "unsupported_claims",
}


def nonempty(value: Any) -> bool:
    return value is not None and value != "" and value != [] and value != {}


def missing_keys(obj: object, required: set[str], label: str, errors: list[str]) -> None:
    if not isinstance(obj, dict):
        errors.append(f"{label} must be an object")
        return
    missing = sorted(required - set(obj))
    if missing:
        errors.append(f"{label} missing: {', '.join(missing)}")


def normalized(value: Any) -> str:
    return " ".join(str(value).casefold().split())


def require_nonempty(obj: dict[str, Any], fields: set[str], label: str, errors: list[str]) -> None:
    for field in sorted(fields):
        if not nonempty(obj.get(field)):
            errors.append(f"{label} empty: {field}")


def validate_evidence_refs(
    refs: object,
    known_evidence: set[str],
    label: str,
    errors: list[str],
    allow_empty: bool = False,
) -> None:
    if not isinstance(refs, list):
        errors.append(f"{label} must be a list")
        return
    if not refs and not allow_empty:
        errors.append(f"{label} must not be empty")
    for ref in refs:
        if ref not in known_evidence:
            errors.append(f"{label} references unknown evidence: {ref}")


def find_forbidden_scores(value: object, path: str = "packet") -> list[str]:
    errors: list[str] = []
    if isinstance(value, dict):
        for key, child in value.items():
            key_norm = str(key).casefold()
            if key_norm in FORBIDDEN_SCORE_KEYS:
                errors.append(f"{path}.{key} is a forbidden cross-axis score")
            if key_norm == "combined_total_score" and child is not False:
                errors.append(f"{path}.{key} must be false")
            errors.extend(find_forbidden_scores(child, f"{path}.{key}"))
    elif isinstance(value, list):
        for idx, child in enumerate(value):
            errors.extend(find_forbidden_scores(child, f"{path}[{idx}]"))
    return errors


def validate_source_router(
    router: object,
    known_source_ids: set[str],
    final_status: str,
    errors: list[str],
) -> None:
    required = {"lanes", "routing_status", "hold_reason"}
    missing_keys(router, required, "source_router_16", errors)
    if not isinstance(router, dict):
        return
    lanes = router.get("lanes")
    if not isinstance(lanes, list) or len(lanes) != 16:
        errors.append("source_router_16.lanes must contain exactly 16 lane records")
        return
    seen: list[str] = []
    for index, lane in enumerate(lanes):
        label = f"source_router_16.lanes[{index}]"
        required_lane = {
            "lane_id", "source_ids", "material_state", "applicability_state",
            "status", "hold_reason",
        }
        missing_keys(lane, required_lane, label, errors)
        if not isinstance(lane, dict):
            continue
        lane_id = str(lane.get("lane_id", ""))
        seen.append(lane_id)
        source_ids = lane.get("source_ids")
        if not isinstance(source_ids, list):
            errors.append(f"{label}.source_ids must be a list")
            source_ids = []
        unknown = sorted(set(source_ids) - known_source_ids)
        if unknown:
            errors.append(f"{label} references unknown Source IDs: {', '.join(unknown)}")
        status = lane.get("status")
        if status not in ROUTER_LANE_STATES:
            errors.append(f"{label}.status is invalid")
        if status == "PASS" and not source_ids:
            errors.append(f"{label} PASS requires a resolved Source ID")
        if status in {"HOLD", "NOT_PARSED"} and not nonempty(lane.get("hold_reason")):
            errors.append(f"{label}.{status} requires hold_reason")
        if status == "NOT_APPLICABLE" and source_ids:
            errors.append(f"{label} NOT_APPLICABLE must not carry Source IDs")
    if seen != ROUTER_LANES:
        errors.append("source_router_16 lane IDs must be S01-S16 exactly once and in order")
    if router.get("routing_status") != "PASS":
        errors.append("source_router_16.routing_status must be PASS after routing")
    lane_index = {
        str(lane.get("lane_id")): lane
        for lane in lanes
        if isinstance(lane, dict)
    }
    for required_lane in ("S12_VARGA_MINI", "S13_VARGA_FULL"):
        if lane_index.get(required_lane, {}).get("status") != "PASS":
            errors.append(f"{required_lane} must be PASS before structural discovery")


def validate_minimum_final_gate(gate: object, final_status: str, errors: list[str]) -> None:
    required = {
        "gate_01_source_entry",
        "gate_02_independent_allocation",
        "gate_03_reverse_mapping",
        "status",
        "hold_reason",
    }
    missing_keys(gate, required, "minimum_final_gate", errors)
    if not isinstance(gate, dict):
        return
    for field in (
        "gate_01_source_entry",
        "gate_02_independent_allocation",
        "gate_03_reverse_mapping",
    ):
        if gate.get(field) not in {"PASS", "REVISE", "HOLD"}:
            errors.append(f"minimum_final_gate.{field} is invalid")
    if gate.get("status") not in {"PASS", "REVISE", "HOLD"}:
        errors.append("minimum_final_gate.status is invalid")
    if final_status == "PASS":
        unresolved = [
            field for field in required - {"status", "hold_reason"}
            if gate.get(field) != "PASS"
        ]
        if unresolved or gate.get("status") != "PASS":
            errors.append("final PASS requires all minimum_final_gate checks PASS")


def validate_human_output(output: object, final_status: str, errors: list[str]) -> None:
    required = {
        "target_title", "slot_count", "dynamic_titles", "ending_meta",
        "artifact_path", "output_validation_status", "status", "hold_reason",
    }
    missing_keys(output, required, "human_output", errors)
    if not isinstance(output, dict):
        return
    titles = output.get("dynamic_titles")
    if not isinstance(titles, list) or len(titles) != 20:
        errors.append("human_output.dynamic_titles must contain exactly 20 titles")
    elif len({normalized(title) for title in titles}) != 20:
        errors.append("human_output.dynamic_titles must be unique")
    if output.get("slot_count") != 20:
        errors.append("human_output.slot_count must be 20")
    if final_status == "PASS":
        require_nonempty(
            output,
            {"target_title", "ending_meta", "artifact_path"},
            "human_output",
            errors,
        )
        if output.get("output_validation_status") != "PASS" or output.get("status") != "PASS":
            errors.append("final PASS requires human_output validator PASS")


def validate_sources(sources: object, errors: list[str]) -> tuple[set[str], set[str]]:
    source_ids: set[str] = set()
    roles: set[str] = set()
    if not isinstance(sources, list) or not sources:
        errors.append("source_packet must be a non-empty list")
        return source_ids, roles
    for idx, source in enumerate(sources):
        label = f"source_packet[{idx}]"
        missing_keys(source, REQUIRED_SOURCE, label, errors)
        if not isinstance(source, dict):
            continue
        errors.extend(validate_source_admission(source, label))
        require_nonempty(source, REQUIRED_SOURCE, label, errors)
        source_id = source.get("source_id")
        if source_id in source_ids:
            errors.append(f"duplicate source_id: {source_id}")
        elif nonempty(source_id):
            source_ids.add(str(source_id))
        role = source.get("source_role")
        if nonempty(role):
            roles.add(str(role))
        if source.get("authority_state") != "ACTIVE":
            errors.append(f"{label} is not ACTIVE")
        if source.get("material_state") != "PARSED":
            errors.append(f"{label} is not PARSED")
        source_identity = " ".join(
            str(source.get(field, ""))
            for field in ("source_id", "name_or_path")
        ).casefold()
        if any(token in source_identity for token in VOID_SOURCE_NAME_TOKENS):
            errors.append(f"{label} uses an explicitly VOID R4 source")
    for required_role in {"VARGA_FULL", "VARGA_MINI"}:
        if required_role not in roles:
            errors.append(f"source_packet missing role: {required_role}")
    return source_ids, roles


def validate_evidence(
    registry: object,
    source_ids: set[str],
    errors: list[str],
) -> set[str]:
    evidence_ids: set[str] = set()
    if not isinstance(registry, list) or not registry:
        errors.append("evidence_registry must be a non-empty list")
        return evidence_ids
    required = {
        "evidence_id", "source_id", "source_locator", "source_value", "grade",
        "approved_rule_ref", "status",
    }
    for idx, evidence in enumerate(registry):
        label = f"evidence_registry[{idx}]"
        missing_keys(evidence, required, label, errors)
        if not isinstance(evidence, dict):
            continue
        evidence_id = evidence.get("evidence_id")
        if evidence_id in evidence_ids:
            errors.append(f"duplicate evidence_id: {evidence_id}")
        elif nonempty(evidence_id):
            evidence_ids.add(str(evidence_id))
        if evidence.get("source_id") not in source_ids:
            errors.append(f"{label} points to an inadmissible or unknown source")
        require_nonempty(
            evidence,
            {"evidence_id", "source_id", "source_locator", "source_value", "grade", "status"},
            label,
            errors,
        )
        if evidence.get("grade") not in EVIDENCE_GRADES:
            errors.append(f"{label}.grade must be DIRECT_SOURCE or DERIVED")
        if evidence.get("grade") == "DERIVED" and not nonempty(evidence.get("approved_rule_ref")):
            errors.append(f"{label} DERIVED evidence requires approved_rule_ref")
        if evidence.get("status") != "PASS":
            errors.append(f"{label} must be PASS before it enters the registry")
    return evidence_ids


def validate_vertical(
    axis: object,
    evidence_ids: set[str],
    target_house: str,
    final_status: str,
    errors: list[str],
) -> None:
    required = {
        "d_set", "d_set_basis", "d_set_evidence_refs", "comparison_by_d",
        "classification_summary", "target_relative_position", "target_structural_importance",
        "importance_basis", "evidence_refs", "status", "hold_reason",
    }
    missing_keys(axis, required, "vertical_20d_axis", errors)
    if not isinstance(axis, dict):
        return
    d_set = axis.get("d_set")
    if not isinstance(d_set, list) or len(d_set) != 20 or len(set(d_set)) != 20:
        errors.append("vertical_20d_axis.d_set must contain 20 unique D charts")
        d_set = []
    if axis.get("d_set_basis") == "DEFAULT_20D" and d_set != DEFAULT_20D:
        errors.append("DEFAULT_20D order or membership changed")
    elif axis.get("d_set_basis") not in {"DEFAULT_20D", "SOURCE_DECLARED_20D"}:
        errors.append("vertical_20d_axis.d_set_basis is invalid")
    validate_evidence_refs(axis.get("d_set_evidence_refs"), evidence_ids, "vertical_20d_axis.d_set_evidence_refs", errors, axis.get("d_set_basis") == "DEFAULT_20D")

    rows = axis.get("comparison_by_d")
    seen: list[str] = []
    if not isinstance(rows, list) or len(rows) != 20:
        errors.append("vertical_20d_axis.comparison_by_d must contain 20 rows")
    else:
        for idx, row in enumerate(rows):
            label = f"vertical_20d_axis.comparison_by_d[{idx}]"
            required_row = {"d_chart", "house_id", "structural_signature", "classification_tags", "evidence_refs", "status", "hold_reason"}
            missing_keys(row, required_row, label, errors)
            if not isinstance(row, dict):
                continue
            d_chart = row.get("d_chart")
            seen.append(str(d_chart))
            if row.get("house_id") != target_house:
                errors.append(f"{label}.house_id must equal target house {target_house}")
            tags = row.get("classification_tags")
            if not isinstance(tags, list) or not tags:
                errors.append(f"{label}.classification_tags must be non-empty")
            elif not set(tags).issubset(VERTICAL_CLASSES):
                errors.append(f"{label}.classification_tags contains an invalid class")
            validate_evidence_refs(row.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, row.get("status") == "HOLD")
            if row.get("status") not in STATUSES:
                errors.append(f"{label}.status is invalid")
            if row.get("status") == "PASS" and not nonempty(row.get("structural_signature")):
                errors.append(f"{label}.structural_signature is required for PASS")
            if row.get("status") == "HOLD" and not nonempty(row.get("hold_reason")):
                errors.append(f"{label}.hold_reason is required")
            if final_status == "PASS" and row.get("status") != "PASS":
                errors.append(f"final PASS requires {label} PASS")
        if seen != d_set:
            errors.append("vertical comparison rows must match d_set exactly once and in order")

    summary = axis.get("classification_summary")
    missing_keys(summary, VERTICAL_SUMMARY_KEYS, "vertical_20d_axis.classification_summary", errors)
    if isinstance(summary, dict):
        for key in VERTICAL_SUMMARY_KEYS:
            item = summary.get(key)
            label = f"vertical_20d_axis.classification_summary.{key}"
            missing_keys(item, {"members", "evidence_refs", "status", "hold_reason"}, label, errors)
            if not isinstance(item, dict):
                continue
            members = item.get("members")
            if not isinstance(members, list) or not set(members).issubset(set(d_set)):
                errors.append(f"{label}.members must be a subset of d_set")
            validate_evidence_refs(item.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, not members or item.get("status") == "HOLD")
            if item.get("status") not in {"PASS", "HOLD"}:
                errors.append(f"{label}.status must be PASS or HOLD")
            if item.get("status") == "HOLD" and not nonempty(item.get("hold_reason")):
                errors.append(f"{label}.hold_reason is required")
            if final_status == "PASS" and item.get("status") != "PASS":
                errors.append(f"final PASS requires {label} PASS")
    validate_evidence_refs(axis.get("evidence_refs"), evidence_ids, "vertical_20d_axis.evidence_refs", errors, axis.get("status") == "HOLD")
    if axis.get("status") == "PASS":
        require_nonempty(
            axis,
            {"target_relative_position", "target_structural_importance", "importance_basis", "evidence_refs"},
            "vertical_20d_axis",
            errors,
        )
    if final_status == "PASS" and axis.get("status") != "PASS":
        errors.append("final PASS requires vertical_20d_axis PASS")


def validate_horizontal(axis: object, evidence_ids: set[str], final_status: str, errors: list[str]) -> None:
    required = {
        "houses", "target_relative_position", "target_structural_importance", "importance_basis",
        "evidence_refs", "status", "hold_reason",
    }
    missing_keys(axis, required, "horizontal_target_d_axis", errors)
    if not isinstance(axis, dict):
        return
    rows = axis.get("houses")
    seen: list[str] = []
    if not isinstance(rows, list) or len(rows) != 12:
        errors.append("horizontal_target_d_axis.houses must contain 12 rows")
    else:
        for idx, row in enumerate(rows):
            label = f"horizontal_target_d_axis.houses[{idx}]"
            required_row = {
                "house_id", "relation_to_target", "role_codes", "input_or_pressure", "handoff",
                "structural_effect", "evidence_refs", "status", "hold_reason",
            }
            missing_keys(row, required_row, label, errors)
            if not isinstance(row, dict):
                continue
            seen.append(str(row.get("house_id")))
            roles = row.get("role_codes")
            if not isinstance(roles, list) or not roles:
                errors.append(f"{label}.role_codes must be non-empty")
            elif not set(roles).issubset(HORIZONTAL_ROLES):
                errors.append(f"{label}.role_codes contains an invalid role")
            validate_evidence_refs(row.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, row.get("status") == "HOLD")
            if row.get("status") == "PASS":
                require_nonempty(row, {"relation_to_target", "input_or_pressure", "handoff", "structural_effect"}, label, errors)
            if row.get("status") not in STATUSES:
                errors.append(f"{label}.status is invalid")
            if row.get("status") == "HOLD" and not nonempty(row.get("hold_reason")):
                errors.append(f"{label}.hold_reason is required")
            if final_status == "PASS" and row.get("status") != "PASS":
                errors.append(f"final PASS requires {label} PASS")
        if seen != HOUSES:
            errors.append("horizontal rows must be H01-H12 exactly once and in order")
    validate_evidence_refs(axis.get("evidence_refs"), evidence_ids, "horizontal_target_d_axis.evidence_refs", errors, axis.get("status") == "HOLD")
    if axis.get("status") == "PASS":
        require_nonempty(
            axis,
            {"target_relative_position", "target_structural_importance", "importance_basis", "evidence_refs"},
            "horizontal_target_d_axis",
            errors,
        )
    if final_status == "PASS" and axis.get("status") != "PASS":
        errors.append("final PASS requires horizontal_target_d_axis PASS")


def validate_crosspoint(crosspoint: object, evidence_ids: set[str], final_status: str, errors: list[str]) -> None:
    required = {
        "vertical_basis", "horizontal_basis", "crosspoint_role", "structural_centrality",
        "distance_directness", "transfer_impact", "bottleneck_reversal_relation",
        "sentence_intensity", "verb_strength", "word_choice", "certainty", "sentence_width",
        "evidence_refs", "evidence_grade", "status", "hold_reason",
    }
    missing_keys(crosspoint, required, "final_structural_crosspoint", errors)
    if not isinstance(crosspoint, dict):
        return
    validate_evidence_refs(crosspoint.get("evidence_refs"), evidence_ids, "final_structural_crosspoint.evidence_refs", errors, crosspoint.get("status") == "HOLD")
    if crosspoint.get("evidence_grade") not in EVIDENCE_GRADES | {"HOLD"}:
        errors.append("final_structural_crosspoint.evidence_grade is invalid")
    if crosspoint.get("status") == "PASS":
        require_nonempty(crosspoint, required - {"hold_reason"}, "final_structural_crosspoint", errors)
    if final_status == "PASS" and crosspoint.get("status") != "PASS":
        errors.append("final PASS requires final_structural_crosspoint PASS")


def validate_joints(
    joints: object,
    evidence_ids: set[str],
    final_status: str,
    errors: list[str],
) -> tuple[dict[str, dict[str, Any]], int]:
    index: dict[str, dict[str, Any]] = {}
    primary_signatures: set[str] = set()
    if not isinstance(joints, list) or not joints:
        errors.append("joint_bank must be a non-empty list")
        return index, 0
    for idx, joint in enumerate(joints):
        label = f"joint_bank[{idx}]"
        missing_keys(joint, REQUIRED_JOINT, label, errors)
        if not isinstance(joint, dict):
            continue
        joint_id = str(joint.get("joint_id", ""))
        if not joint_id:
            errors.append(f"{label}.joint_id is empty")
        elif joint_id in index:
            errors.append(f"duplicate joint_id: {joint_id}")
        else:
            index[joint_id] = joint
        if joint.get("tier") not in TIERS:
            errors.append(f"{label}.tier is invalid")
        if joint.get("evidence_grade") not in EVIDENCE_GRADES | {"HOLD"}:
            errors.append(f"{label}.evidence_grade is invalid")
        if joint.get("status") not in STATUSES:
            errors.append(f"{label}.status is invalid")
        validate_evidence_refs(joint.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, joint.get("status") == "HOLD")
        if joint.get("status") == "PASS":
            require_nonempty(joint, REQUIRED_JOINT - {"hold_reason"}, label, errors)
        if joint.get("status") == "HOLD" and not nonempty(joint.get("hold_reason")):
            errors.append(f"{label}.hold_reason is required")
        if joint.get("tier") == "PRIMARY":
            signature = normalized(joint.get("joint_signature"))
            if signature in primary_signatures:
                errors.append(f"duplicate PRIMARY joint_signature: {joint.get('joint_signature')}")
            primary_signatures.add(signature)
    if final_status == "PASS" and any(j.get("status") != "PASS" for j in index.values()):
        errors.append("final PASS cannot retain unresolved joints")
    primary_count = sum(1 for joint in index.values() if joint.get("tier") == "PRIMARY" and joint.get("status") == "PASS")
    return index, primary_count


def validate_shortfall(shortfall: object, primary_count: int, final_status: str, errors: list[str]) -> None:
    required = {"required_count", "available_count", "missing_count", "status", "hold_reason"}
    missing_keys(shortfall, required, "primary_shortfall", errors)
    if not isinstance(shortfall, dict):
        return
    if shortfall.get("required_count") != 20:
        errors.append("primary_shortfall.required_count must be 20")
    if shortfall.get("available_count") != primary_count:
        errors.append("primary_shortfall.available_count does not match PASS PRIMARY count")
    expected_missing = max(0, 20 - primary_count)
    if shortfall.get("missing_count") != expected_missing:
        errors.append("primary_shortfall.missing_count is wrong")
    if expected_missing:
        if shortfall.get("status") != "HOLD" or not nonempty(shortfall.get("hold_reason")):
            errors.append("PRIMARY shortage requires HOLD and hold_reason")
        if final_status == "PASS":
            errors.append("final PASS requires at least 20 PASS PRIMARY joints")
    elif shortfall.get("status") != "NOT_APPLICABLE":
        errors.append("no PRIMARY shortage requires NOT_APPLICABLE")


def validate_allocations(
    allocations: object,
    joint_index: dict[str, dict[str, Any]],
    evidence_ids: set[str],
    final_status: str,
    errors: list[str],
) -> None:
    required = {
        "stage_no", "slot_title", "stage_function", "stage_question", "primary_joint_ids", "support_joint_ids",
        "reserve_joint_ids", "operation_face", "most_important", "why_this_joint_owns_stage",
        "loss_if_omitted", "distinctness_signature", "wording_level", "evidence_refs", "status", "hold_reason",
    }
    if not isinstance(allocations, list) or len(allocations) != 20:
        errors.append("allocation_01_20 must contain exactly 20 stages")
        return
    expected = [f"{number:02d}" for number in range(1, 21)]
    seen: list[str] = []
    signatures: dict[tuple[str, str, str, str], str] = {}
    slot_titles: dict[str, str] = {}
    slot_title_vector: list[str] = []
    joint_faces: dict[tuple[str, str], str] = {}
    for idx, stage in enumerate(allocations):
        label = f"allocation_01_20[{idx}]"
        missing_keys(stage, required, label, errors)
        if not isinstance(stage, dict):
            continue
        stage_no = str(stage.get("stage_no"))
        seen.append(stage_no)
        if stage.get("operation_face") not in OPERATION_FACES:
            errors.append(f"{label}.operation_face is invalid")
        if stage.get("wording_level") not in WORDING_LEVELS:
            errors.append(f"{label}.wording_level is invalid")
        status = stage.get("status")
        if status not in STATUSES:
            errors.append(f"{label}.status is invalid")
        primary_ids = stage.get("primary_joint_ids")
        if status == "PASS" and (not isinstance(primary_ids, list) or not primary_ids):
            errors.append(f"{label} PASS requires a PRIMARY joint")
        for field, tier in (
            ("primary_joint_ids", "PRIMARY"),
            ("support_joint_ids", "SUPPORT"),
            ("reserve_joint_ids", "RESERVE"),
        ):
            ids = stage.get(field)
            if not isinstance(ids, list):
                errors.append(f"{label}.{field} must be a list")
                continue
            if len(ids) != len(set(ids)):
                errors.append(f"{label}.{field} contains duplicate IDs")
            for joint_id in ids:
                joint = joint_index.get(str(joint_id))
                if joint is None:
                    errors.append(f"{label}.{field} references unknown joint: {joint_id}")
                elif joint.get("tier") != tier:
                    errors.append(f"{label}.{field} tier mismatch: {joint_id}")
                elif status == "PASS" and joint.get("status") != "PASS":
                    errors.append(f"{label} uses unresolved joint: {joint_id}")
                if status == "PASS":
                    face_key = (str(joint_id), str(stage.get("operation_face")))
                    if face_key in joint_faces:
                        errors.append(
                            f"same joint and operation_face reused in {joint_faces[face_key]} and {stage_no}: {joint_id}"
                        )
                    joint_faces[face_key] = stage_no
        signature = stage.get("distinctness_signature")
        sig_fields = {"function", "causal_path", "result", "conclusion"}
        missing_keys(signature, sig_fields, f"{label}.distinctness_signature", errors)
        if isinstance(signature, dict) and status == "PASS":
            require_nonempty(signature, sig_fields, f"{label}.distinctness_signature", errors)
            sig_key = tuple(normalized(signature.get(field)) for field in ("function", "causal_path", "result", "conclusion"))
            if sig_key in signatures:
                errors.append(f"duplicate stage distinctness signature: {signatures[sig_key]} and {stage_no}")
            signatures[sig_key] = stage_no
        slot_title = str(stage.get("slot_title", ""))
        slot_title_key = normalized(slot_title)
        slot_title_vector.append(slot_title_key)
        if status == "PASS" and not slot_title_key:
            errors.append(f"{label}.slot_title is required for PASS")
        elif status == "PASS":
            if slot_title_key in slot_titles:
                errors.append(
                    f"duplicate dynamic slot_title: {slot_titles[slot_title_key]} and {stage_no}"
                )
            slot_titles[slot_title_key] = stage_no
        validate_evidence_refs(stage.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, status == "HOLD")
        if status == "PASS":
            require_nonempty(
                stage,
                {"slot_title", "stage_function", "stage_question", "most_important", "why_this_joint_owns_stage", "loss_if_omitted"},
                label,
                errors,
            )
        if status == "HOLD" and not nonempty(stage.get("hold_reason")):
            errors.append(f"{label}.hold_reason is required")
        if final_status == "PASS" and status != "PASS":
            errors.append(f"final PASS requires {label} PASS")
    if seen != expected:
        errors.append("allocation_01_20 stages must be 01-20 exactly once and in order")
    if slot_title_vector == [normalized(title) for title in FIXED_TITLES]:
        errors.append("dynamic allocation copied the complete fixed/calibration title vector")


def validate_reverse_map(
    mappings: object,
    joint_index: dict[str, dict[str, Any]],
    evidence_ids: set[str],
    source_ids: set[str],
    final_status: str,
    errors: list[str],
) -> None:
    required = {
        "stage_no", "knife_sentence_core", "core_clauses", "clause_records", "joint_ids", "evidence_refs",
        "evidence_grade", "mapping_status", "hold_reason",
    }
    if not isinstance(mappings, list) or len(mappings) != 20:
        errors.append("sentence_reverse_map must contain exactly 20 stages")
        return
    expected = [f"{number:02d}" for number in range(1, 21)]
    seen: list[str] = []
    for idx, mapping in enumerate(mappings):
        label = f"sentence_reverse_map[{idx}]"
        missing_keys(mapping, required, label, errors)
        if not isinstance(mapping, dict):
            continue
        seen.append(str(mapping.get("stage_no")))
        status = mapping.get("mapping_status")
        if status not in {"PASS", "HOLD"}:
            errors.append(f"{label}.mapping_status is invalid")
        grade = mapping.get("evidence_grade")
        if grade not in EVIDENCE_GRADES | {"HOLD"}:
            errors.append(f"{label}.evidence_grade is invalid")
        joint_ids = mapping.get("joint_ids")
        if not isinstance(joint_ids, list):
            errors.append(f"{label}.joint_ids must be a list")
        else:
            for joint_id in joint_ids:
                if str(joint_id) not in joint_index:
                    errors.append(f"{label} references unknown joint: {joint_id}")
        clause_records = mapping.get("clause_records")
        if not isinstance(clause_records, list):
            errors.append(f"{label}.clause_records must be a list")
        elif status == "PASS" and not clause_records:
            errors.append(f"{label} PASS requires clause_records")
        else:
            required_clause = {
                "sentence_no", "clause_id", "core_clause", "joint_id", "evidence_id",
                "source_id", "archive_name", "inner_member_name", "source_locator",
                "source_value", "evidence_grade", "vertical_link", "horizontal_link",
                "crosspoint_link", "status",
            }
            for clause_index, clause in enumerate(clause_records):
                clause_label = f"{label}.clause_records[{clause_index}]"
                missing_keys(clause, required_clause, clause_label, errors)
                if not isinstance(clause, dict):
                    continue
                if str(clause.get("sentence_no")) != str(mapping.get("stage_no")):
                    errors.append(f"{clause_label}.sentence_no must match stage_no")
                if str(clause.get("joint_id")) not in joint_index:
                    errors.append(f"{clause_label} references unknown joint")
                if str(clause.get("evidence_id")) not in evidence_ids:
                    errors.append(f"{clause_label} references unknown evidence")
                if str(clause.get("source_id")) not in source_ids:
                    errors.append(f"{clause_label} references unknown source")
                if clause.get("evidence_grade") not in EVIDENCE_GRADES:
                    errors.append(f"{clause_label}.evidence_grade is invalid")
                if clause.get("status") != "PASS":
                    errors.append(f"{clause_label}.status must be PASS")
                require_nonempty(clause, required_clause, clause_label, errors)
        validate_evidence_refs(mapping.get("evidence_refs"), evidence_ids, f"{label}.evidence_refs", errors, status == "HOLD")
        if status == "PASS":
            require_nonempty(mapping, {"knife_sentence_core", "core_clauses", "clause_records", "joint_ids", "evidence_refs"}, label, errors)
            if grade not in EVIDENCE_GRADES:
                errors.append(f"{label} PASS cannot use HOLD evidence")
        if status == "HOLD" and not nonempty(mapping.get("hold_reason")):
            errors.append(f"{label}.hold_reason is required")
        if final_status == "PASS" and status != "PASS":
            errors.append(f"final PASS requires {label} PASS")
    if seen != expected:
        errors.append("sentence_reverse_map stages must be 01-20 exactly once and in order")


def validate_non_addition(lock: object, final_status: str, errors: list[str]) -> None:
    required = {
        "combined_total_score", "combination_method", "independent_axes",
        "rarity_is_not_importance", "repetition_is_not_strength", "status",
    }
    missing_keys(lock, required, "axis_non_addition_lock", errors)
    if not isinstance(lock, dict):
        return
    if lock.get("combined_total_score") is not False:
        errors.append("axis_non_addition_lock.combined_total_score must be false")
    if lock.get("combination_method") != "HIERARCHICAL_ONLY":
        errors.append("axis_non_addition_lock.combination_method must be HIERARCHICAL_ONLY")
    axes = lock.get("independent_axes")
    if not isinstance(axes, dict) or not INDEPENDENT_AXES.issubset(set(axes)):
        errors.append("axis_non_addition_lock.independent_axes is incomplete")
    if lock.get("rarity_is_not_importance") is not True:
        errors.append("rarity_is_not_importance must be true")
    if lock.get("repetition_is_not_strength") is not True:
        errors.append("repetition_is_not_strength must be true")
    if final_status == "PASS" and lock.get("status") != "PASS":
        errors.append("final PASS requires axis_non_addition_lock PASS")


def validate(packet: object) -> list[str]:
    errors: list[str] = []
    missing_keys(packet, REQUIRED_TOP, "packet", errors)
    if not isinstance(packet, dict):
        return errors

    if packet.get("operation_mode") != "STRUCTURAL_JOINT_DISCOVERY":
        errors.append("operation_mode must be STRUCTURAL_JOINT_DISCOVERY")
    if packet.get("template_id") != "DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2":
        errors.append("template_id must be DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2")
    if packet.get("template_version") != "V2_REPAIRED":
        errors.append("template_version must be V2_REPAIRED")
    if packet.get("template_authority") != "ACTIVE_CANONICAL":
        errors.append("template_authority must be ACTIVE_CANONICAL")
    if packet.get("pikachu_dependency") != "NOT_USED":
        errors.append("pikachu_dependency must be NOT_USED")
    for field in sorted(FORBIDDEN_PIKACHU_FIELDS & set(packet)):
        errors.append(f"standalone mode must not include PIKACHU field: {field}")

    final_status = str(packet.get("final_status"))
    if final_status not in FINAL_STATUSES:
        errors.append("final_status is invalid")

    policy = packet.get("source_admission_policy")
    expected_policy = {
        "logic": "SC_VERIFIED_OR_CREATED_AT_CUTOFF",
        "cutoff": "2026-08-09T00:00:00+09:00",
        "cutoff_inclusive": True,
        "modified_at_fallback": "FORBIDDEN",
    }
    missing_keys(policy, set(expected_policy), "source_admission_policy", errors)
    if isinstance(policy, dict):
        for key, expected_value in expected_policy.items():
            if policy.get(key) != expected_value:
                errors.append(f"source_admission_policy.{key} must be {expected_value!r}")

    target = packet.get("target")
    target_required = {
        "d_chart", "house_id", "source_house_token", "d_chart_domain",
        "house_function", "view",
    }
    missing_keys(target, target_required, "target", errors)
    if isinstance(target, dict):
        require_nonempty(target, target_required, "target", errors)
        if target.get("view") != "SOURCE_ROUTED_SEPARATE_LAYERS":
            errors.append("target.view must be SOURCE_ROUTED_SEPARATE_LAYERS")

    source_ids, _ = validate_sources(packet.get("source_packet"), errors)
    validate_source_router(packet.get("source_router_16"), source_ids, final_status, errors)
    evidence_ids = validate_evidence(packet.get("evidence_registry"), source_ids, errors)
    target_house = str(target.get("house_id", "")) if isinstance(target, dict) else ""
    validate_vertical(packet.get("vertical_20d_axis"), evidence_ids, target_house, final_status, errors)
    validate_horizontal(packet.get("horizontal_target_d_axis"), evidence_ids, final_status, errors)
    validate_crosspoint(packet.get("final_structural_crosspoint"), evidence_ids, final_status, errors)
    joint_index, primary_count = validate_joints(packet.get("joint_bank"), evidence_ids, final_status, errors)
    validate_shortfall(packet.get("primary_shortfall"), primary_count, final_status, errors)
    validate_allocations(packet.get("allocation_01_20"), joint_index, evidence_ids, final_status, errors)
    validate_reverse_map(
        packet.get("sentence_reverse_map"),
        joint_index,
        evidence_ids,
        source_ids,
        final_status,
        errors,
    )
    validate_non_addition(packet.get("axis_non_addition_lock"), final_status, errors)
    validate_minimum_final_gate(packet.get("minimum_final_gate"), final_status, errors)
    validate_human_output(packet.get("human_output"), final_status, errors)

    allocations = packet.get("allocation_01_20")
    human_output = packet.get("human_output")
    if isinstance(allocations, list) and isinstance(human_output, dict):
        allocated_titles = [
            str(stage.get("slot_title", ""))
            for stage in allocations
            if isinstance(stage, dict)
        ]
        if human_output.get("dynamic_titles") != allocated_titles:
            errors.append("human_output.dynamic_titles must match allocation slot_title order")

    qa = packet.get("qa")
    missing_keys(qa, QA_GATES, "qa", errors)
    if final_status == "PASS" and isinstance(qa, dict):
        failed = sorted(gate for gate in QA_GATES if qa.get(gate) != "PASS")
        if failed:
            errors.append(f"final PASS has unpassed QA gates: {', '.join(failed)}")

    errors.extend(find_forbidden_scores(packet))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet", type=Path, help="JSON structural-joint packet")
    args = parser.parse_args()
    try:
        packet = json.loads(args.packet.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"HOLD: cannot read packet: {exc}", file=sys.stderr)
        return 2
    errors = validate(packet)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    final_status = packet.get("final_status")
    print("PASS" if final_status == "PASS" else f"SCHEMA_PASS: final_status={final_status}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
