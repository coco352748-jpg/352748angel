#!/usr/bin/env python3
"""Shared Source-admission gate for every rq-templ mode."""

from __future__ import annotations

from datetime import datetime, timezone
import re
from typing import Any


CUTOFF_KST = "2026-08-09T00:00:00+09:00"
CUTOFF_UTC = datetime(2026, 8, 8, 15, 0, 0, tzinfo=timezone.utc)
VALID_SC_BASES = {
    "SC_FILENAME_TOKEN",
    "SC_INTERNAL_MARKER",
    "USER_CONFIRMED_SC",
}
VALID_ADMISSION_BASES = {
    "SC_VERIFIED",
    "CREATED_ON_OR_AFTER_2026_08_09_KST",
}
FORBIDDEN_DATE_SOURCE_MARKERS = {
    "modified",
    "updated",
    "filesystem_mtime",
    "filesystem_ctime",
    "local_copy",
    "download_time",
    "zip_entry",
}
REQUIRED_ADMISSION_FIELDS = {
    "sc_verified",
    "sc_verification_basis",
    "created_at",
    "created_at_source",
    "admission_basis",
}


def parse_iso8601(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    candidate = value.strip()
    if candidate.endswith("Z"):
        candidate = candidate[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(candidate)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc)


def validate_source_admission(source: object, label: str) -> list[str]:
    """Return gate errors. Admission is SC-verified OR created at/after cutoff."""

    if not isinstance(source, dict):
        return [f"{label} must be an object"]

    errors: list[str] = []
    missing = sorted(REQUIRED_ADMISSION_FIELDS - set(source))
    if missing:
        errors.append(f"{label} source-admission fields missing: {', '.join(missing)}")
        return errors

    sc_verified = source.get("sc_verified")
    sc_basis = source.get("sc_verification_basis")
    admission_basis = source.get("admission_basis")
    created_at = parse_iso8601(source.get("created_at"))
    created_at_source = source.get("created_at_source")

    if not isinstance(sc_verified, bool):
        errors.append(f"{label}.sc_verified must be boolean")
        sc_verified = False

    if admission_basis not in VALID_ADMISSION_BASES:
        errors.append(f"{label}.admission_basis is invalid")

    sc_qualifies = sc_verified is True and sc_basis in VALID_SC_BASES
    if sc_verified is True and sc_basis not in VALID_SC_BASES:
        errors.append(f"{label}.sc_verification_basis is not verified")
    if sc_qualifies and sc_basis == "SC_FILENAME_TOKEN":
        name = str(source.get("name_or_path", "")).rsplit("/", 1)[-1]
        if re.search(r"(?:^|[^a-z0-9])sc(?:$|[^a-z0-9])", name, flags=re.IGNORECASE) is None:
            errors.append(f"{label}.name_or_path has no independent SC filename token")
            sc_qualifies = False

    date_qualifies = created_at is not None and created_at >= CUTOFF_UTC
    raw_created_at = source.get("created_at")
    if raw_created_at is not None and raw_created_at != "" and created_at is None:
        errors.append(f"{label}.created_at must be timezone-aware ISO-8601")
    if date_qualifies and not isinstance(created_at_source, str):
        errors.append(f"{label}.created_at_source is required for date admission")
    if date_qualifies and isinstance(created_at_source, str) and not created_at_source.strip():
        errors.append(f"{label}.created_at_source is required for date admission")
    if isinstance(created_at_source, str):
        source_marker = created_at_source.casefold()
        if any(marker in source_marker for marker in FORBIDDEN_DATE_SOURCE_MARKERS):
            errors.append(f"{label}.created_at_source uses a forbidden substitute timestamp")

    if not (sc_qualifies or date_qualifies):
        errors.append(
            f"{label} is inadmissible: require verified SC or created_at >= {CUTOFF_KST}"
        )

    if admission_basis == "SC_VERIFIED" and not sc_qualifies:
        errors.append(f"{label} claims SC_VERIFIED without SC evidence")
    if admission_basis == "CREATED_ON_OR_AFTER_2026_08_09_KST" and not date_qualifies:
        errors.append(f"{label} claims date admission without qualifying created_at")

    return errors
