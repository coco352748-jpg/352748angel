#!/usr/bin/env python3
"""Regression tests for the fixed knife-sentence Source packet validator."""

from __future__ import annotations

import copy
import sys
import unittest
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from validate_fixed_knife_sentence_output import FIXED_TITLES  # noqa: E402
from validate_fixed_knife_sentence_packet import title_vector_sha256, validate  # noqa: E402


def valid_packet() -> dict:
    source = {
        "source_id": "DRIVE-CANONICAL-1",
        "source_role": "CANONICAL",
        "name_or_path": "07_1AB_D10_RaShi_Sc_.txt",
        "authority": "GOOGLE_DRIVE_ACTIVE_CANONICAL",
        "authority_state": "ACTIVE",
        "material_state": "PARSED",
        "read_scope": "TARGET_D_HOUSE_AND_REQUIRED_AXES",
        "identity_or_hash": "sha256:" + "1" * 64,
        "allowed_uses": ["FIXED_KNIFE_SENTENCE_01_20_PATH"],
        "prohibited_uses": ["CANONICAL_AUTO_PROMOTION"],
        "sc_verified": True,
        "sc_verification_basis": "SC_FILENAME_TOKEN",
        "created_at": None,
        "created_at_source": None,
        "admission_basis": "SC_VERIFIED",
    }
    evidence = [
        {
            "evidence_id": f"E-{number:02d}",
            "source_id": "DRIVE-CANONICAL-1",
            "source_locator": f"D10:H10:SLOT-{number:02d}",
            "source_value": f"source-value-{number:02d}",
            "grade": "DIRECT_SOURCE",
            "approved_rule_ref": None,
            "status": "PASS",
        }
        for number in range(1, 21)
    ]
    slots = [
        {
            "slot_no": f"{number:02d}",
            "fixed_slot_title": title,
            "applicable_source_ids": ["DRIVE-CANONICAL-1"],
            "evidence_ids": [f"E-{number:02d}"],
            "direct_fact": f"direct-fact-{number:02d}",
            "why_parent": f"why-parent-{number:02d}",
            "result_boundary": f"result-boundary-{number:02d}",
            "evidence_grade": "DIRECT_SOURCE",
            "assertion_state": "CONFIRMED",
            "status": "PASS",
            "hold_reason": "",
        }
        for number, title in enumerate(FIXED_TITLES, start=1)
    ]
    reverse = [
        {
            "slot_no": f"{number:02d}",
            "clause_id": f"C-{number:02d}-01",
            "core_clause": f"core-clause-{number:02d}",
            "evidence_id": f"E-{number:02d}",
            "source_id": "DRIVE-CANONICAL-1",
            "source_locator": f"D10:H10:SLOT-{number:02d}",
            "source_value": f"source-value-{number:02d}",
            "evidence_grade": "DIRECT_SOURCE",
            "result_boundary": f"result-boundary-{number:02d}",
            "status": "PASS",
        }
        for number in range(1, 21)
    ]
    return {
        "schema_version": "RQ_FIXED_KNIFE_PACKET_V1",
        "template_id": "FIXED_KNIFE_SENTENCE_01_20_FNA98_V1",
        "operation_route": "FIXED_KNIFE_SENTENCE_01_20_PATH",
        "actual_question": "Write D10-H10 with the user fixed knife-sentence template.",
        "target": {
            "d_chart": "D10",
            "house_id": "H10",
            "source_house_token": "10H",
            "d_chart_domain": "career-role-output",
            "house_function": "public-output",
        },
        "source_authority": "GOOGLE_DRIVE_ACTIVE_CANONICAL",
        "chart_value_mode": "FETCH_FROM_DRIVE",
        "unverified_value_generation": "FORBIDDEN",
        "pikachu_dependency": "NOT_USED",
        "dynamic_v2_dependency": "NOT_USED",
        "deep_dense_240h_dependency": "NOT_USED",
        "source_admission_policy": {
            "logic": "SC_VERIFIED_OR_CREATED_AT_CUTOFF",
            "cutoff": "2026-08-09T00:00:00+09:00",
            "cutoff_inclusive": True,
            "modified_at_fallback": "FORBIDDEN",
        },
        "source_provider_lock": {
            "primary_authority": "GOOGLE_DRIVE_ACTIVE_CANONICAL",
            "rq_sc_status": "USED",
            "canonical_auto_promotion": "FORBIDDEN",
            "spirit_chalit_scope": "D1_ONLY",
            "transit_scope": "D1_D9_ONLY",
            "transit_canonical_status": "CANONICAL_STATUS_NOT_DECLARED",
        },
        "source_packet": [source],
        "evidence_registry": evidence,
        "slot_evidence_map_01_20": slots,
        "sentence_reverse_map": reverse,
        "nakpada_subroute": {
            "trigger": "SUPPORT_ONLY",
            "skill_name": None,
            "status": "NOT_APPLICABLE",
            "scope_slots": ["05", "06"],
            "packet_ref": None,
            "hold_reason": "",
        },
        "output_artifact": {
            "path": "D10H10_FNa98_심층촘촘결_칼끝문장_01-20.txt",
            "artifact_sha256": "2" * 64,
            "fixed_title_vector_sha256": title_vector_sha256(),
            "output_validation_status": "PASS",
            "status": "PASS",
        },
        "validation_passes": {
            "pass_1_source_identity": "PASS",
            "pass_2_structure_why": "PASS",
            "pass_3_format_delivery": "PASS",
        },
        "final_status": "PASS",
        "holds": [],
        "conflicts": [],
    }


class FixedKnifePacketTests(unittest.TestCase):
    def assert_error(self, packet: dict, fragment: str) -> None:
        errors = validate(packet)
        self.assertTrue(
            any(fragment in error for error in errors),
            msg=f"Expected {fragment!r}; got:\n" + "\n".join(errors),
        )

    def test_valid_packet_passes(self) -> None:
        self.assertEqual(validate(valid_packet()), [])

    def test_dynamic_route_is_rejected(self) -> None:
        packet = valid_packet()
        packet["operation_route"] = "STRUCTURAL_JOINT_DISCOVERY"
        self.assert_error(packet, "operation_route must be FIXED")

    def test_dynamic_field_is_rejected(self) -> None:
        packet = valid_packet()
        packet["joint_bank"] = []
        self.assert_error(packet, "foreign route field")

    def test_fixed_title_mutation_is_rejected(self) -> None:
        packet = valid_packet()
        packet["slot_evidence_map_01_20"][4]["fixed_slot_title"] = "changed"
        self.assert_error(packet, "fixed_slot_title changed")

    def test_reverse_mapping_mismatch_is_rejected(self) -> None:
        packet = valid_packet()
        packet["sentence_reverse_map"][0]["source_value"] = "invented"
        self.assert_error(packet, "does not match evidence")

    def test_transit_boundary_cannot_be_promoted(self) -> None:
        packet = valid_packet()
        packet["source_provider_lock"]["transit_canonical_status"] = "ACTIVE_CANONICAL"
        self.assert_error(packet, "Transit canonical boundary changed")

    def test_nakpada_pass_requires_packet_reference(self) -> None:
        packet = valid_packet()
        packet["nakpada_subroute"]["status"] = "PASS"
        self.assert_error(packet, "PASS requires packet_ref")

    def test_primary_nakpada_target_cannot_be_skipped(self) -> None:
        packet = valid_packet()
        packet["nakpada_subroute"].update({
            "trigger": "PRIMARY_TARGET",
            "skill_name": "rq-nak",
            "status": "NOT_APPLICABLE",
        })
        self.assert_error(packet, "must be PASS or HOLD")

    def test_source_missing_hold_packet_passes(self) -> None:
        packet = valid_packet()
        packet["source_provider_lock"]["rq_sc_status"] = "HOLD"
        packet["source_packet"] = []
        packet["evidence_registry"] = []
        for slot in packet["slot_evidence_map_01_20"]:
            slot.update({
                "applicable_source_ids": [],
                "evidence_ids": [],
                "direct_fact": "",
                "why_parent": "",
                "result_boundary": "",
                "evidence_grade": "HOLD",
                "assertion_state": "BLOCKED",
                "status": "HOLD_BOUNDARY",
                "hold_reason": "Google Drive Active Canonical values are unavailable.",
            })
        packet["sentence_reverse_map"] = []
        packet["nakpada_subroute"].update({
            "trigger": "PRIMARY_TARGET",
            "skill_name": "rq-nak",
            "status": "HOLD",
            "packet_ref": None,
            "hold_reason": "Nakshatra/Pada Source packet is unavailable.",
        })
        packet["output_artifact"].update({
            "path": "",
            "artifact_sha256": "",
            "output_validation_status": "HOLD",
            "status": "HOLD",
        })
        packet["validation_passes"] = {
            "pass_1_source_identity": "HOLD",
            "pass_2_structure_why": "HOLD",
            "pass_3_format_delivery": "NOT_APPLICABLE",
        }
        packet["final_status"] = "HOLD"
        packet["holds"] = ["Required canonical chart values are unavailable."]
        self.assertEqual(validate(packet), [])


if __name__ == "__main__":
    unittest.main()
