#!/usr/bin/env python3
"""Validate the fixed-title FNa98 knife-sentence 01-20 human artifact."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


D_CHARTS = {
    "D1", "D9", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D10",
    "D11", "D12", "D16", "D20", "D24", "D27", "D30", "D40", "D45", "D60",
}
HOUSES = {f"H{number:02d}" for number in range(1, 13)}
DIVIDER_LINE = "━" * 24
FIXED_TITLES = [
    "도메인과 질문을 정확히 고정",
    "Rashi의 기본 Promise와 배역 확정",
    "Bhava의 실제 도착 위치와 현실 작동장 확인",
    "House Lord·점유행성·카라카의 독립 의제 분리",
    "Nakshatra·Pada·RL/NL·SL·SSL 착색 삽입",
    "도수·공동장·선후관절·근접성 확인",
    "행성강도층 전수 삽입",
    "Aspect·Argala·Parivartana·관계망 삽입",
    "Avastha·연소·역행·MKS 등 작동상태 삽입",
    "Arudha·Pada·귀속·가시화·이미지층 삽입",
    "동일 D 내부의 하우스 간 회로 연결",
    "다른 D차트의 지지·충돌·보정 검산",
    "Dasha가 실제 실행권자를 선택",
    "Timing Gate·Transit이 점화 관절을 지정",
    "인과·전달·도착·귀속·보유·회수 경로 조립",
    "병목의 정확한 위치와 손실 원인 확정",
    "조건 변화에 따른 관계 전환과 결과 변화 추적",
    "단기·중단기·장기 결과 분리",
    "모든 층의 모순·누락·과잉해석 전수 검산",
    "하나의 통합 잠금문으로 봉합",
]
TARGET_RE = re.compile(
    r"^《(?P<d>D\d+)-(?P<h>H\d{2}) 심층촘촘결 FNa98 칼끝문장》$",
    re.MULTILINE,
)
FIXED_HEADING_RE = re.compile(r"^《(?P<no>\d{2})》 (?P<title>.+)$", re.MULTILINE)
ANY_NUMERIC_HEADING_RE = re.compile(r"^《\d{2}(?:[.\-]|》).*$", re.MULTILINE)
PLACEHOLDER_RE = re.compile(r"<[^<>\n]+>")


def normalized(value: str) -> str:
    return " ".join(value.casefold().split())


def split_slot_bodies(text: str, matches: list[re.Match[str]]) -> list[str]:
    bodies: list[str] = []
    content_end = text.find("\nContent End", matches[-1].end()) if matches else -1
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else content_end
        bodies.append(text[match.end():end].strip() if end >= 0 else "")
    return bodies


def validate_divider_lines(text: str) -> list[str]:
    divider_lines = [line for line in text.splitlines() if line and set(line) == {"━"}]
    errors: list[str] = []
    if len(divider_lines) < 3:
        errors.append("expected at least three divider lines")
    for index, line in enumerate(divider_lines, start=1):
        if line != DIVIDER_LINE:
            errors.append(f"divider line {index} must contain exactly 24 ━ characters")
    return errors


def validate_text(text: str) -> list[str]:
    errors: list[str] = []
    text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    errors.extend(validate_divider_lines(text))

    targets = list(TARGET_RE.finditer(text))
    if len(targets) != 1:
        errors.append(f"expected one final target title, got {len(targets)}")
        target_d = target_h = ""
    else:
        target_d = targets[0].group("d")
        target_h = targets[0].group("h")
        if target_d not in D_CHARTS:
            errors.append(f"unsupported D chart: {target_d}")
        if target_h not in HOUSES:
            errors.append(f"unsupported house: {target_h}")

    headings = list(FIXED_HEADING_RE.finditer(text))
    foreign_headings = [
        match.group(0)
        for match in ANY_NUMERIC_HEADING_RE.finditer(text)
        if FIXED_HEADING_RE.fullmatch(match.group(0)) is None
    ]
    if foreign_headings:
        errors.append(f"foreign heading family found: {foreign_headings[0]}")
    if len(headings) != 20:
        errors.append(f"expected 20 fixed headings, got {len(headings)}")
    expected_numbers = [f"{number:02d}" for number in range(1, 21)]
    actual_numbers = [match.group("no") for match in headings]
    if actual_numbers != expected_numbers:
        errors.append("fixed headings must be 01-20 exactly once and in order")
    actual_titles = [match.group("title").strip() for match in headings]
    if actual_titles != FIXED_TITLES:
        for index, (actual, expected) in enumerate(
            zip(actual_titles, FIXED_TITLES), start=1
        ):
            if actual != expected:
                errors.append(
                    f"slot {index:02d} title changed: expected {expected!r}, got {actual!r}"
                )
        if len(actual_titles) != len(FIXED_TITLES):
            errors.append("fixed title topology is incomplete")

    bodies = split_slot_bodies(text, headings)
    seen_bodies: dict[str, int] = {}
    for index, body in enumerate(bodies, start=1):
        if not body:
            errors.append(f"slot {index:02d} body is empty")
            continue
        body_key = normalized(body)
        if body_key in seen_bodies:
            errors.append(
                f"slot bodies are identical: {seen_bodies[body_key]:02d} and {index:02d}"
            )
        else:
            seen_bodies[body_key] = index

    placeholders = PLACEHOLDER_RE.findall(text)
    if placeholders:
        preview = ", ".join(placeholders[:5])
        errors.append(f"unresolved placeholders remain: {preview}")

    if text.count("Content End") != 1:
        errors.append("Content End must appear exactly once")
    if target_d and target_h:
        expected_title = (
            f"TITLE={target_d}{target_h}_FNa98_심층촘촘결_칼끝문장_01-20"
        )
        expected_index = (
            f"INDEX=STRUCTURAL_JOINT_DISCOVERY > {target_d} > {target_h} "
            "> KNIFE_SENTENCE_01_20"
        )
        title_lines = [line for line in text.splitlines() if line.startswith("TITLE=")]
        index_lines = [line for line in text.splitlines() if line.startswith("INDEX=")]
        if title_lines != [expected_title]:
            errors.append(f"ending TITLE mismatch: expected {expected_title}")
        if index_lines != [expected_index]:
            errors.append(f"ending INDEX mismatch: expected {expected_index}")

    status_re = re.compile(
        r"^STATUS=(PASS|REVISE|HOLD) / SOURCE_LOCK / "
        r"20_SLOT_DISTINCTNESS_CHECK / REVERSE_MAPPING_REQUIRED / "
        r"NO_INTERPRETATION_OVERREACH$",
        re.MULTILINE,
    )
    status_lines = [line for line in text.splitlines() if line.startswith("STATUS=")]
    if len(status_re.findall(text)) != 1 or len(status_lines) != 1:
        errors.append("ending STATUS is missing or does not match the fixed contract")
    return errors


def validate(path: Path) -> list[str]:
    try:
        return validate_text(path.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        return [f"cannot read artifact: {exc}"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", type=Path, help="Filled fixed-title knife-sentence file")
    args = parser.parse_args()
    errors = validate(args.artifact)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
