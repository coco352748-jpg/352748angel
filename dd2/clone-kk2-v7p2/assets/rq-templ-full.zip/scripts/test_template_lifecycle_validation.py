#!/usr/bin/env python3
"""Regression tests for validate_template_lifecycle_packet.py."""

from copy import deepcopy
import unittest

from validate_template_lifecycle_packet import validate


def valid_packet() -> dict:
    return {
        "schema_version": "RQ_TEMPL_LIFECYCLE_V1",
        "scope_firewall": {
            "current_target": "Build and validate one reusable chart template family",
            "deliverable": "one validated reusable chart template family",
            "deliverable_count": 1,
            "in_scope_requirements": ["REQ-1"],
            "direct_dependency_links": [],
            "authorized_actions": [
                {"action": "BUILD_AND_VALIDATE_TEMPLATE", "requirement_ref": "REQ-1"},
            ],
            "auto_import": False,
            "scope_expansion": "NOT_REQUIRED",
            "user_output": "FINAL_ONLY",
            "execution_budget": {
                "analysis_design_percent": 30,
                "product_creation_percent": 60,
                "final_validation_percent": 10,
            },
            "stop_condition": {
                "deliverable_exists": True,
                "explicit_conditions_met": True,
                "final_validation_complete": True,
                "stop_now": True,
            },
            "status": "PASS",
        },
        "actual_question": "Build and validate one reusable chart template family",
        "target": "D10-H10 template family",
        "action": "BUILD",
        "operation_route": "PIKACHU_CANONICAL_PATH",
        "source_scope": {
            "included_source_ids": ["SC-1"],
            "excluded_sources": [],
            "admission_verified": True,
            "authority_verified": True,
        },
        "file_family": {
            "family_id": "FAMILY-1",
            "filename_pattern": "<D>-<H>.txt",
            "block_order": ["TITLE", "BODY", "META"],
            "ending_meta": ["TITLE", "INDEX", "STATUS"],
            "one_chart_one_file": True,
        },
        "stage_roles": [{
            "stage_id": "01",
            "input_refs": ["SC-1#L1"],
            "operation": "LOCK_TARGET",
            "output": "D10-H10",
            "handoff_to": "02",
            "evidence_grade": "DIRECT_SOURCE",
            "status": "PASS",
        }],
        "input_sources": [{
            "source_id": "SC-1",
            "name_or_path": "template_Sc.txt",
            "authority_state": "ACTIVE",
            "material_state": "PARSED",
            "sc_verified": True,
            "sc_verification_basis": "SC_FILENAME_TOKEN",
            "created_at": None,
            "created_at_source": None,
            "admission_basis": "SC_VERIFIED",
            "read_scope": "FULL",
            "allowed_uses": ["TEMPLATE"],
            "prohibited_uses": ["CANONICAL_CHANGE"],
        }],
        "source_separation": {
            "natal_anchor": {"status": "NOT_APPLICABLE", "source_ids": []},
            "target_native": {"status": "APPLICABLE", "source_ids": ["SC-1"]},
            "vas_native": {"status": "NOT_APPLICABLE", "source_ids": []},
            "support": {"status": "NOT_APPLICABLE", "source_ids": []},
        },
        "batch_scope": {
            "unit": "ONE_D_CHART_X_ONE_HOUSE_X_ONE_VIEW",
            "expected_job_count": 1,
            "actual_job_count": 1,
            "unique_target_count": 1,
            "duplicate_target_count": 0,
            "d_chart_set": [
                "D1", "D9", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D10",
                "D11", "D12", "D16", "D20", "D24", "D27", "D30", "D40", "D45", "D60",
            ],
            "coordinate_map_stage": "00A-00C",
            "coordinate_scan_count": 1,
            "downstream_rescan": False,
        },
        "application_route": {
            "route_id": "PIKACHU_CANONICAL_PATH",
            "ordered_steps": ["00A", "00B", "00C", "01-20"],
            "route_validator": "validate_work_packet.py",
            "route_validation_status": "PASS",
        },
        "template_topology": {
            "block_order": ["TITLE", "BODY", "META"],
            "placeholder_bindings": {"TARGET": "SC-1#L1"},
            "ending_meta": ["TITLE", "INDEX", "STATUS"],
            "divider_line": "━━━━━━━━━━━━━━━━━━━━━━━━",
            "topology_status": "PASS",
        },
        "raw_check": {field: "PASS" for field in (
            "source_values", "d_chart_distribution", "view_boundary", "visibility_boundary", "occupant_lord_state"
        )},
        "link_check": {field: "PASS" for field in (
            "stage_handoffs", "source_reverse_mapping", "placeholder_binding", "domain_house_preservation", "job_uniqueness", "attribution_chain", "coordinate_map_single_scan"
        )},
        "pilot": {"target_key": "D10-H10", "status": "PASS", "skip_authorized": False, "evidence": "pilot.txt"},
        "validation_passes": {
            "pass_1_source_identity": "PASS",
            "pass_2_structure_why": "PASS",
            "pass_3_format_delivery": "PASS",
        },
        "final_output": {
            "paths": ["D10-H10.txt"],
            "file_count": 1,
            "exists": True,
            "reopened": True,
            "ending_meta_verified": True,
            "archive_extract_verified": "NOT_APPLICABLE",
            "final_only": True,
            "stop_condition_met": True,
        },
        "final_status": "PASS",
        "delivery_disposition": "PASS",
        "holds": [],
        "conflicts": [],
    }


def valid_fixed_route_packet() -> dict:
    packet = valid_packet()
    packet["operation_route"] = "FIXED_KNIFE_SENTENCE_01_20_PATH"
    packet["application_route"] = {
        "route_id": "FIXED_KNIFE_SENTENCE_01_20_PATH",
        "ordered_steps": [
            "00_TARGET_LOCK",
            "01_SOURCE_LOCK",
            "02_SLOT_EVIDENCE_MAP_01_20",
            "03_FIXED_SENTENCE_ASSEMBLY_01_20",
            "04_SENTENCE_REVERSE_MAP",
            "05_FIXED_PACKET_VALIDATION",
            "06_FIXED_OUTPUT_VALIDATION",
            "07_3PASS_FINAL_GATE",
        ],
        "route_validator": [
            "validate_fixed_knife_sentence_packet.py",
            "validate_fixed_knife_sentence_output.py",
        ],
        "route_validation_status": "PASS",
    }
    return packet


def valid_structural_route_packet() -> dict:
    packet = valid_packet()
    packet["operation_route"] = "STRUCTURAL_JOINT_DISCOVERY"
    packet["template_identity"] = {
        "template_id": "DEEP_DENSE_KNIFE_SENTENCE_TEMPLATE_SET_V2",
        "template_version": "V2_REPAIRED",
        "template_authority": "ACTIVE_CANONICAL",
        "canonical_scope": "RQ_VEDIC_SYSTEM_WIDE_FOR_STRUCTURAL_JOINT_DISCOVERY",
    }
    packet["application_route"] = {
        "route_id": "STRUCTURAL_JOINT_DISCOVERY",
        "ordered_steps": [
            "00_TARGET_LOCK",
            "01_SOURCE_ROUTER_16",
            "02_EVIDENCE_REGISTRY",
            "03_STRUCTURAL_JOINT_DISCOVERY",
            "04_JOINT_BANK",
            "05_INDEPENDENT_ALLOCATION_01_20",
            "06_HUMAN_SENTENCE_ASSEMBLY",
            "07_SENTENCE_REVERSE_MAP",
            "08_MINIMUM_FINAL_GATE",
        ],
        "route_validator": [
            "validate_structural_joint_packet.py",
            "validate_knife_sentence_v2_output.py",
        ],
        "route_validation_status": "PASS",
    }
    return packet


class TemplateLifecycleTests(unittest.TestCase):
    def assert_error(self, packet: dict, fragment: str) -> None:
        errors = validate(packet)
        self.assertTrue(
            any(fragment in error for error in errors),
            msg=f"Expected {fragment!r}; got:\n" + "\n".join(errors),
        )

    def test_valid_packet_passes(self) -> None:
        self.assertEqual(validate(valid_packet()), [])

    def test_valid_fixed_route_packet_passes(self) -> None:
        self.assertEqual(validate(valid_fixed_route_packet()), [])

    def test_valid_structural_route_packet_passes(self) -> None:
        self.assertEqual(validate(valid_structural_route_packet()), [])

    def test_structural_route_requires_active_canonical_v2(self) -> None:
        packet = valid_structural_route_packet()
        packet["template_identity"]["template_authority"] = "CURRENT_SPECIFIED"
        self.assert_error(packet, "template_identity.template_authority must be")

    def test_explicit_void_r4_source_is_rejected(self) -> None:
        packet = valid_structural_route_packet()
        packet["input_sources"][0]["name_or_path"] = "DDCHART_Mj01_FNa98_R4_P02.txt"
        self.assert_error(packet, "explicitly VOID R4 source")

    def test_duplicate_job_is_rejected(self) -> None:
        packet = valid_packet()
        packet["batch_scope"]["duplicate_target_count"] = 1
        self.assert_error(packet, "duplicate-free")

    def test_void_source_is_rejected(self) -> None:
        packet = valid_packet()
        packet["input_sources"][0]["authority_state"] = "VOID"
        self.assert_error(packet, "not ACTIVE")

    def test_broken_link_is_rejected(self) -> None:
        packet = valid_packet()
        packet["link_check"]["stage_handoffs"] = "REVISE"
        self.assert_error(packet, "unresolved gate")

    def test_boundary_disposition_requires_note(self) -> None:
        packet = valid_packet()
        packet["delivery_disposition"] = "PASS_WITH_BOUNDARY_NOTE"
        self.assert_error(packet, "boundary_note")

    def test_route_id_mismatch_is_rejected(self) -> None:
        packet = valid_packet()
        packet["operation_route"] = "FIXED_KNIFE_SENTENCE_01_20_PATH"
        self.assert_error(packet, "route_id must match")

    def test_wrong_route_validator_is_rejected(self) -> None:
        packet = valid_packet()
        packet["application_route"]["route_validator"] = "anything.py"
        self.assert_error(packet, "route_validator does not match")

    def test_source_admission_is_not_bypassed(self) -> None:
        packet = valid_packet()
        packet["input_sources"][0]["sc_verified"] = False
        packet["input_sources"][0]["sc_verification_basis"] = "NOT_SC"
        packet["input_sources"][0]["admission_basis"] = "CREATED_ON_OR_AFTER_2026_08_09_KST"
        self.assert_error(packet, "is inadmissible")

    def test_scope_auto_import_is_rejected(self) -> None:
        packet = valid_packet()
        packet["scope_firewall"]["auto_import"] = True
        self.assert_error(packet, "auto_import must be false")

    def test_scope_action_without_requirement_link_is_rejected(self) -> None:
        packet = valid_packet()
        packet["scope_firewall"]["authorized_actions"][0]["requirement_ref"] = "OUT-OF-SCOPE"
        self.assert_error(packet, "no in-scope requirement link")

    def test_non_24_character_divider_is_rejected(self) -> None:
        packet = valid_packet()
        packet["template_topology"]["divider_line"] = "━" * 25
        self.assert_error(packet, "exactly 24")

    def test_default_20d_membership_is_locked(self) -> None:
        packet = valid_packet()
        packet["batch_scope"]["d_chart_set"][5] = "D50"
        self.assert_error(packet, "include D5, exclude VOID D50")

    def test_downstream_20d_rescan_is_rejected(self) -> None:
        packet = valid_packet()
        packet["batch_scope"]["coordinate_scan_count"] = 2
        packet["batch_scope"]["downstream_rescan"] = True
        self.assert_error(packet, "coordinate_scan_count must be exactly 1")
        self.assert_error(packet, "downstream_rescan must be false")


if __name__ == "__main__":
    unittest.main()
