#!/usr/bin/env python3
"""Regression tests for fixed and dynamic knife-sentence output validators."""

from __future__ import annotations

import sys
import unittest
import hashlib
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from validate_fixed_knife_sentence_output import (  # noqa: E402
    FIXED_HEADING_RE,
    FIXED_TITLES,
    validate_text as validate_fixed,
)
from validate_knife_sentence_v2_output import validate_text as validate_dynamic  # noqa: E402


def fixed_artifact() -> str:
    blocks = [
        f"《{number:02d}》 {title}\n고정 경로 {number:02d}번의 Source 역매핑된 고유 문장이다."
        for number, title in enumerate(FIXED_TITLES, start=1)
    ]
    return "\n".join([
        "━━━━━━━━━━━━━━━━━━━━━━━━",
        "《D10-H10 심층촘촘결 FNa98 칼끝문장》",
        "━━━━━━━━━━━━━━━━━━━━━━━━",
        *blocks,
        "Content End",
        "TITLE=D10H10_FNa98_심층촘촘결_칼끝문장_01-20",
        "INDEX=STRUCTURAL_JOINT_DISCOVERY > D10 > H10 > KNIFE_SENTENCE_01_20",
        "STATUS=PASS / SOURCE_LOCK / 20_SLOT_DISTINCTNESS_CHECK / REVERSE_MAPPING_REQUIRED / NO_INTERPRETATION_OVERREACH",
        "━━━━━━━━━━━━━━━━━━━━━━━━",
    ])


def dynamic_artifact() -> str:
    blocks = [
        f"《{number:02d}. 발견관절-{number:02d}》\n동적 경로 {number:02d}번의 Source 역매핑된 고유 문장이다."
        for number in range(1, 21)
    ]
    return "\n".join([
        "━━━━━━━━━━━━━━━━━━━━━━━━",
        "《D9-H05 심층촘촘결 FNa98 칼끝문장》",
        "━━━━━━━━━━━━━━━━━━━━━━━━",
        *blocks,
        "Content End",
        "TITLE=D9H05_FNa98_심층촘촘결_칼끝문장_01-20",
        "INDEX=STRUCTURAL_JOINT_DISCOVERY > D9 > H05 > INDEPENDENT_ALLOCATION_01_20 > KNIFE_SENTENCE",
        "STATUS=PASS / SOURCE_ROUTER_16 / STRUCTURAL_DISCOVERY_FIRST / 20_SLOT_DISTINCTNESS / REVERSE_MAPPING",
        "━━━━━━━━━━━━━━━━━━━━━━━━",
    ])


class KnifeSentenceValidatorTests(unittest.TestCase):
    def assert_error(self, errors: list[str], fragment: str) -> None:
        self.assertTrue(
            any(fragment in error for error in errors),
            msg=f"Expected {fragment!r}; got:\n" + "\n".join(errors),
        )

    def test_fixed_artifact_passes(self) -> None:
        self.assertEqual(validate_fixed(fixed_artifact()), [])

    def test_dynamic_artifact_passes(self) -> None:
        self.assertEqual(validate_dynamic(dynamic_artifact()), [])

    def test_d50_is_void(self) -> None:
        candidate = fixed_artifact().replace("D10", "D50")
        self.assert_error(validate_fixed(candidate), "unsupported D chart: D50")

    def test_d5_is_supported(self) -> None:
        candidate = fixed_artifact().replace("D10", "D5")
        self.assertEqual(validate_fixed(candidate), [])

    def test_25_character_divider_is_rejected(self) -> None:
        candidate = fixed_artifact().replace("━━━━━━━━━━━━━━━━━━━━━━━━", "━━━━━━━━━━━━━━━━━━━━━━━━━", 1)
        self.assert_error(validate_fixed(candidate), "exactly 24")

    def test_fixed_title_change_is_rejected(self) -> None:
        candidate = fixed_artifact().replace(FIXED_TITLES[4], "임의 변경 제목", 1)
        self.assert_error(validate_fixed(candidate), "slot 05 title changed")

    def test_fixed_placeholder_is_rejected(self) -> None:
        candidate = fixed_artifact().replace("고정 경로 01번", "<UNRESOLVED>", 1)
        self.assert_error(validate_fixed(candidate), "unresolved placeholders")

    def test_fixed_duplicate_body_is_rejected(self) -> None:
        candidate = fixed_artifact().replace(
            "고정 경로 02번의 Source 역매핑된 고유 문장이다.",
            "고정 경로 01번의 Source 역매핑된 고유 문장이다.",
            1,
        )
        self.assert_error(validate_fixed(candidate), "slot bodies are identical")

    def test_dynamic_duplicate_title_is_rejected(self) -> None:
        candidate = dynamic_artifact().replace("발견관절-02", "발견관절-01", 1)
        self.assert_error(validate_dynamic(candidate), "dynamic titles are duplicated")

    def test_dynamic_fixed_title_copy_is_rejected(self) -> None:
        candidate = dynamic_artifact()
        for number, title in enumerate(FIXED_TITLES, start=1):
            candidate = candidate.replace(f"발견관절-{number:02d}", title, 1)
        self.assert_error(validate_dynamic(candidate), "complete fixed/calibration title vector")

    def test_fixed_and_dynamic_formats_are_not_interchangeable(self) -> None:
        self.assert_error(validate_fixed(dynamic_artifact()), "expected 20 fixed headings")
        self.assert_error(validate_dynamic(fixed_artifact()), "expected 20 dynamic headings")

    def test_foreign_substage_heading_is_rejected(self) -> None:
        candidate = fixed_artifact().replace(
            "Content End", "《16-01》 foreign substage\nforeign body\nContent End", 1
        )
        self.assert_error(validate_fixed(candidate), "foreign heading family")

    def test_extra_ending_meta_is_rejected(self) -> None:
        candidate = fixed_artifact().replace(
            "TITLE=D10H10_", "TITLE=WRONG\nTITLE=D10H10_", 1
        )
        self.assert_error(validate_fixed(candidate), "ending TITLE mismatch")

    def test_saved_fixed_template_preserves_user_topology(self) -> None:
        template = (
            SKILL_DIR / "references" / "fixed-knife-sentence-template-01-20.txt"
        ).read_text(encoding="utf-8")
        self.assertEqual(
            hashlib.sha256(template.encode("utf-8")).hexdigest(),
            "ef001b7c9ae33638e964217fd59bfb7d895762b34756d8e9eca26d14724aafb0",
        )
        headings = list(FIXED_HEADING_RE.finditer(template))
        self.assertEqual([match.group("no") for match in headings], [f"{n:02d}" for n in range(1, 21)])
        self.assertEqual([match.group("title") for match in headings], FIXED_TITLES)
        self.assertIn("=GOOGLE_DRIVE_ACTIVE_CANONICAL", template)
        self.assertIn("=FETCH_FROM_DRIVE", template)
        self.assertIn("=FORBIDDEN", template)
        self.assertIn(
            "STATUS=<PASS / REVISE / HOLD> / SOURCE_LOCK / 20_SLOT_DISTINCTNESS_CHECK / REVERSE_MAPPING_REQUIRED / NO_INTERPRETATION_OVERREACH",
            template,
        )


if __name__ == "__main__":
    unittest.main()
