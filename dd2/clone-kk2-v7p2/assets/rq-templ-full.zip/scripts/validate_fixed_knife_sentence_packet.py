#!/usr/bin/env python3
"""Validate the fixed-title FNa98 knife-sentence Source and reverse-map packet."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

from source_admission import validate_source_admission
from validate_fixed_knife_sentence_output import D_CHARTS, FIXED_TITLES, HOUSES


REQUIRED_TOP = {
    "schema_version",
    "template_id",
    "operation_route",
    "actual_question",
    "target",
    "source_authority",
    "chart_value_mode",
    "unverified_value_generation",
    "pikachu_dependency",
    "dynamic_v2_dependency",
    "deep_dense_240h_dependency",
    "source_admission_policy",
    "source_provider_lock",
    "source_packet",
    "evidence_registry",
    "slot_evidence_map_01_20",
    "sentence_reverse_map",
    "nakpada_subroute",
    "output_artifact",
    "validation_passes",
    "final_status",
    "holds",
    "conflicts",
}
FORBIDDEN_DYNAMIC_FIELDS = {
    "joint_bank",
    "allocation_01_20",
    "source_router_16",
    "minimum_final_gate",
    "premap_execution",
    "master_execution_01_20",
    "post_bottleneck_execution_01_11",
}
SOURCE_FIELDS = {
    "source_id",
    "source_role",
    "name_or_path",
    "authority",
    "authority_state",
    "material_state",
    "read_scope",
    "identity_or_hash",
    "allowed_uses",
    "prohibited_uses",
    "sc_verified",
    "sc_verification_basis",
    "created_at",
    "created_at_source",
    "admission_basis",
}
EVIDENCE_FIELDS = {
    "evidence_id",
    "source_id",
    "source_locator",
    "source_value",
    "grade",
    "approved_rule_ref",
    "status",
}
SLOT_FIELDS = {
    "slot_no",
    "fixed_slot_title",
    "applicable_source_ids",
    "evidence_ids",
    "direct_fact",
    "why_parent",
    "result_boundary",
    "evidence_grade",
    "assertion_state",
    "status",
    "hold_reason",
}
REVERSE_FIELDS = {
    "slot_no",
    "clause_id",
    "core_clause",
    "evidence_id",
    "source_id",
    "source_locator",
    "source_value",
    "evidence_grade",
    "result_boundary",
    "status",
}
SLOT_STATUSES = {"PASS", "HOLD_BOUNDARY", "NOT_APPLICABLE"}
FINAL_STATUSES = {"PASS", "REVISE", "HOLD"}
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def nonempty(value: Any) -> bool:
    return value is not None and value != "" and value != [] and value != {}


def missing_keys(value: object, fields: set[str], label: str, errors: list[str]) -> None:
    if not isinstance(value, dict):
        errors.append(f"{label} must be an object")
        return
    missing = sorted(fields - set(value))
    if missing:
        errors.append(f"{label} missing: {', '.join(missing)}")


def require_nonempty(value: dict[str, Any], fields: set[str], label: str, errors: list[str]) -> None:
    for field in sorted(fields):
        if not nonempty(value.get(field)):
            errors.append(f"{label} empty: {field}")


def title_vector_sha256() -> str:
    return hashlib.sha256("\n".join(FIXED_TITLES).encode("utf-8")).hexdigest()


def validate(packet: object) -> list[str]:
    errors: list[str] = []
    missing_keys(packet, REQUIRED_TOP, "packet", errors)
    if not isinstance(packet, dict):
        return errors

    exact = {
        "template_id": "FIXED_KNIFE_SENTENCE_01_20_FNA98_V1",
        "operation_route": "FIXED_KNIFE_SENTENCE_01_20_PATH",
        "source_authority": "GOOGLE_DRIVE_ACTIVE_CANONICAL",
        "chart_value_mode": "FETCH_FROM_DRIVE",
        "unverified_value_generation": "FORBIDDEN",
        "pikachu_dependency": "NOT_USED",
        "dynamic_v2_dependency": "NOT_USED",
        "deep_dense_240h_dependency": "NOT_USED",
    }
    for field, expected in exact.items():
        if packet.get(field) != expected:
            errors.append(f"{field} must be {expected}")
    for field in sorted(FORBIDDEN_DYNAMIC_FIELDS & set(packet)):
        errors.append(f"fixed path must not include foreign route field: {field}")
    if not nonempty(packet.get("actual_question")):
        errors.append("actual_question must be non-empty")

    final_status = packet.get("final_status")
    if final_status not in FINAL_STATUSES:
        errors.append("final_status is invalid")

    policy = packet.get("source_admission_policy")
    policy_expected = {
        "logic": "SC_VERIFIED_OR_CREATED_AT_CUTOFF",
        "cutoff": "2026-08-09T00:00:00+09:00",
        "cutoff_inclusive": True,
        "modified_at_fallback": "FORBIDDEN",
    }
    missing_keys(policy, set(policy_expected), "source_admission_policy", errors)
    if isinstance(policy, dict):
        for field, expected in policy_expected.items():
            if policy.get(field) != expected:
                errors.append(f"source_admission_policy.{field} must be {expected!r}")

    target = packet.get("target")
    target_fields = {
        "d_chart", "house_id", "source_house_token", "d_chart_domain", "house_function",
    }
    missing_keys(target, target_fields, "target", errors)
    if isinstance(target, dict):
        require_nonempty(target, target_fields, "target", errors)
        d_chart = str(target.get("d_chart"))
        house_id = str(target.get("house_id"))
        if d_chart not in D_CHARTS:
            errors.append("target.d_chart is unsupported")
        if house_id not in HOUSES:
            errors.append("target.house_id is unsupported")
        if house_id in HOUSES and target.get("source_house_token") != f"{int(house_id[1:])}H":
            errors.append("target.source_house_token does not match house_id")

    provider = packet.get("source_provider_lock")
    provider_fields = {
        "primary_authority", "rq_sc_status", "canonical_auto_promotion",
        "spirit_chalit_scope", "transit_scope", "transit_canonical_status",
    }
    missing_keys(provider, provider_fields, "source_provider_lock", errors)
    if isinstance(provider, dict):
        if provider.get("primary_authority") != "GOOGLE_DRIVE_ACTIVE_CANONICAL":
            errors.append("source_provider_lock.primary_authority mismatch")
        if provider.get("rq_sc_status") not in {"USED", "NOT_USED", "HOLD"}:
            errors.append("source_provider_lock.rq_sc_status is invalid")
        if provider.get("canonical_auto_promotion") != "FORBIDDEN":
            errors.append("source_provider_lock.canonical_auto_promotion must be FORBIDDEN")
        if provider.get("spirit_chalit_scope") != "D1_ONLY":
            errors.append("source_provider_lock.spirit_chalit_scope must be D1_ONLY")
        if provider.get("transit_scope") != "D1_D9_ONLY":
            errors.append("source_provider_lock.transit_scope must be D1_D9_ONLY")
        if provider.get("transit_canonical_status") != "CANONICAL_STATUS_NOT_DECLARED":
            errors.append("Transit canonical boundary changed")

    sources = packet.get("source_packet")
    source_ids: set[str] = set()
    canonical_source_ids: set[str] = set()
    if not isinstance(sources, list):
        errors.append("source_packet must be a list")
    else:
        for index, source in enumerate(sources):
            label = f"source_packet[{index}]"
            missing_keys(source, SOURCE_FIELDS, label, errors)
            if not isinstance(source, dict):
                continue
            errors.extend(validate_source_admission(source, label))
            source_id = str(source.get("source_id", ""))
            if not source_id:
                errors.append(f"{label}.source_id is empty")
            elif source_id in source_ids:
                errors.append(f"duplicate source_id: {source_id}")
            else:
                source_ids.add(source_id)
            if source.get("authority_state") != "ACTIVE":
                errors.append(f"{label} is not ACTIVE")
            if source.get("material_state") not in {"PARSED", "NOT_PARSED", "NONE"}:
                errors.append(f"{label}.material_state is invalid")
            if final_status == "PASS" and source.get("material_state") != "PARSED":
                errors.append(f"{label} is not PARSED")
            if (
                source.get("source_role") == "CANONICAL"
                and source.get("authority") == "GOOGLE_DRIVE_ACTIVE_CANONICAL"
            ):
                canonical_source_ids.add(source_id)
    if final_status == "PASS" and not canonical_source_ids:
        errors.append("source_packet requires a Google Drive Active Canonical source")

    registry = packet.get("evidence_registry")
    evidence_index: dict[str, dict[str, Any]] = {}
    if not isinstance(registry, list):
        errors.append("evidence_registry must be a list")
    else:
        for index, evidence in enumerate(registry):
            label = f"evidence_registry[{index}]"
            missing_keys(evidence, EVIDENCE_FIELDS, label, errors)
            if not isinstance(evidence, dict):
                continue
            evidence_id = str(evidence.get("evidence_id", ""))
            if evidence_id in evidence_index:
                errors.append(f"duplicate evidence_id: {evidence_id}")
            elif evidence_id:
                evidence_index[evidence_id] = evidence
            if evidence.get("source_id") not in source_ids:
                errors.append(f"{label} references unknown Source")
            if evidence.get("grade") not in {"DIRECT_SOURCE", "DERIVED"}:
                errors.append(f"{label}.grade is invalid")
            if evidence.get("grade") == "DERIVED" and not nonempty(evidence.get("approved_rule_ref")):
                errors.append(f"{label} DERIVED requires approved_rule_ref")
            if evidence.get("status") != "PASS":
                errors.append(f"{label}.status must be PASS")

    slots = packet.get("slot_evidence_map_01_20")
    expected_numbers = [f"{number:02d}" for number in range(1, 21)]
    slot_status: dict[str, str] = {}
    if not isinstance(slots, list) or len(slots) != 20:
        errors.append("slot_evidence_map_01_20 must contain exactly 20 slots")
    else:
        seen_numbers: list[str] = []
        for index, slot in enumerate(slots):
            label = f"slot_evidence_map_01_20[{index}]"
            missing_keys(slot, SLOT_FIELDS, label, errors)
            if not isinstance(slot, dict):
                continue
            slot_no = str(slot.get("slot_no", ""))
            seen_numbers.append(slot_no)
            slot_status[slot_no] = str(slot.get("status"))
            if index < len(FIXED_TITLES) and slot.get("fixed_slot_title") != FIXED_TITLES[index]:
                errors.append(f"{label}.fixed_slot_title changed")
            source_refs = slot.get("applicable_source_ids")
            evidence_refs = slot.get("evidence_ids")
            if not isinstance(source_refs, list) or any(ref not in source_ids for ref in source_refs):
                errors.append(f"{label}.applicable_source_ids is invalid")
            if not isinstance(evidence_refs, list) or any(ref not in evidence_index for ref in evidence_refs):
                errors.append(f"{label}.evidence_ids is invalid")
            status = slot.get("status")
            if status not in SLOT_STATUSES:
                errors.append(f"{label}.status is invalid")
            if status == "PASS":
                require_nonempty(
                    slot,
                    {"applicable_source_ids", "evidence_ids", "direct_fact", "why_parent", "result_boundary"},
                    label,
                    errors,
                )
                if slot.get("evidence_grade") not in {"DIRECT_SOURCE", "DERIVED"}:
                    errors.append(f"{label}.evidence_grade is invalid")
                if slot.get("assertion_state") not in {"CONFIRMED", "CONDITIONAL"}:
                    errors.append(f"{label}.assertion_state is invalid")
            elif not nonempty(slot.get("hold_reason")):
                errors.append(f"{label} {status} requires hold_reason")
        if seen_numbers != expected_numbers:
            errors.append("fixed slots must be 01-20 exactly once and in order")

    reverse = packet.get("sentence_reverse_map")
    mapped_slots: set[str] = set()
    if not isinstance(reverse, list):
        errors.append("sentence_reverse_map must be a list")
    else:
        for index, record in enumerate(reverse):
            label = f"sentence_reverse_map[{index}]"
            missing_keys(record, REVERSE_FIELDS, label, errors)
            if not isinstance(record, dict):
                continue
            slot_no = str(record.get("slot_no", ""))
            if slot_no not in expected_numbers:
                errors.append(f"{label}.slot_no is invalid")
            else:
                mapped_slots.add(slot_no)
            evidence = evidence_index.get(str(record.get("evidence_id")))
            if evidence is None:
                errors.append(f"{label} references unknown evidence")
            else:
                for field in ("source_id", "source_locator", "source_value"):
                    if record.get(field) != evidence.get(field):
                        errors.append(f"{label}.{field} does not match evidence")
            if record.get("source_id") not in source_ids:
                errors.append(f"{label} references unknown Source")
            if record.get("evidence_grade") not in {"DIRECT_SOURCE", "DERIVED"}:
                errors.append(f"{label}.evidence_grade is invalid")
            if record.get("status") != "PASS":
                errors.append(f"{label}.status must be PASS")
            require_nonempty(record, REVERSE_FIELDS, label, errors)
    pass_slots = {
        slot_no for slot_no, status in slot_status.items() if status == "PASS"
    }
    if mapped_slots != pass_slots:
        errors.append("sentence_reverse_map must cover every and only PASS fixed slot")

    nakpada = packet.get("nakpada_subroute")
    nakpada_fields = {
        "trigger", "skill_name", "status", "scope_slots", "packet_ref", "hold_reason",
    }
    missing_keys(nakpada, nakpada_fields, "nakpada_subroute", errors)
    if isinstance(nakpada, dict):
        trigger = nakpada.get("trigger")
        status = nakpada.get("status")
        if trigger not in {"PRIMARY_TARGET", "SUPPORT_ONLY", "NOT_APPLICABLE"}:
            errors.append("nakpada_subroute.trigger is invalid")
        if status not in {"PASS", "NOT_APPLICABLE", "HOLD"}:
            errors.append("nakpada_subroute.status is invalid")
        if nakpada.get("scope_slots") != ["05", "06"]:
            errors.append("nakpada_subroute.scope_slots must be 05 and 06")
        if trigger == "PRIMARY_TARGET":
            if nakpada.get("skill_name") != "rq-nak":
                errors.append("PRIMARY_TARGET requires rq-nak")
            if status not in {"PASS", "HOLD"}:
                errors.append("PRIMARY_TARGET nakpada subroute must be PASS or HOLD")
        if status == "PASS" and not nonempty(nakpada.get("packet_ref")):
            errors.append("nakpada_subroute PASS requires packet_ref")
        if status == "HOLD" and not nonempty(nakpada.get("hold_reason")):
            errors.append("nakpada_subroute HOLD requires hold_reason")

    output = packet.get("output_artifact")
    output_fields = {
        "path", "artifact_sha256", "fixed_title_vector_sha256", "output_validation_status", "status",
    }
    missing_keys(output, output_fields, "output_artifact", errors)
    if isinstance(output, dict):
        output_present = nonempty(output.get("path"))
        if final_status == "PASS" and not output_present:
            errors.append("output_artifact.path must be non-empty for PASS")
        if output_present and not SHA256_RE.fullmatch(str(output.get("artifact_sha256", ""))):
            errors.append("output_artifact.artifact_sha256 must be lowercase SHA256")
        if not output_present and nonempty(output.get("artifact_sha256")):
            errors.append("output_artifact.artifact_sha256 requires an artifact path")
        if output.get("fixed_title_vector_sha256") != title_vector_sha256():
            errors.append("output_artifact fixed title vector hash mismatch")
        if final_status == "PASS" and (
            output.get("output_validation_status") != "PASS" or output.get("status") != "PASS"
        ):
            errors.append("final PASS requires output artifact validation PASS")

    passes = packet.get("validation_passes")
    pass_fields = {"pass_1_source_identity", "pass_2_structure_why", "pass_3_format_delivery"}
    missing_keys(passes, pass_fields, "validation_passes", errors)
    if isinstance(passes, dict) and final_status == "PASS":
        if any(passes.get(field) != "PASS" for field in pass_fields):
            errors.append("final PASS requires all three validation passes")

    holds = packet.get("holds")
    conflicts = packet.get("conflicts")
    if not isinstance(holds, list) or not isinstance(conflicts, list):
        errors.append("holds and conflicts must be lists")
    elif final_status == "PASS" and (holds or conflicts):
        errors.append("final PASS cannot retain global holds or conflicts")
    elif final_status == "HOLD" and not holds:
        errors.append("final HOLD requires at least one explicit hold reason")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("packet", type=Path, help="Fixed knife-sentence packet JSON")
    args = parser.parse_args()
    try:
        packet = json.loads(args.packet.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"HOLD: cannot read packet: {exc}", file=sys.stderr)
        return 2
    errors = validate(packet)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS" if packet.get("final_status") == "PASS" else "SCHEMA_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
