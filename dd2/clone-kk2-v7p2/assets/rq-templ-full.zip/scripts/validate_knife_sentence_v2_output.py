#!/usr/bin/env python3
"""Validate a dynamic-title V2 knife-sentence 01-20 human artifact."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from validate_fixed_knife_sentence_output import (
    D_CHARTS,
    FIXED_TITLES,
    HOUSES,
    PLACEHOLDER_RE,
    normalized,
    validate_divider_lines,
)


TARGET_RE = re.compile(
    r"^《(?P<d>D\d+)-(?P<h>H\d{2}) 심층촘촘결 FNa98 칼끝문장》$",
    re.MULTILINE,
)
DYNAMIC_HEADING_RE = re.compile(
    r"^《(?P<no>\d{2})\. (?P<title>[^》\n]+)》$", re.MULTILINE
)
ANY_NUMERIC_HEADING_RE = re.compile(r"^《\d{2}(?:[.\-]|》).*$", re.MULTILINE)


def split_slot_bodies(text: str, matches: list[re.Match[str]]) -> list[str]:
    bodies: list[str] = []
    content_end = text.find("\nContent End", matches[-1].end()) if matches else -1
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else content_end
        bodies.append(text[match.end():end].strip() if end >= 0 else "")
    return bodies


def validate_text(text: str) -> list[str]:
    errors: list[str] = []
    text = text.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n")
    errors.extend(validate_divider_lines(text))

    targets = list(TARGET_RE.finditer(text))
    if len(targets) != 1:
        errors.append(f"expected one final target title, got {len(targets)}")
        target_d = target_h = ""
    else:
        target_d = targets[0].group("d")
        target_h = targets[0].group("h")
        if target_d not in D_CHARTS:
            errors.append(f"unsupported D chart: {target_d}")
        if target_h not in HOUSES:
            errors.append(f"unsupported house: {target_h}")

    headings = list(DYNAMIC_HEADING_RE.finditer(text))
    foreign_headings = [
        match.group(0)
        for match in ANY_NUMERIC_HEADING_RE.finditer(text)
        if DYNAMIC_HEADING_RE.fullmatch(match.group(0)) is None
    ]
    if foreign_headings:
        errors.append(f"foreign heading family found: {foreign_headings[0]}")
    if len(headings) != 20:
        errors.append(f"expected 20 dynamic headings, got {len(headings)}")
    expected_numbers = [f"{number:02d}" for number in range(1, 21)]
    actual_numbers = [match.group("no") for match in headings]
    if actual_numbers != expected_numbers:
        errors.append("dynamic headings must be 01-20 exactly once and in order")

    seen_titles: dict[str, int] = {}
    for index, match in enumerate(headings, start=1):
        title = match.group("title").strip()
        title_key = normalized(title)
        if not title:
            errors.append(f"slot {index:02d} dynamic title is empty")
        if title_key in seen_titles:
            errors.append(
                f"dynamic titles are duplicated: {seen_titles[title_key]:02d} and {index:02d}"
            )
        else:
            seen_titles[title_key] = index
    actual_title_vector = [normalized(match.group("title")) for match in headings]
    fixed_title_vector = [normalized(title) for title in FIXED_TITLES]
    if actual_title_vector == fixed_title_vector:
        errors.append("dynamic output copied the complete fixed/calibration title vector")

    bodies = split_slot_bodies(text, headings)
    seen_bodies: dict[str, int] = {}
    for index, body in enumerate(bodies, start=1):
        if not body:
            errors.append(f"slot {index:02d} body is empty")
            continue
        body_key = normalized(body)
        if body_key in seen_bodies:
            errors.append(
                f"slot bodies are identical: {seen_bodies[body_key]:02d} and {index:02d}"
            )
        else:
            seen_bodies[body_key] = index

    placeholders = PLACEHOLDER_RE.findall(text)
    if placeholders:
        preview = ", ".join(placeholders[:5])
        errors.append(f"unresolved placeholders remain: {preview}")
    if text.count("Content End") != 1:
        errors.append("Content End must appear exactly once")

    if target_d and target_h:
        expected_title = (
            f"TITLE={target_d}{target_h}_FNa98_심층촘촘결_칼끝문장_01-20"
        )
        expected_index = (
            f"INDEX=STRUCTURAL_JOINT_DISCOVERY > {target_d} > {target_h} "
            "> INDEPENDENT_ALLOCATION_01_20 > KNIFE_SENTENCE"
        )
        title_lines = [line for line in text.splitlines() if line.startswith("TITLE=")]
        index_lines = [line for line in text.splitlines() if line.startswith("INDEX=")]
        if title_lines != [expected_title]:
            errors.append(f"ending TITLE mismatch: expected {expected_title}")
        if index_lines != [expected_index]:
            errors.append(f"ending INDEX mismatch: expected {expected_index}")

    status_re = re.compile(
        r"^STATUS=(PASS|REVISE|HOLD) / SOURCE_ROUTER_16 / "
        r"STRUCTURAL_DISCOVERY_FIRST / 20_SLOT_DISTINCTNESS / REVERSE_MAPPING$",
        re.MULTILINE,
    )
    status_lines = [line for line in text.splitlines() if line.startswith("STATUS=")]
    if len(status_re.findall(text)) != 1 or len(status_lines) != 1:
        errors.append("ending STATUS is missing or does not match the V2 contract")
    return errors


def validate(path: Path) -> list[str]:
    try:
        return validate_text(path.read_text(encoding="utf-8-sig"))
    except OSError as exc:
        return [f"cannot read artifact: {exc}"]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifact", type=Path, help="Filled dynamic V2 knife-sentence file")
    args = parser.parse_args()
    errors = validate(args.artifact)
    if errors:
        print("REVISE")
        for error in errors:
            print(f"- {error}")
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
